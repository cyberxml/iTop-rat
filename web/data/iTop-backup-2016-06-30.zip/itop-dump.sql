-- MySQL dump 10.14  Distrib 5.5.47-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: itop
-- ------------------------------------------------------
-- Server version	5.5.47-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicationsolution`
--

DROP TABLE IF EXISTS `applicationsolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applicationsolution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT 'active',
  `redundancy` varchar(20) COLLATE utf8_unicode_ci DEFAULT 'disabled',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicationsolution`
--

LOCK TABLES `applicationsolution` WRITE;
/*!40000 ALTER TABLE `applicationsolution` DISABLE KEYS */;
INSERT INTO `applicationsolution` VALUES (11,'active','disabled'),(12,'active','disabled'),(13,'active','disabled'),(14,'active','disabled');
/*!40000 ALTER TABLE `applicationsolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asnumber`
--

DROP TABLE IF EXISTS `asnumber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asnumber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` decimal(10,0) DEFAULT NULL,
  `registrar_id` int(11) DEFAULT '0',
  `whois` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `validity_end` date DEFAULT NULL,
  `renewal_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `registrar_id` (`registrar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asnumber`
--

LOCK TABLES `asnumber` WRITE;
/*!40000 ALTER TABLE `asnumber` DISABLE KEYS */;
/*!40000 ALTER TABLE `asnumber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expire` datetime DEFAULT NULL,
  `temp_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `item_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `item_id` int(11) DEFAULT '0',
  `item_org_id` int(11) DEFAULT '0',
  `contents_data` longblob,
  `contents_mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contents_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `temp_id` (`temp_id`),
  KEY `item_class_item_id` (`item_class`,`item_id`),
  KEY `item_org_id` (`item_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brand`
--

DROP TABLE IF EXISTS `brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brand`
--

LOCK TABLES `brand` WRITE;
/*!40000 ALTER TABLE `brand` DISABLE KEYS */;
INSERT INTO `brand` VALUES (1),(2);
/*!40000 ALTER TABLE `brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `businessprocess`
--

DROP TABLE IF EXISTS `businessprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `businessprocess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `businessprocess`
--

LOCK TABLES `businessprocess` WRITE;
/*!40000 ALTER TABLE `businessprocess` DISABLE KEYS */;
/*!40000 ALTER TABLE `businessprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `connectableci`
--

DROP TABLE IF EXISTS `connectableci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connectableci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connectableci`
--

LOCK TABLES `connectableci` WRITE;
/*!40000 ALTER TABLE `connectableci` DISABLE KEYS */;
INSERT INTO `connectableci` VALUES (1),(2),(3),(4),(5),(6);
/*!40000 ALTER TABLE `connectableci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT 'active',
  `org_id` int(11) DEFAULT '0',
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `notify` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT 'yes',
  `function` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Contact',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'My last name','active',1,'my.email@foo.org','+00 000 000 000','yes','','Person'),(2,'Gavalda','active',2,'gavalda@it.com','','yes','','Person'),(3,'Monet','active',3,'monet@demo.com','','yes','','Person'),(4,'Delacroix','active',3,'delacroix@demo.com','','yes','','Person'),(5,'Flaubert','active',2,'flaubert@it.com','','yes','','Person'),(6,'Cocteau','active',2,'cocteau@it.com','','yes','','Person'),(7,'Rousseau','active',2,'rousseau@it.com','','yes','','Person'),(8,'Sartre','active',2,'sartre@it.com','','yes','','Person'),(9,'Verne','active',2,'vernes@it.com','','yes','','Person'),(10,'Duras','active',2,'duras@it.com','','yes','','Person'),(11,'Picasso','active',3,'pablo@demo.com','','yes','','Person'),(12,'Dali','active',3,'dali@demo.com','','yes','','Person'),(13,'Hugo','active',2,'hugo@it.com','','yes','','Person'),(14,'Hardware support','active',2,'hw@test.com','','yes','','Team'),(15,'Helpdesk','active',2,'','','yes','','Team'),(16,'Network support','active',2,'nw@test.com','','yes','','Team'),(17,'System & application support','active',2,'','','yes','','Team');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacttype`
--

DROP TABLE IF EXISTS `contacttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacttype`
--

LOCK TABLES `contacttype` WRITE;
/*!40000 ALTER TABLE `contacttype` DISABLE KEYS */;
INSERT INTO `contacttype` VALUES (12),(13),(14),(15),(16),(17);
/*!40000 ALTER TABLE `contacttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `cost_currency` enum('dollars','euros') COLLATE utf8_unicode_ci DEFAULT NULL,
  `contracttype_id` int(11) DEFAULT '0',
  `billing_frequency` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `cost_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `provider_id` int(11) DEFAULT '0',
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Contract',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `contracttype_id` (`contracttype_id`),
  KEY `provider_id` (`provider_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` VALUES (1,'Customer contract Demo',3,'',NULL,NULL,'',NULL,0,'','',2,NULL,'CustomerContract');
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracttype`
--

DROP TABLE IF EXISTS `contracttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contracttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracttype`
--

LOCK TABLES `contracttype` WRITE;
/*!40000 ALTER TABLE `contracttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customercontract`
--

DROP TABLE IF EXISTS `customercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customercontract`
--

LOCK TABLES `customercontract` WRITE;
/*!40000 ALTER TABLE `customercontract` DISABLE KEYS */;
INSERT INTO `customercontract` VALUES (1);
/*!40000 ALTER TABLE `customercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `databaseschema`
--

DROP TABLE IF EXISTS `databaseschema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `databaseschema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbserver_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `dbserver_id` (`dbserver_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `databaseschema`
--

LOCK TABLES `databaseschema` WRITE;
/*!40000 ALTER TABLE `databaseschema` DISABLE KEYS */;
INSERT INTO `databaseschema` VALUES (8,7),(27,25),(28,26);
/*!40000 ALTER TABLE `databaseschema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacenterdevice`
--

DROP TABLE IF EXISTS `datacenterdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datacenterdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rack_id` int(11) DEFAULT '0',
  `enclosure_id` int(11) DEFAULT '0',
  `nb_u` int(11) DEFAULT NULL,
  `managementip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `powera_id` int(11) DEFAULT '0',
  `powerB_id` int(11) DEFAULT '0',
  `redundancy` varchar(20) COLLATE utf8_unicode_ci DEFAULT '1',
  `managementip_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `enclosure_id` (`enclosure_id`),
  KEY `powera_id` (`powera_id`),
  KEY `powerB_id` (`powerB_id`),
  KEY `managementip_id` (`managementip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacenterdevice`
--

LOCK TABLES `datacenterdevice` WRITE;
/*!40000 ALTER TABLE `datacenterdevice` DISABLE KEYS */;
INSERT INTO `datacenterdevice` VALUES (1,0,0,NULL,'',0,0,'1',0),(2,0,0,NULL,'',0,0,'1',0),(3,0,0,NULL,'',0,0,'1',0),(4,0,0,NULL,'10.10.24.2',0,0,'1',0),(5,0,0,NULL,'',0,0,'1',0),(6,0,0,NULL,'',0,0,'1',0);
/*!40000 ALTER TABLE `datacenterdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbserver`
--

DROP TABLE IF EXISTS `dbserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbserver` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbserver`
--

LOCK TABLES `dbserver` WRITE;
/*!40000 ALTER TABLE `dbserver` DISABLE KEYS */;
INSERT INTO `dbserver` VALUES (7),(25),(26);
/*!40000 ALTER TABLE `dbserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliverymodel`
--

DROP TABLE IF EXISTS `deliverymodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliverymodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliverymodel`
--

LOCK TABLES `deliverymodel` WRITE;
/*!40000 ALTER TABLE `deliverymodel` DISABLE KEYS */;
INSERT INTO `deliverymodel` VALUES (1,'Standard support',2,'');
/*!40000 ALTER TABLE `deliverymodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsobject`
--

DROP TABLE IF EXISTS `dnsobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsobject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'DNSObject',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsobject`
--

LOCK TABLES `dnsobject` WRITE;
/*!40000 ALTER TABLE `dnsobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnsobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `documenttype_id` int(11) DEFAULT '0',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `status` enum('draft','obsolete','published') COLLATE utf8_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Document',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `documenttype_id` (`documenttype_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentfile`
--

DROP TABLE IF EXISTS `documentfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentfile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_data` longblob,
  `file_mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentfile`
--

LOCK TABLES `documentfile` WRITE;
/*!40000 ALTER TABLE `documentfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentnote`
--

DROP TABLE IF EXISTS `documentnote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentnote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentnote`
--

LOCK TABLES `documentnote` WRITE;
/*!40000 ALTER TABLE `documentnote` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentnote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documenttype`
--

DROP TABLE IF EXISTS `documenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documenttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documenttype`
--

LOCK TABLES `documenttype` WRITE;
/*!40000 ALTER TABLE `documenttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `documenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentweb`
--

DROP TABLE IF EXISTS `documentweb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentweb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentweb`
--

LOCK TABLES `documentweb` WRITE;
/*!40000 ALTER TABLE `documentweb` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentweb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domain`
--

DROP TABLE IF EXISTS `domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `parent_id_left` int(11) DEFAULT '0',
  `parent_id_right` int(11) DEFAULT '0',
  `requestor_id` int(11) DEFAULT '0',
  `release_date` datetime DEFAULT NULL,
  `registrar_id` int(11) DEFAULT '0',
  `validity_start` date DEFAULT NULL,
  `validity_end` date DEFAULT NULL,
  `renewal` enum('automatic','manual','na') COLLATE utf8_unicode_ci DEFAULT 'na',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`),
  KEY `requestor_id` (`requestor_id`),
  KEY `registrar_id` (`registrar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domain`
--

LOCK TABLES `domain` WRITE;
/*!40000 ALTER TABLE `domain` DISABLE KEYS */;
/*!40000 ALTER TABLE `domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enclosure`
--

DROP TABLE IF EXISTS `enclosure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enclosure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rack_id` int(11) DEFAULT '0',
  `nb_u` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enclosure`
--

LOCK TABLES `enclosure` WRITE;
/*!40000 ALTER TABLE `enclosure` DISABLE KEYS */;
/*!40000 ALTER TABLE `enclosure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `summary` text COLLATE utf8_unicode_ci,
  `description` longtext COLLATE utf8_unicode_ci,
  `category_id` int(11) DEFAULT '0',
  `error_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `key_words` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqcategory`
--

DROP TABLE IF EXISTS `faqcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nam` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqcategory`
--

LOCK TABLES `faqcategory` WRITE;
/*!40000 ALTER TABLE `faqcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `faqcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `farm`
--

DROP TABLE IF EXISTS `farm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `farm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `redundancy` varchar(20) COLLATE utf8_unicode_ci DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farm`
--

LOCK TABLES `farm` WRITE;
/*!40000 ALTER TABLE `farm` DISABLE KEYS */;
INSERT INTO `farm` VALUES (16,'1'),(17,'1');
/*!40000 ALTER TABLE `farm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fiberchannelinterface`
--

DROP TABLE IF EXISTS `fiberchannelinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fiberchannelinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `speed` decimal(6,2) DEFAULT NULL,
  `topology` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `wwn` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `datacenterdevice_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `datacenterdevice_id` (`datacenterdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fiberchannelinterface`
--

LOCK TABLES `fiberchannelinterface` WRITE;
/*!40000 ALTER TABLE `fiberchannelinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `fiberchannelinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functionalci`
--

DROP TABLE IF EXISTS `functionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `functionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `org_id` int(11) DEFAULT '0',
  `business_criticity` enum('high','low','medium') COLLATE utf8_unicode_ci DEFAULT 'low',
  `move2production` date DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'FunctionalCI',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functionalci`
--

LOCK TABLES `functionalci` WRITE;
/*!40000 ALTER TABLE `functionalci` DISABLE KEYS */;
INSERT INTO `functionalci` VALUES (1,'Server1','',3,'low',NULL,'Server'),(2,'Server2','',3,'low',NULL,'Server'),(3,'Server3','',3,'low',NULL,'Server'),(4,'Server4','',3,'low',NULL,'Server'),(5,'Router1','',3,'low',NULL,'NetworkDevice'),(6,'Switch1','',3,'low',NULL,'NetworkDevice'),(7,'Oracle','',3,'low',NULL,'DBServer'),(8,'openerpprod','',3,'low',NULL,'DatabaseSchema'),(9,'IIS','',3,'low',NULL,'WebServer'),(10,'onlineSales','',3,'low',NULL,'WebApplication'),(11,'CRM','',3,'high',NULL,'ApplicationSolution'),(12,'ERP','',3,'low',NULL,'ApplicationSolution'),(13,'itop','',3,'low',NULL,'ApplicationSolution'),(14,'Sales web site','',3,'high',NULL,'ApplicationSolution'),(15,'Rack1','',3,'low',NULL,'Rack'),(16,'Cluster1','',3,'low',NULL,'Farm'),(17,'Cluster2','',3,'medium',NULL,'Farm'),(18,'ESX1','',3,'low',NULL,'Hypervisor'),(19,'ESX2','',3,'low',NULL,'Hypervisor'),(20,'ESX3','',3,'low',NULL,'Hypervisor'),(21,'VM1','',3,'low',NULL,'VirtualMachine'),(22,'VM2','',3,'low',NULL,'VirtualMachine'),(23,'VM3','',3,'low',NULL,'VirtualMachine'),(24,'VM4','',3,'low',NULL,'VirtualMachine'),(25,'MySQL','',3,'low',NULL,'DBServer'),(26,'Oracle','',3,'low',NULL,'DBServer'),(27,'itop-demo','',3,'low',NULL,'DatabaseSchema'),(28,'sugarcrmprod','',3,'low',NULL,'DatabaseSchema'),(29,'Apache','',3,'low',NULL,'WebServer'),(30,'Open ERP','',3,'low',NULL,'WebApplication'),(31,'Sugar CRM','',3,'high',NULL,'WebApplication');
/*!40000 ALTER TABLE `functionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT 'implementation',
  `org_id` int(11) DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `parent_id` int(11) DEFAULT '0',
  `parent_id_left` int(11) DEFAULT '0',
  `parent_id_right` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hypervisor`
--

DROP TABLE IF EXISTS `hypervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hypervisor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `farm_id` int(11) DEFAULT '0',
  `server_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `farm_id` (`farm_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hypervisor`
--

LOCK TABLES `hypervisor` WRITE;
/*!40000 ALTER TABLE `hypervisor` DISABLE KEYS */;
INSERT INTO `hypervisor` VALUES (18,16,1),(19,16,3),(20,17,0);
/*!40000 ALTER TABLE `hypervisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iosversion`
--

DROP TABLE IF EXISTS `iosversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iosversion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iosversion`
--

LOCK TABLES `iosversion` WRITE;
/*!40000 ALTER TABLE `iosversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `iosversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipaddress`
--

DROP TABLE IF EXISTS `ipaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipaddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `domain_id` int(11) DEFAULT '0',
  `fqdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `aliases` text COLLATE utf8_unicode_ci,
  `usage_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `domain_id` (`domain_id`),
  KEY `usage_id` (`usage_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipaddress`
--

LOCK TABLES `ipaddress` WRITE;
/*!40000 ALTER TABLE `ipaddress` DISABLE KEYS */;
INSERT INTO `ipaddress` VALUES (1,'',0,'','',18);
/*!40000 ALTER TABLE `ipaddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipaddressv4`
--

DROP TABLE IF EXISTS `ipaddressv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipaddressv4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subnet_id` int(11) DEFAULT '0',
  `range_id` int(11) DEFAULT '0',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`),
  KEY `range_id` (`range_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipaddressv4`
--

LOCK TABLES `ipaddressv4` WRITE;
/*!40000 ALTER TABLE `ipaddressv4` DISABLE KEYS */;
INSERT INTO `ipaddressv4` VALUES (1,0,0,'192.168.168.1');
/*!40000 ALTER TABLE `ipaddressv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipaddressv6`
--

DROP TABLE IF EXISTS `ipaddressv6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipaddressv6` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subnet_id` int(11) DEFAULT '0',
  `range_id` int(11) DEFAULT '0',
  `ip_text` char(39) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_high` bigint(20) unsigned DEFAULT NULL,
  `ip_low` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`),
  KEY `range_id` (`range_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipaddressv6`
--

LOCK TABLES `ipaddressv6` WRITE;
/*!40000 ALTER TABLE `ipaddressv6` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipaddressv6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipblock`
--

DROP TABLE IF EXISTS `ipblock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipblock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `parent_org_id` int(11) DEFAULT '0',
  `write_reason` enum('expand','is_delete','none','parent_is_delete','shrink','split') COLLATE utf8_unicode_ci DEFAULT 'none',
  `occupancy` int(11) DEFAULT '0',
  `children_occupancy` int(11) DEFAULT '0',
  `subnet_occupancy` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_org_id` (`parent_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipblock`
--

LOCK TABLES `ipblock` WRITE;
/*!40000 ALTER TABLE `ipblock` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipblock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipblockv4`
--

DROP TABLE IF EXISTS `ipblockv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipblockv4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `parent_id_left` int(11) DEFAULT '0',
  `parent_id_right` int(11) DEFAULT '0',
  `firstip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `lastip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipblockv4`
--

LOCK TABLES `ipblockv4` WRITE;
/*!40000 ALTER TABLE `ipblockv4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipblockv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipblockv6`
--

DROP TABLE IF EXISTS `ipblockv6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipblockv6` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `parent_id_left` int(11) DEFAULT '0',
  `parent_id_right` int(11) DEFAULT '0',
  `firstip_text` char(39) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstip_high` bigint(20) unsigned DEFAULT NULL,
  `firstip_low` bigint(20) unsigned DEFAULT NULL,
  `lastip_text` char(39) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastip_high` bigint(20) unsigned DEFAULT NULL,
  `lastip_low` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipblockv6`
--

LOCK TABLES `ipblockv6` WRITE;
/*!40000 ALTER TABLE `ipblockv6` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipblockv6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipconfig`
--

DROP TABLE IF EXISTS `ipconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'IP Settings',
  `requestor_id` int(11) DEFAULT '0',
  `ipv4_block_min_size` int(11) DEFAULT '256',
  `ipv4_block_cidr_aligned` enum('bca_no','bca_yes') COLLATE utf8_unicode_ci DEFAULT 'bca_yes',
  `delegate_to_children_only` enum('dtc_no','dtc_yes') COLLATE utf8_unicode_ci DEFAULT 'dtc_yes',
  `reserve_subnet_IPs` enum('reserve_no','reserve_yes') COLLATE utf8_unicode_ci DEFAULT 'reserve_no',
  `ipv4_gateway_ip_format` enum('broadcastip_minus_1','free_setup','subnetip_plus_1') COLLATE utf8_unicode_ci DEFAULT 'subnetip_plus_1',
  `subnet_low_watermark` int(11) DEFAULT '60',
  `subnet_high_watermark` int(11) DEFAULT '80',
  `iprange_low_watermark` int(11) DEFAULT '60',
  `iprange_high_watermark` int(11) DEFAULT '80',
  `ip_allow_duplicate_name` enum('ipdup_no','ipdup_yes') COLLATE utf8_unicode_ci DEFAULT 'ipdup_no',
  `mac_address_format` enum('colons','dots','hyphens') COLLATE utf8_unicode_ci DEFAULT 'colons',
  `ping_before_assign` enum('ping_no','ping_yes') COLLATE utf8_unicode_ci DEFAULT 'ping_no',
  `ipv6_block_min_prefix` enum('48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64') COLLATE utf8_unicode_ci DEFAULT '64',
  `ipv6_block_cidr_aligned` enum('bca_no','bca_yes') COLLATE utf8_unicode_ci DEFAULT 'bca_yes',
  `ipv6_gateway_ip_format` enum('free_setup','lastip','subnetip_plus_1') COLLATE utf8_unicode_ci DEFAULT 'subnetip_plus_1',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `requestor_id` (`requestor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipconfig`
--

LOCK TABLES `ipconfig` WRITE;
/*!40000 ALTER TABLE `ipconfig` DISABLE KEYS */;
INSERT INTO `ipconfig` VALUES (1,3,'IP Settings',0,256,'bca_yes','dtc_yes','reserve_no','subnetip_plus_1',60,80,60,80,'ipdup_no','colons','ping_no','64','bca_yes','subnetip_plus_1');
/*!40000 ALTER TABLE `ipconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipinterface`
--

DROP TABLE IF EXISTS `ipinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `macaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci,
  `ipgateway` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ipmask` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `speed` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipinterface`
--

LOCK TABLES `ipinterface` WRITE;
/*!40000 ALTER TABLE `ipinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipobject`
--

DROP TABLE IF EXISTS `ipobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipobject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT '0',
  `status` enum('allocated','released','reserved','unassigned') COLLATE utf8_unicode_ci DEFAULT 'allocated',
  `comment` text COLLATE utf8_unicode_ci,
  `requestor_id` int(11) DEFAULT '0',
  `allocation_date` datetime DEFAULT NULL,
  `release_date` datetime DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'IPObject',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `requestor_id` (`requestor_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipobject`
--

LOCK TABLES `ipobject` WRITE;
/*!40000 ALTER TABLE `ipobject` DISABLE KEYS */;
INSERT INTO `ipobject` VALUES (1,3,'allocated','',0,'2016-06-30 04:23:48',NULL,'IPv4Address');
/*!40000 ALTER TABLE `ipobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipphone`
--

DROP TABLE IF EXISTS `ipphone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipphone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipphone`
--

LOCK TABLES `ipphone` WRITE;
/*!40000 ALTER TABLE `ipphone` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipphone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iprange`
--

DROP TABLE IF EXISTS `iprange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iprange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `usage_id` int(11) DEFAULT '0',
  `dhcp` enum('dhcp_no','dhcp_yes') COLLATE utf8_unicode_ci DEFAULT 'dhcp_no',
  `write_reason` enum('expand','is_delete','none','shrink','split') COLLATE utf8_unicode_ci DEFAULT 'none',
  `occupancy` int(11) DEFAULT '0',
  `alarm_water_mark` enum('high_sent','low_sent','no_alarm') COLLATE utf8_unicode_ci DEFAULT 'no_alarm',
  PRIMARY KEY (`id`),
  KEY `usage_id` (`usage_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iprange`
--

LOCK TABLES `iprange` WRITE;
/*!40000 ALTER TABLE `iprange` DISABLE KEYS */;
/*!40000 ALTER TABLE `iprange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iprangeusage`
--

DROP TABLE IF EXISTS `iprangeusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iprangeusage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT '0',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iprangeusage`
--

LOCK TABLES `iprangeusage` WRITE;
/*!40000 ALTER TABLE `iprangeusage` DISABLE KEYS */;
/*!40000 ALTER TABLE `iprangeusage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iprangev4`
--

DROP TABLE IF EXISTS `iprangev4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iprangev4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subnet_id` int(11) DEFAULT '0',
  `firstip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `lastip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iprangev4`
--

LOCK TABLES `iprangev4` WRITE;
/*!40000 ALTER TABLE `iprangev4` DISABLE KEYS */;
/*!40000 ALTER TABLE `iprangev4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iprangev6`
--

DROP TABLE IF EXISTS `iprangev6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iprangev6` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subnet_id` int(11) DEFAULT '0',
  `firstip_text` char(39) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstip_high` bigint(20) unsigned DEFAULT NULL,
  `firstip_low` bigint(20) unsigned DEFAULT NULL,
  `lastip_text` char(39) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastip_high` bigint(20) unsigned DEFAULT NULL,
  `lastip_low` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iprangev6`
--

LOCK TABLES `iprangev6` WRITE;
/*!40000 ALTER TABLE `iprangev6` DISABLE KEYS */;
/*!40000 ALTER TABLE `iprangev6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipsubnet`
--

DROP TABLE IF EXISTS `ipsubnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipsubnet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `write_reason` enum('expand','is_delete','none','shrink','split') COLLATE utf8_unicode_ci DEFAULT 'none',
  `ip_occupancy` int(11) DEFAULT '0',
  `range_occupancy` int(11) DEFAULT '0',
  `alarm_water_mark` enum('high_sent','low_sent','no_alarm') COLLATE utf8_unicode_ci DEFAULT 'no_alarm',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipsubnet`
--

LOCK TABLES `ipsubnet` WRITE;
/*!40000 ALTER TABLE `ipsubnet` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipsubnet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipsubnetv4`
--

DROP TABLE IF EXISTS `ipsubnetv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipsubnetv4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block_id` int(11) DEFAULT '0',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `mask` enum('255.255.0.0','255.255.128.0','255.255.192.0','255.255.224.0','255.255.240.0','255.255.248.0','255.255.252.0','255.255.254.0','255.255.255.0','255.255.255.128','255.255.255.192','255.255.255.224','255.255.255.240','255.255.255.248','255.255.255.252','255.255.255.254') COLLATE utf8_unicode_ci DEFAULT NULL,
  `gatewayip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `broadcastip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `block_id` (`block_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipsubnetv4`
--

LOCK TABLES `ipsubnetv4` WRITE;
/*!40000 ALTER TABLE `ipsubnetv4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipsubnetv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipsubnetv6`
--

DROP TABLE IF EXISTS `ipsubnetv6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipsubnetv6` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block_id` int(11) DEFAULT '0',
  `ip_text` char(39) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip_high` bigint(20) unsigned DEFAULT NULL,
  `ip_low` bigint(20) unsigned DEFAULT NULL,
  `mask` enum('64') COLLATE utf8_unicode_ci DEFAULT NULL,
  `gatewayip_text` char(39) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gatewayip_high` bigint(20) unsigned DEFAULT NULL,
  `gatewayip_low` bigint(20) unsigned DEFAULT NULL,
  `lastip_text` char(39) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastip_high` bigint(20) unsigned DEFAULT NULL,
  `lastip_low` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `block_id` (`block_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipsubnetv6`
--

LOCK TABLES `ipsubnetv6` WRITE;
/*!40000 ALTER TABLE `ipsubnetv6` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipsubnetv6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipusage`
--

DROP TABLE IF EXISTS `ipusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipusage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT '0',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipusage`
--

LOCK TABLES `ipusage` WRITE;
/*!40000 ALTER TABLE `ipusage` DISABLE KEYS */;
INSERT INTO `ipusage` VALUES (18,3,'mission interface'),(19,3,'Subnet IP'),(20,3,'Gateway IP'),(21,3,'');
/*!40000 ALTER TABLE `ipusage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knownerror`
--

DROP TABLE IF EXISTS `knownerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knownerror` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `cust_id` int(11) DEFAULT '0',
  `problem_id` int(11) DEFAULT '0',
  `symptom` text COLLATE utf8_unicode_ci,
  `rootcause` text COLLATE utf8_unicode_ci,
  `workaround` text COLLATE utf8_unicode_ci,
  `solution` text COLLATE utf8_unicode_ci,
  `error_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `domain` enum('Application','Desktop','Network','Server') COLLATE utf8_unicode_ci DEFAULT 'Application',
  `vendor` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cust_id` (`cust_id`),
  KEY `problem_id` (`problem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knownerror`
--

LOCK TABLES `knownerror` WRITE;
/*!40000 ALTER TABLE `knownerror` DISABLE KEYS */;
/*!40000 ALTER TABLE `knownerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licence`
--

DROP TABLE IF EXISTS `licence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `usage_limit` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `licence_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `perpetual` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT 'no',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Licence',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licence`
--

LOCK TABLES `licence` WRITE;
/*!40000 ALTER TABLE `licence` DISABLE KEYS */;
/*!40000 ALTER TABLE `licence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkapplicationsolutiontobusinessprocess`
--

DROP TABLE IF EXISTS `lnkapplicationsolutiontobusinessprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkapplicationsolutiontobusinessprocess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `businessprocess_id` int(11) DEFAULT '0',
  `applicationsolution_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `businessprocess_id` (`businessprocess_id`),
  KEY `applicationsolution_id` (`applicationsolution_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkapplicationsolutiontobusinessprocess`
--

LOCK TABLES `lnkapplicationsolutiontobusinessprocess` WRITE;
/*!40000 ALTER TABLE `lnkapplicationsolutiontobusinessprocess` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkapplicationsolutiontobusinessprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkapplicationsolutiontofunctionalci`
--

DROP TABLE IF EXISTS `lnkapplicationsolutiontofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkapplicationsolutiontofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `applicationsolution_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `applicationsolution_id` (`applicationsolution_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkapplicationsolutiontofunctionalci`
--

LOCK TABLES `lnkapplicationsolutiontofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkapplicationsolutiontofunctionalci` DISABLE KEYS */;
INSERT INTO `lnkapplicationsolutiontofunctionalci` VALUES (1,12,8),(2,13,29),(3,14,11),(4,14,12),(5,11,28),(6,11,31),(7,12,30),(8,13,27);
/*!40000 ALTER TABLE `lnkapplicationsolutiontofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkconnectablecitonetworkdevice`
--

DROP TABLE IF EXISTS `lnkconnectablecitonetworkdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkconnectablecitonetworkdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkdevice_id` int(11) DEFAULT '0',
  `connectableci_id` int(11) DEFAULT '0',
  `network_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `device_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `type` enum('downlink','uplink') COLLATE utf8_unicode_ci DEFAULT 'downlink',
  PRIMARY KEY (`id`),
  KEY `networkdevice_id` (`networkdevice_id`),
  KEY `connectableci_id` (`connectableci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkconnectablecitonetworkdevice`
--

LOCK TABLES `lnkconnectablecitonetworkdevice` WRITE;
/*!40000 ALTER TABLE `lnkconnectablecitonetworkdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkconnectablecitonetworkdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttocontract`
--

DROP TABLE IF EXISTS `lnkcontacttocontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttocontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `contract_id` (`contract_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttocontract`
--

LOCK TABLES `lnkcontacttocontract` WRITE;
/*!40000 ALTER TABLE `lnkcontacttocontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttocontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttofunctionalci`
--

DROP TABLE IF EXISTS `lnkcontacttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttofunctionalci`
--

LOCK TABLES `lnkcontacttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkcontacttofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoipobject`
--

DROP TABLE IF EXISTS `lnkcontacttoipobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttoipobject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipobject_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipobject_id` (`ipobject_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoipobject`
--

LOCK TABLES `lnkcontacttoipobject` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoipobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttoipobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoservice`
--

DROP TABLE IF EXISTS `lnkcontacttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoservice`
--

LOCK TABLES `lnkcontacttoservice` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoticket`
--

DROP TABLE IF EXISTS `lnkcontacttoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttoticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  `role` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `impact_code` enum('computed','do_not_notify','manual') COLLATE utf8_unicode_ci DEFAULT 'manual',
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoticket`
--

LOCK TABLES `lnkcontacttoticket` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontracttodocument`
--

DROP TABLE IF EXISTS `lnkcontracttodocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontracttodocument` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `contract_id` (`contract_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontracttodocument`
--

LOCK TABLES `lnkcontracttodocument` WRITE;
/*!40000 ALTER TABLE `lnkcontracttodocument` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontracttodocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttoservice`
--

DROP TABLE IF EXISTS `lnkcustomercontracttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcustomercontracttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customercontract_id` int(11) DEFAULT '0',
  `service_id` int(11) DEFAULT '0',
  `sla_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `service_id` (`service_id`),
  KEY `sla_id` (`sla_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttoservice`
--

LOCK TABLES `lnkcustomercontracttoservice` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttoservice` DISABLE KEYS */;
INSERT INTO `lnkcustomercontracttoservice` VALUES (1,1,1,1),(2,1,2,1),(3,1,3,1);
/*!40000 ALTER TABLE `lnkcustomercontracttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdatacenterdevicetosan`
--

DROP TABLE IF EXISTS `lnkdatacenterdevicetosan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdatacenterdevicetosan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `san_id` int(11) DEFAULT '0',
  `datacenterdevice_id` int(11) DEFAULT '0',
  `san_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `datacenterdevice_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `san_id` (`san_id`),
  KEY `datacenterdevice_id` (`datacenterdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdatacenterdevicetosan`
--

LOCK TABLES `lnkdatacenterdevicetosan` WRITE;
/*!40000 ALTER TABLE `lnkdatacenterdevicetosan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdatacenterdevicetosan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdeliverymodeltocontact`
--

DROP TABLE IF EXISTS `lnkdeliverymodeltocontact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdeliverymodeltocontact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deliverymodel_id` int(11) DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  `role_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `deliverymodel_id` (`deliverymodel_id`),
  KEY `contact_id` (`contact_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdeliverymodeltocontact`
--

LOCK TABLES `lnkdeliverymodeltocontact` WRITE;
/*!40000 ALTER TABLE `lnkdeliverymodeltocontact` DISABLE KEYS */;
INSERT INTO `lnkdeliverymodeltocontact` VALUES (1,1,8,17),(2,1,17,16),(3,1,15,17);
/*!40000 ALTER TABLE `lnkdeliverymodeltocontact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdoctoipobject`
--

DROP TABLE IF EXISTS `lnkdoctoipobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdoctoipobject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipobject_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipobject_id` (`ipobject_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdoctoipobject`
--

LOCK TABLES `lnkdoctoipobject` WRITE;
/*!40000 ALTER TABLE `lnkdoctoipobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdoctoipobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttoerror`
--

DROP TABLE IF EXISTS `lnkdocumenttoerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttoerror` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) DEFAULT '0',
  `error_id` int(11) DEFAULT '0',
  `link_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `document_id` (`document_id`),
  KEY `error_id` (`error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttoerror`
--

LOCK TABLES `lnkdocumenttoerror` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttoerror` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttoerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttofunctionalci`
--

DROP TABLE IF EXISTS `lnkdocumenttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttofunctionalci`
--

LOCK TABLES `lnkdocumenttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttolicence`
--

DROP TABLE IF EXISTS `lnkdocumenttolicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttolicence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `licence_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `licence_id` (`licence_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttolicence`
--

LOCK TABLES `lnkdocumenttolicence` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttolicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttolicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttopatch`
--

DROP TABLE IF EXISTS `lnkdocumenttopatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttopatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patch_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `patch_id` (`patch_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttopatch`
--

LOCK TABLES `lnkdocumenttopatch` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttopatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttopatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttoservice`
--

DROP TABLE IF EXISTS `lnkdocumenttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttoservice`
--

LOCK TABLES `lnkdocumenttoservice` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttosoftware`
--

DROP TABLE IF EXISTS `lnkdocumenttosoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttosoftware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT '0',
  `document_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttosoftware`
--

LOCK TABLES `lnkdocumenttosoftware` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttosoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttosoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkerrortofunctionalci`
--

DROP TABLE IF EXISTS `lnkerrortofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkerrortofunctionalci` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) DEFAULT '0',
  `error_id` int(11) DEFAULT '0',
  `dummy` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `error_id` (`error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkerrortofunctionalci`
--

LOCK TABLES `lnkerrortofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkerrortofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkerrortofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoospatch`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoospatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoospatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ospatch_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ospatch_id` (`ospatch_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoospatch`
--

LOCK TABLES `lnkfunctionalcitoospatch` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoospatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoospatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoprovidercontract`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoprovidercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoprovidercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `providercontract_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `providercontract_id` (`providercontract_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoprovidercontract`
--

LOCK TABLES `lnkfunctionalcitoprovidercontract` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoprovidercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoprovidercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoservice`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoservice`
--

LOCK TABLES `lnkfunctionalcitoservice` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoticket`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT '0',
  `functionalci_id` int(11) DEFAULT '0',
  `impact` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `impact_code` enum('computed','manual','not_impacted') COLLATE utf8_unicode_ci DEFAULT 'manual',
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoticket`
--

LOCK TABLES `lnkfunctionalcitoticket` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkgrouptoci`
--

DROP TABLE IF EXISTS `lnkgrouptoci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkgrouptoci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT '0',
  `ci_id` int(11) DEFAULT '0',
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `ci_id` (`ci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkgrouptoci`
--

LOCK TABLES `lnkgrouptoci` WRITE;
/*!40000 ALTER TABLE `lnkgrouptoci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkgrouptoci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipaddresstoipaddress`
--

DROP TABLE IF EXISTS `lnkipaddresstoipaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkipaddresstoipaddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip1_id` int(11) DEFAULT '0',
  `ip2_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ip1_id` (`ip1_id`),
  KEY `ip2_id` (`ip2_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipaddresstoipaddress`
--

LOCK TABLES `lnkipaddresstoipaddress` WRITE;
/*!40000 ALTER TABLE `lnkipaddresstoipaddress` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipaddresstoipaddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipblocktolocation`
--

DROP TABLE IF EXISTS `lnkipblocktolocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkipblocktolocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipblock_id` int(11) DEFAULT '0',
  `location_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipblock_id` (`ipblock_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipblocktolocation`
--

LOCK TABLES `lnkipblocktolocation` WRITE;
/*!40000 ALTER TABLE `lnkipblocktolocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipblocktolocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipinterfacetoipaddress`
--

DROP TABLE IF EXISTS `lnkipinterfacetoipaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkipinterfacetoipaddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipinterface_id` int(11) DEFAULT '0',
  `ipaddress_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipinterface_id` (`ipinterface_id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipinterfacetoipaddress`
--

LOCK TABLES `lnkipinterfacetoipaddress` WRITE;
/*!40000 ALTER TABLE `lnkipinterfacetoipaddress` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipinterfacetoipaddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipobjecttoticket`
--

DROP TABLE IF EXISTS `lnkipobjecttoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkipobjecttoticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipobject_id` int(11) DEFAULT '0',
  `ticket_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipobject_id` (`ipobject_id`),
  KEY `ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipobjecttoticket`
--

LOCK TABLES `lnkipobjecttoticket` WRITE;
/*!40000 ALTER TABLE `lnkipobjecttoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipobjecttoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipsubnettolocation`
--

DROP TABLE IF EXISTS `lnkipsubnettolocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkipsubnettolocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipsubnet_id` int(11) DEFAULT '0',
  `location_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipsubnet_id` (`ipsubnet_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipsubnettolocation`
--

LOCK TABLES `lnkipsubnettolocation` WRITE;
/*!40000 ALTER TABLE `lnkipsubnettolocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipsubnettolocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipsubnettovlan`
--

DROP TABLE IF EXISTS `lnkipsubnettovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkipsubnettovlan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipsubnet_id` int(11) DEFAULT '0',
  `vlan_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipsubnet_id` (`ipsubnet_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipsubnettovlan`
--

LOCK TABLES `lnkipsubnettovlan` WRITE;
/*!40000 ALTER TABLE `lnkipsubnettovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipsubnettovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkipsubnettovrf`
--

DROP TABLE IF EXISTS `lnkipsubnettovrf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkipsubnettovrf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipsubnet_id` int(11) DEFAULT '0',
  `vrf_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipsubnet_id` (`ipsubnet_id`),
  KEY `vrf_id` (`vrf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkipsubnettovrf`
--

LOCK TABLES `lnkipsubnettovrf` WRITE;
/*!40000 ALTER TABLE `lnkipsubnettovrf` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkipsubnettovrf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkpersontoteam`
--

DROP TABLE IF EXISTS `lnkpersontoteam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkpersontoteam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT '0',
  `person_id` int(11) DEFAULT '0',
  `role_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `team_id` (`team_id`),
  KEY `person_id` (`person_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkpersontoteam`
--

LOCK TABLES `lnkpersontoteam` WRITE;
/*!40000 ALTER TABLE `lnkpersontoteam` DISABLE KEYS */;
INSERT INTO `lnkpersontoteam` VALUES (1,17,9,0),(2,17,8,0),(3,15,9,0),(4,15,10,0),(5,15,13,0),(6,14,5,0),(7,14,2,0),(8,16,6,0),(9,16,7,0);
/*!40000 ALTER TABLE `lnkpersontoteam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkphysicalinterfacetovlan`
--

DROP TABLE IF EXISTS `lnkphysicalinterfacetovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkphysicalinterfacetovlan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `physicalinterface_id` int(11) DEFAULT '0',
  `vlan_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `physicalinterface_id` (`physicalinterface_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkphysicalinterfacetovlan`
--

LOCK TABLES `lnkphysicalinterfacetovlan` WRITE;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkphysicalinterfacetovrf`
--

DROP TABLE IF EXISTS `lnkphysicalinterfacetovrf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkphysicalinterfacetovrf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `physicalinterface_id` int(11) DEFAULT '0',
  `vrf_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `physicalinterface_id` (`physicalinterface_id`),
  KEY `vrf_id` (`vrf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkphysicalinterfacetovrf`
--

LOCK TABLES `lnkphysicalinterfacetovrf` WRITE;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovrf` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovrf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkprovidercontracttoservice`
--

DROP TABLE IF EXISTS `lnkprovidercontracttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkprovidercontracttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) DEFAULT '0',
  `providercontract_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `providercontract_id` (`providercontract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkprovidercontracttoservice`
--

LOCK TABLES `lnkprovidercontracttoservice` WRITE;
/*!40000 ALTER TABLE `lnkprovidercontracttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkprovidercontracttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkservertovolume`
--

DROP TABLE IF EXISTS `lnkservertovolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkservertovolume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` int(11) DEFAULT '0',
  `server_id` int(11) DEFAULT '0',
  `size_used` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `volume_id` (`volume_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkservertovolume`
--

LOCK TABLES `lnkservertovolume` WRITE;
/*!40000 ALTER TABLE `lnkservertovolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkservertovolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkslatoslt`
--

DROP TABLE IF EXISTS `lnkslatoslt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkslatoslt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sla_id` int(11) DEFAULT '0',
  `slt_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sla_id` (`sla_id`),
  KEY `slt_id` (`slt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkslatoslt`
--

LOCK TABLES `lnkslatoslt` WRITE;
/*!40000 ALTER TABLE `lnkslatoslt` DISABLE KEYS */;
INSERT INTO `lnkslatoslt` VALUES (1,1,1),(2,1,2);
/*!40000 ALTER TABLE `lnkslatoslt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnksoftwareinstancetosoftwarepatch`
--

DROP TABLE IF EXISTS `lnksoftwareinstancetosoftwarepatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnksoftwareinstancetosoftwarepatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `softwarepatch_id` int(11) DEFAULT '0',
  `softwareinstance_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `softwarepatch_id` (`softwarepatch_id`),
  KEY `softwareinstance_id` (`softwareinstance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnksoftwareinstancetosoftwarepatch`
--

LOCK TABLES `lnksoftwareinstancetosoftwarepatch` WRITE;
/*!40000 ALTER TABLE `lnksoftwareinstancetosoftwarepatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnksoftwareinstancetosoftwarepatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnksubnettovlan`
--

DROP TABLE IF EXISTS `lnksubnettovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnksubnettovlan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subnet_id` int(11) DEFAULT '0',
  `vlan_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnksubnettovlan`
--

LOCK TABLES `lnksubnettovlan` WRITE;
/*!40000 ALTER TABLE `lnksubnettovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnksubnettovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkvirtualdevicetovolume`
--

DROP TABLE IF EXISTS `lnkvirtualdevicetovolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkvirtualdevicetovolume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` int(11) DEFAULT '0',
  `virtualdevice_id` int(11) DEFAULT '0',
  `size_used` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `volume_id` (`volume_id`),
  KEY `virtualdevice_id` (`virtualdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkvirtualdevicetovolume`
--

LOCK TABLES `lnkvirtualdevicetovolume` WRITE;
/*!40000 ALTER TABLE `lnkvirtualdevicetovolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkvirtualdevicetovolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT 'active',
  `org_id` int(11) DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postal_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'Bordeaux','active',3,'','','',''),(2,'Grenoble','active',3,'24, rue Lamartine','38320','Eybens','France'),(3,'Paris','active',3,'5, rue du Sentier','75002','Paris','France');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logicalinterface`
--

DROP TABLE IF EXISTS `logicalinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logicalinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `virtualmachine_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `virtualmachine_id` (`virtualmachine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logicalinterface`
--

LOCK TABLES `logicalinterface` WRITE;
/*!40000 ALTER TABLE `logicalinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `logicalinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logicalvolume`
--

DROP TABLE IF EXISTS `logicalvolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logicalvolume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `lun_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `raid_level` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `storagesystem_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `storagesystem_id` (`storagesystem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logicalvolume`
--

LOCK TABLES `logicalvolume` WRITE;
/*!40000 ALTER TABLE `logicalvolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `logicalvolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `middleware`
--

DROP TABLE IF EXISTS `middleware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `middleware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middleware`
--

LOCK TABLES `middleware` WRITE;
/*!40000 ALTER TABLE `middleware` DISABLE KEYS */;
/*!40000 ALTER TABLE `middleware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `middlewareinstance`
--

DROP TABLE IF EXISTS `middlewareinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `middlewareinstance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `middleware_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `middleware_id` (`middleware_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middlewareinstance`
--

LOCK TABLES `middlewareinstance` WRITE;
/*!40000 ALTER TABLE `middlewareinstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `middlewareinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobilephone`
--

DROP TABLE IF EXISTS `mobilephone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobilephone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imei` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `hw_pin` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ipaddress_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobilephone`
--

LOCK TABLES `mobilephone` WRITE;
/*!40000 ALTER TABLE `mobilephone` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobilephone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model`
--

DROP TABLE IF EXISTS `model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT '0',
  `type` enum('DiskArray','Enclosure','IPPhone','MobilePhone','NAS','NetworkDevice','PC','PDU','Peripheral','Phone','PowerSource','Printer','Rack','SANSwitch','Server','StorageSystem','Tablet','TapeLibrary') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model`
--

LOCK TABLES `model` WRITE;
/*!40000 ALTER TABLE `model` DISABLE KEYS */;
INSERT INTO `model` VALUES (3,1,'NetworkDevice'),(4,2,'Server'),(5,2,'NetworkDevice');
/*!40000 ALTER TABLE `model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nasfilesystem`
--

DROP TABLE IF EXISTS `nasfilesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nasfilesystem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `raid_level` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `nas_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `nas_id` (`nas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nasfilesystem`
--

LOCK TABLES `nasfilesystem` WRITE;
/*!40000 ALTER TABLE `nasfilesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `nasfilesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevice`
--

DROP TABLE IF EXISTS `networkdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkdevicetype_id` int(11) DEFAULT '0',
  `iosversion_id` int(11) DEFAULT '0',
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `networkdevicetype_id` (`networkdevicetype_id`),
  KEY `iosversion_id` (`iosversion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevice`
--

LOCK TABLES `networkdevice` WRITE;
/*!40000 ALTER TABLE `networkdevice` DISABLE KEYS */;
INSERT INTO `networkdevice` VALUES (5,10,0,''),(6,11,0,'');
/*!40000 ALTER TABLE `networkdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevicetype`
--

DROP TABLE IF EXISTS `networkdevicetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkdevicetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevicetype`
--

LOCK TABLES `networkdevicetype` WRITE;
/*!40000 ALTER TABLE `networkdevicetype` DISABLE KEYS */;
INSERT INTO `networkdevicetype` VALUES (10),(11);
/*!40000 ALTER TABLE `networkdevicetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkinterface`
--

DROP TABLE IF EXISTS `networkinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'NetworkInterface',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkinterface`
--

LOCK TABLES `networkinterface` WRITE;
/*!40000 ALTER TABLE `networkinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT 'active',
  `parent_id` int(11) DEFAULT '0',
  `parent_id_left` int(11) DEFAULT '0',
  `parent_id_right` int(11) DEFAULT '0',
  `deliverymodel_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`),
  KEY `deliverymodel_id` (`deliverymodel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES (1,'My Company/Department','SOMECODE','active',0,1,2,0),(2,'IT Department','IT','active',0,3,4,0),(3,'Demo','','active',0,5,6,1);
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `osfamily`
--

DROP TABLE IF EXISTS `osfamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `osfamily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `osfamily`
--

LOCK TABLES `osfamily` WRITE;
/*!40000 ALTER TABLE `osfamily` DISABLE KEYS */;
INSERT INTO `osfamily` VALUES (6),(7);
/*!40000 ALTER TABLE `osfamily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oslicence`
--

DROP TABLE IF EXISTS `oslicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oslicence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osversion_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oslicence`
--

LOCK TABLES `oslicence` WRITE;
/*!40000 ALTER TABLE `oslicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `oslicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospatch`
--

DROP TABLE IF EXISTS `ospatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ospatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osversion_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospatch`
--

LOCK TABLES `ospatch` WRITE;
/*!40000 ALTER TABLE `ospatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `osversion`
--

DROP TABLE IF EXISTS `osversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `osversion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osfamily_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `osversion`
--

LOCK TABLES `osversion` WRITE;
/*!40000 ALTER TABLE `osversion` DISABLE KEYS */;
INSERT INTO `osversion` VALUES (8,6),(9,7);
/*!40000 ALTER TABLE `osversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `othersoftware`
--

DROP TABLE IF EXISTS `othersoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `othersoftware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `othersoftware`
--

LOCK TABLES `othersoftware` WRITE;
/*!40000 ALTER TABLE `othersoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `othersoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patch`
--

DROP TABLE IF EXISTS `patch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Patch',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patch`
--

LOCK TABLES `patch` WRITE;
/*!40000 ALTER TABLE `patch` DISABLE KEYS */;
/*!40000 ALTER TABLE `patch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pc`
--

DROP TABLE IF EXISTS `pc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osfamily_id` int(11) DEFAULT '0',
  `osversion_id` int(11) DEFAULT '0',
  `cpu` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `type` enum('desktop','laptop') COLLATE utf8_unicode_ci DEFAULT NULL,
  `ipaddress_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pc`
--

LOCK TABLES `pc` WRITE;
/*!40000 ALTER TABLE `pc` DISABLE KEYS */;
/*!40000 ALTER TABLE `pc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pcsoftware`
--

DROP TABLE IF EXISTS `pcsoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pcsoftware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pcsoftware`
--

LOCK TABLES `pcsoftware` WRITE;
/*!40000 ALTER TABLE `pcsoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `pcsoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdu`
--

DROP TABLE IF EXISTS `pdu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rack_id` int(11) DEFAULT '0',
  `powerstart_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `powerstart_id` (`powerstart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdu`
--

LOCK TABLES `pdu` WRITE;
/*!40000 ALTER TABLE `pdu` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peripheral`
--

DROP TABLE IF EXISTS `peripheral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `peripheral` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peripheral`
--

LOCK TABLES `peripheral` WRITE;
/*!40000 ALTER TABLE `peripheral` DISABLE KEYS */;
/*!40000 ALTER TABLE `peripheral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `employee_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `mobile_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `location_id` int(11) DEFAULT '0',
  `manager_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `manager_id` (`manager_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,'My first name','','',0,0),(2,'Anna','','',0,0),(3,'Claude','','',0,0),(4,'Eugene','','',0,0),(5,'Gustave','','',0,0),(6,'Jean','','',0,0),(7,'Jean-Jacques','','',0,0),(8,'Jean-Paul','','',0,0),(9,'Jules','','',0,0),(10,'Marguerite','','',0,0),(11,'Pablo','','',2,0),(12,'Salvador','','',2,0),(13,'Victor','','',0,0);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone`
--

DROP TABLE IF EXISTS `phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone`
--

LOCK TABLES `phone` WRITE;
/*!40000 ALTER TABLE `phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicaldevice`
--

DROP TABLE IF EXISTS `physicaldevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physicaldevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serialnumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `location_id` int(11) DEFAULT '0',
  `status` enum('implementation','obsolete','production','stock') COLLATE utf8_unicode_ci DEFAULT 'production',
  `brand_id` int(11) DEFAULT '0',
  `model_id` int(11) DEFAULT '0',
  `asset_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `purchase_date` date DEFAULT NULL,
  `end_of_warranty` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `brand_id` (`brand_id`),
  KEY `model_id` (`model_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicaldevice`
--

LOCK TABLES `physicaldevice` WRITE;
/*!40000 ALTER TABLE `physicaldevice` DISABLE KEYS */;
INSERT INTO `physicaldevice` VALUES (1,'',1,'production',2,4,'',NULL,NULL),(2,'',2,'production',0,0,'',NULL,NULL),(3,'',0,'production',2,4,'',NULL,NULL),(4,'US3215687014',0,'production',2,4,'','2011-05-22','2013-05-21'),(5,'',1,'production',1,0,'',NULL,NULL),(6,'',2,'production',2,5,'',NULL,NULL),(15,'',2,'production',0,0,'',NULL,NULL);
/*!40000 ALTER TABLE `physicaldevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicalinterface`
--

DROP TABLE IF EXISTS `physicalinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physicalinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `connectableci_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `connectableci_id` (`connectableci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicalinterface`
--

LOCK TABLES `physicalinterface` WRITE;
/*!40000 ALTER TABLE `physicalinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `physicalinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powerconnection`
--

DROP TABLE IF EXISTS `powerconnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powerconnection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powerconnection`
--

LOCK TABLES `powerconnection` WRITE;
/*!40000 ALTER TABLE `powerconnection` DISABLE KEYS */;
/*!40000 ALTER TABLE `powerconnection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powersource`
--

DROP TABLE IF EXISTS `powersource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powersource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powersource`
--

LOCK TABLES `powersource` WRITE;
/*!40000 ALTER TABLE `powersource` DISABLE KEYS */;
/*!40000 ALTER TABLE `powersource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printer`
--

DROP TABLE IF EXISTS `printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printer`
--

LOCK TABLES `printer` WRITE;
/*!40000 ALTER TABLE `printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action`
--

DROP TABLE IF EXISTS `priv_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('test','enabled','disabled') COLLATE utf8_unicode_ci DEFAULT 'test',
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Action',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action`
--

LOCK TABLES `priv_action` WRITE;
/*!40000 ALTER TABLE `priv_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_email`
--

DROP TABLE IF EXISTS `priv_action_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_action_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_recipient` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `from` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `reply_to` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `to` text COLLATE utf8_unicode_ci,
  `cc` text COLLATE utf8_unicode_ci,
  `bcc` text COLLATE utf8_unicode_ci,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `body` text COLLATE utf8_unicode_ci,
  `importance` enum('high','low','normal') COLLATE utf8_unicode_ci DEFAULT 'normal',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_email`
--

LOCK TABLES `priv_action_email` WRITE;
/*!40000 ALTER TABLE `priv_action_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_notification`
--

DROP TABLE IF EXISTS `priv_action_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_action_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_notification`
--

LOCK TABLES `priv_action_notification` WRITE;
/*!40000 ALTER TABLE `priv_action_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_app_dashboards`
--

DROP TABLE IF EXISTS `priv_app_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_app_dashboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `menu_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `contents` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_app_dashboards`
--

LOCK TABLES `priv_app_dashboards` WRITE;
/*!40000 ALTER TABLE `priv_app_dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_app_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_app_preferences`
--

DROP TABLE IF EXISTS `priv_app_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_app_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT '0',
  `preferences` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_app_preferences`
--

LOCK TABLES `priv_app_preferences` WRITE;
/*!40000 ALTER TABLE `priv_app_preferences` DISABLE KEYS */;
INSERT INTO `priv_app_preferences` VALUES (1,1,'a:1:{s:13:\"welcome_popup\";s:1:\"0\";}');
/*!40000 ALTER TABLE `priv_app_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_send_email`
--

DROP TABLE IF EXISTS `priv_async_send_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_async_send_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` int(11) DEFAULT '1',
  `to` text COLLATE utf8_unicode_ci,
  `subject` text COLLATE utf8_unicode_ci,
  `message` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_send_email`
--

LOCK TABLES `priv_async_send_email` WRITE;
/*!40000 ALTER TABLE `priv_async_send_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_send_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_task`
--

DROP TABLE IF EXISTS `priv_async_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_async_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('error','idle','planned','running') COLLATE utf8_unicode_ci DEFAULT 'planned',
  `created` datetime DEFAULT NULL,
  `started` datetime DEFAULT NULL,
  `planned` datetime DEFAULT NULL,
  `event_id` int(11) DEFAULT '0',
  `remaining_retries` int(11) DEFAULT '0',
  `last_error_code` int(11) DEFAULT '0',
  `last_error` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `last_attempt` datetime DEFAULT NULL,
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'AsyncTask',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_task`
--

LOCK TABLES `priv_async_task` WRITE;
/*!40000 ALTER TABLE `priv_async_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditcategory`
--

DROP TABLE IF EXISTS `priv_auditcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_auditcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `definition_set` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditcategory`
--

LOCK TABLES `priv_auditcategory` WRITE;
/*!40000 ALTER TABLE `priv_auditcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditrule`
--

DROP TABLE IF EXISTS `priv_auditrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_auditrule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `query` text COLLATE utf8_unicode_ci,
  `valid_flag` enum('false','true') COLLATE utf8_unicode_ci DEFAULT 'true',
  `category_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditrule`
--

LOCK TABLES `priv_auditrule` WRITE;
/*!40000 ALTER TABLE `priv_auditrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_backgroundtask`
--

DROP TABLE IF EXISTS `priv_backgroundtask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_backgroundtask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `first_run_date` datetime DEFAULT NULL,
  `latest_run_date` datetime DEFAULT NULL,
  `next_run_date` datetime DEFAULT NULL,
  `total_exec_count` int(11) DEFAULT '0',
  `latest_run_duration` decimal(8,3) DEFAULT '0.000',
  `min_run_duration` decimal(8,3) DEFAULT '0.000',
  `max_run_duration` decimal(8,3) DEFAULT '0.000',
  `average_run_duration` decimal(8,3) DEFAULT '0.000',
  `running` tinyint(1) DEFAULT '0',
  `status` enum('active','paused') COLLATE utf8_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_backgroundtask`
--

LOCK TABLES `priv_backgroundtask` WRITE;
/*!40000 ALTER TABLE `priv_backgroundtask` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_backgroundtask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_bulk_export_result`
--

DROP TABLE IF EXISTS `priv_bulk_export_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_bulk_export_result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `chunk_size` int(11) DEFAULT '0',
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `temp_file_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `search` longtext COLLATE utf8_unicode_ci,
  `status_info` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_bulk_export_result`
--

LOCK TABLES `priv_bulk_export_result` WRITE;
/*!40000 ALTER TABLE `priv_bulk_export_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_bulk_export_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_change`
--

DROP TABLE IF EXISTS `priv_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `origin` enum('csv-import.php','csv-interactive','custom-extension','email-processing','interactive','synchro-data-source','webservice-rest','webservice-soap') COLLATE utf8_unicode_ci DEFAULT 'interactive',
  PRIMARY KEY (`id`),
  KEY `origin` (`origin`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_change`
--

LOCK TABLES `priv_change` WRITE;
/*!40000 ALTER TABLE `priv_change` DISABLE KEYS */;
INSERT INTO `priv_change` VALUES (1,'2016-06-30 03:55:57','','interactive'),(2,'2016-06-30 03:55:59','Initialization','interactive'),(3,'2016-06-30 03:56:12','','interactive'),(4,'2016-06-30 04:20:48','','interactive'),(5,'2016-06-30 04:20:49','Initialization','interactive'),(6,'2016-06-30 04:20:50','','interactive'),(7,'2016-06-30 04:22:18','My first name My last name','interactive'),(8,'2016-06-30 04:23:47','My first name My last name','interactive');
/*!40000 ALTER TABLE `priv_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop`
--

DROP TABLE IF EXISTS `priv_changeop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changeid` int(11) DEFAULT '0',
  `objclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `objkey` int(11) DEFAULT '0',
  `optype` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'CMDBChangeOp',
  PRIMARY KEY (`id`),
  KEY `changeid` (`changeid`),
  KEY `optype` (`optype`),
  KEY `objclass_objkey` (`objclass`,`objkey`)
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop`
--

LOCK TABLES `priv_changeop` WRITE;
/*!40000 ALTER TABLE `priv_changeop` DISABLE KEYS */;
INSERT INTO `priv_changeop` VALUES (1,1,'URP_Profiles',1,'CMDBChangeOpCreate'),(2,1,'URP_Profiles',3,'CMDBChangeOpCreate'),(3,1,'URP_Profiles',4,'CMDBChangeOpCreate'),(4,1,'URP_Profiles',5,'CMDBChangeOpCreate'),(5,1,'URP_Profiles',6,'CMDBChangeOpCreate'),(6,1,'URP_Profiles',7,'CMDBChangeOpCreate'),(7,1,'URP_Profiles',8,'CMDBChangeOpCreate'),(8,1,'URP_Profiles',9,'CMDBChangeOpCreate'),(9,1,'URP_Profiles',10,'CMDBChangeOpCreate'),(10,1,'URP_Profiles',11,'CMDBChangeOpCreate'),(11,1,'URP_Profiles',2,'CMDBChangeOpCreate'),(12,1,'URP_Profiles',12,'CMDBChangeOpCreate'),(13,1,'Organization',1,'CMDBChangeOpCreate'),(14,1,'Person',1,'CMDBChangeOpCreate'),(16,1,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(17,1,'URP_UserProfile',1,'CMDBChangeOpCreate'),(18,1,'UserLocal',1,'CMDBChangeOpCreate'),(19,2,'Organization',2,'CMDBChangeOpCreate'),(20,2,'Organization',3,'CMDBChangeOpCreate'),(21,2,'Brand',1,'CMDBChangeOpCreate'),(22,2,'Brand',2,'CMDBChangeOpCreate'),(23,2,'Model',3,'CMDBChangeOpCreate'),(24,2,'Model',4,'CMDBChangeOpCreate'),(25,2,'Model',5,'CMDBChangeOpCreate'),(26,2,'OSFamily',6,'CMDBChangeOpCreate'),(27,2,'OSFamily',7,'CMDBChangeOpCreate'),(28,2,'OSVersion',8,'CMDBChangeOpCreate'),(29,2,'OSVersion',9,'CMDBChangeOpCreate'),(30,2,'NetworkDeviceType',10,'CMDBChangeOpCreate'),(31,2,'NetworkDeviceType',11,'CMDBChangeOpCreate'),(32,2,'ContactType',12,'CMDBChangeOpCreate'),(33,2,'ContactType',13,'CMDBChangeOpCreate'),(34,2,'ContactType',14,'CMDBChangeOpCreate'),(35,2,'ContactType',15,'CMDBChangeOpCreate'),(36,2,'ContactType',16,'CMDBChangeOpCreate'),(37,2,'ContactType',17,'CMDBChangeOpCreate'),(38,2,'Location',1,'CMDBChangeOpCreate'),(39,2,'Location',2,'CMDBChangeOpCreate'),(40,2,'Location',3,'CMDBChangeOpCreate'),(41,2,'Person',2,'CMDBChangeOpCreate'),(42,2,'Person',3,'CMDBChangeOpCreate'),(43,2,'Person',4,'CMDBChangeOpCreate'),(44,2,'Person',5,'CMDBChangeOpCreate'),(45,2,'Person',6,'CMDBChangeOpCreate'),(46,2,'Person',7,'CMDBChangeOpCreate'),(47,2,'Person',8,'CMDBChangeOpCreate'),(48,2,'Person',9,'CMDBChangeOpCreate'),(49,2,'Person',10,'CMDBChangeOpCreate'),(50,2,'Location',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(51,2,'Person',11,'CMDBChangeOpCreate'),(52,2,'Location',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(53,2,'Person',12,'CMDBChangeOpCreate'),(54,2,'Person',13,'CMDBChangeOpCreate'),(55,2,'Team',14,'CMDBChangeOpCreate'),(56,2,'Team',15,'CMDBChangeOpCreate'),(57,2,'Team',16,'CMDBChangeOpCreate'),(58,2,'Team',17,'CMDBChangeOpCreate'),(59,2,'Team',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(60,2,'Person',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(61,2,'lnkPersonToTeam',1,'CMDBChangeOpCreate'),(62,2,'Team',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(63,2,'Person',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(64,2,'lnkPersonToTeam',2,'CMDBChangeOpCreate'),(65,2,'Team',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(66,2,'Person',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(67,2,'lnkPersonToTeam',3,'CMDBChangeOpCreate'),(68,2,'Team',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(69,2,'Person',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(70,2,'lnkPersonToTeam',4,'CMDBChangeOpCreate'),(71,2,'Team',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(72,2,'Person',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(73,2,'lnkPersonToTeam',5,'CMDBChangeOpCreate'),(74,2,'Team',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(75,2,'Person',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(76,2,'lnkPersonToTeam',6,'CMDBChangeOpCreate'),(77,2,'Team',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(78,2,'Person',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(79,2,'lnkPersonToTeam',7,'CMDBChangeOpCreate'),(80,2,'Team',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(81,2,'Person',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(82,2,'lnkPersonToTeam',8,'CMDBChangeOpCreate'),(83,2,'Team',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(84,2,'Person',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(85,2,'lnkPersonToTeam',9,'CMDBChangeOpCreate'),(86,2,'Location',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(87,2,'Brand',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(88,2,'Model',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(89,2,'Server',1,'CMDBChangeOpCreate'),(90,2,'Location',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(91,2,'Server',2,'CMDBChangeOpCreate'),(92,2,'Brand',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(93,2,'Model',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(94,2,'Server',3,'CMDBChangeOpCreate'),(95,2,'Brand',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(96,2,'Model',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(97,2,'Server',4,'CMDBChangeOpCreate'),(98,2,'Location',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(99,2,'Brand',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(100,2,'NetworkDeviceType',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(101,2,'NetworkDevice',5,'CMDBChangeOpCreate'),(102,2,'Location',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(103,2,'Brand',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(104,2,'Model',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(105,2,'NetworkDeviceType',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(106,2,'NetworkDevice',6,'CMDBChangeOpCreate'),(107,2,'Software',1,'CMDBChangeOpCreate'),(108,2,'Software',2,'CMDBChangeOpCreate'),(109,2,'Server',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(110,2,'Software',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(111,2,'DBServer',7,'CMDBChangeOpCreate'),(112,2,'DBServer',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(113,2,'DatabaseSchema',8,'CMDBChangeOpCreate'),(114,2,'Server',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(115,2,'WebServer',9,'CMDBChangeOpCreate'),(116,2,'WebServer',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(117,2,'WebApplication',10,'CMDBChangeOpCreate'),(118,2,'ApplicationSolution',11,'CMDBChangeOpCreate'),(119,2,'ApplicationSolution',12,'CMDBChangeOpCreate'),(120,2,'ApplicationSolution',13,'CMDBChangeOpCreate'),(121,2,'ApplicationSolution',14,'CMDBChangeOpCreate'),(122,2,'ApplicationSolution',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(123,2,'DatabaseSchema',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(124,2,'lnkApplicationSolutionToFunctionalCI',1,'CMDBChangeOpCreate'),(125,2,'ApplicationSolution',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(126,2,'Server',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(127,2,'lnkApplicationSolutionToFunctionalCI',2,'CMDBChangeOpCreate'),(128,2,'ApplicationSolution',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(129,2,'ApplicationSolution',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(130,2,'lnkApplicationSolutionToFunctionalCI',3,'CMDBChangeOpCreate'),(131,2,'ApplicationSolution',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(132,2,'ApplicationSolution',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(133,2,'lnkApplicationSolutionToFunctionalCI',4,'CMDBChangeOpCreate'),(134,2,'Location',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(135,2,'Rack',15,'CMDBChangeOpCreate'),(136,2,'Farm',16,'CMDBChangeOpCreate'),(137,2,'Farm',17,'CMDBChangeOpCreate'),(138,2,'Farm',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(139,2,'Hypervisor',18,'CMDBChangeOpCreate'),(140,2,'Farm',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(141,2,'Hypervisor',19,'CMDBChangeOpCreate'),(142,2,'Farm',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(143,2,'Hypervisor',20,'CMDBChangeOpCreate'),(144,2,'Farm',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(145,2,'VirtualMachine',21,'CMDBChangeOpCreate'),(146,2,'Farm',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(147,2,'VirtualMachine',22,'CMDBChangeOpCreate'),(148,2,'Farm',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(149,2,'VirtualMachine',23,'CMDBChangeOpCreate'),(150,2,'Farm',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(151,2,'VirtualMachine',24,'CMDBChangeOpCreate'),(152,2,'VirtualMachine',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(153,2,'Software',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(154,2,'DBServer',25,'CMDBChangeOpCreate'),(155,2,'VirtualMachine',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(156,2,'Software',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(157,2,'DBServer',26,'CMDBChangeOpCreate'),(158,2,'DBServer',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(159,2,'DatabaseSchema',27,'CMDBChangeOpCreate'),(160,2,'DBServer',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(161,2,'DatabaseSchema',28,'CMDBChangeOpCreate'),(162,2,'VirtualMachine',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(163,2,'WebServer',29,'CMDBChangeOpCreate'),(164,2,'WebServer',29,'CMDBChangeOpSetAttributeLinksAddRemove'),(165,2,'WebApplication',30,'CMDBChangeOpCreate'),(166,2,'WebServer',29,'CMDBChangeOpSetAttributeLinksAddRemove'),(167,2,'WebApplication',31,'CMDBChangeOpCreate'),(168,2,'ApplicationSolution',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(169,2,'DatabaseSchema',28,'CMDBChangeOpSetAttributeLinksAddRemove'),(170,2,'lnkApplicationSolutionToFunctionalCI',5,'CMDBChangeOpCreate'),(171,2,'ApplicationSolution',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(172,2,'WebApplication',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(173,2,'lnkApplicationSolutionToFunctionalCI',6,'CMDBChangeOpCreate'),(174,2,'ApplicationSolution',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(175,2,'WebApplication',30,'CMDBChangeOpSetAttributeLinksAddRemove'),(176,2,'lnkApplicationSolutionToFunctionalCI',7,'CMDBChangeOpCreate'),(177,2,'ApplicationSolution',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(178,2,'DatabaseSchema',27,'CMDBChangeOpSetAttributeLinksAddRemove'),(179,2,'lnkApplicationSolutionToFunctionalCI',8,'CMDBChangeOpCreate'),(180,2,'ApplicationSolution',13,'CMDBChangeOpSetAttributeLinksTune'),(181,2,'WebServer',29,'CMDBChangeOpSetAttributeLinksAddRemove'),(182,2,'Server',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(183,2,'lnkApplicationSolutionToFunctionalCI',2,'CMDBChangeOpSetAttributeScalar'),(184,2,'DeliveryModel',1,'CMDBChangeOpCreate'),(185,2,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(186,2,'Organization',3,'CMDBChangeOpSetAttributeScalar'),(187,2,'CustomerContract',1,'CMDBChangeOpCreate'),(188,2,'Service',1,'CMDBChangeOpCreate'),(189,2,'Service',2,'CMDBChangeOpCreate'),(190,2,'Service',3,'CMDBChangeOpCreate'),(191,2,'Service',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(192,2,'ServiceSubcategory',1,'CMDBChangeOpCreate'),(193,2,'Service',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(194,2,'ServiceSubcategory',2,'CMDBChangeOpCreate'),(195,2,'Service',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(196,2,'ServiceSubcategory',3,'CMDBChangeOpCreate'),(197,2,'Service',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(198,2,'ServiceSubcategory',4,'CMDBChangeOpCreate'),(199,2,'Service',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(200,2,'ServiceSubcategory',5,'CMDBChangeOpCreate'),(201,2,'Service',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(202,2,'ServiceSubcategory',6,'CMDBChangeOpCreate'),(203,2,'Service',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(204,2,'ServiceSubcategory',7,'CMDBChangeOpCreate'),(205,2,'Service',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(206,2,'ServiceSubcategory',8,'CMDBChangeOpCreate'),(207,2,'Service',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(208,2,'ServiceSubcategory',9,'CMDBChangeOpCreate'),(209,2,'Service',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(210,2,'ServiceSubcategory',10,'CMDBChangeOpCreate'),(211,2,'Service',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(212,2,'ServiceSubcategory',11,'CMDBChangeOpCreate'),(213,2,'Service',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(214,2,'ServiceSubcategory',12,'CMDBChangeOpCreate'),(215,2,'Service',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(216,2,'ServiceSubcategory',13,'CMDBChangeOpCreate'),(217,2,'Service',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(218,2,'ServiceSubcategory',14,'CMDBChangeOpCreate'),(219,2,'Service',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(220,2,'ServiceSubcategory',15,'CMDBChangeOpCreate'),(221,2,'Service',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(222,2,'ServiceSubcategory',16,'CMDBChangeOpCreate'),(223,2,'Service',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(224,2,'ServiceSubcategory',17,'CMDBChangeOpCreate'),(225,2,'SLA',1,'CMDBChangeOpCreate'),(226,2,'SLT',1,'CMDBChangeOpCreate'),(227,2,'SLT',2,'CMDBChangeOpCreate'),(228,2,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(229,2,'lnkSLAToSLT',1,'CMDBChangeOpCreate'),(230,2,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(231,2,'lnkSLAToSLT',2,'CMDBChangeOpCreate'),(232,2,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(233,2,'Service',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(234,2,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(235,2,'lnkCustomerContractToService',1,'CMDBChangeOpCreate'),(236,2,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(237,2,'Service',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(238,2,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(239,2,'lnkCustomerContractToService',2,'CMDBChangeOpCreate'),(240,2,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(241,2,'Service',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(242,2,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(243,2,'lnkCustomerContractToService',3,'CMDBChangeOpCreate'),(244,2,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(245,2,'lnkDeliveryModelToContact',1,'CMDBChangeOpCreate'),(246,2,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(247,2,'lnkDeliveryModelToContact',2,'CMDBChangeOpCreate'),(248,2,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(249,2,'lnkDeliveryModelToContact',3,'CMDBChangeOpCreate'),(250,3,'ModuleInstallation',1,'CMDBChangeOpCreate'),(251,3,'ModuleInstallation',2,'CMDBChangeOpCreate'),(252,3,'ModuleInstallation',3,'CMDBChangeOpCreate'),(253,3,'ModuleInstallation',4,'CMDBChangeOpCreate'),(254,3,'ModuleInstallation',5,'CMDBChangeOpCreate'),(255,3,'ModuleInstallation',6,'CMDBChangeOpCreate'),(256,3,'ModuleInstallation',7,'CMDBChangeOpCreate'),(257,3,'ModuleInstallation',8,'CMDBChangeOpCreate'),(258,3,'ModuleInstallation',9,'CMDBChangeOpCreate'),(259,3,'ModuleInstallation',10,'CMDBChangeOpCreate'),(260,3,'ModuleInstallation',11,'CMDBChangeOpCreate'),(261,3,'ModuleInstallation',12,'CMDBChangeOpCreate'),(262,3,'ModuleInstallation',13,'CMDBChangeOpCreate'),(263,3,'ModuleInstallation',14,'CMDBChangeOpCreate'),(264,3,'ModuleInstallation',15,'CMDBChangeOpCreate'),(265,3,'ModuleInstallation',16,'CMDBChangeOpCreate'),(266,3,'ModuleInstallation',17,'CMDBChangeOpCreate'),(267,3,'ModuleInstallation',18,'CMDBChangeOpCreate'),(268,3,'ModuleInstallation',19,'CMDBChangeOpCreate'),(269,3,'ModuleInstallation',20,'CMDBChangeOpCreate'),(270,3,'ModuleInstallation',21,'CMDBChangeOpCreate'),(271,3,'ModuleInstallation',22,'CMDBChangeOpCreate'),(272,3,'ModuleInstallation',23,'CMDBChangeOpCreate'),(273,4,'URP_Profiles',20,'CMDBChangeOpCreate'),(274,6,'ModuleInstallation',24,'CMDBChangeOpCreate'),(275,6,'ModuleInstallation',25,'CMDBChangeOpCreate'),(276,6,'ModuleInstallation',26,'CMDBChangeOpCreate'),(277,6,'ModuleInstallation',27,'CMDBChangeOpCreate'),(278,6,'ModuleInstallation',28,'CMDBChangeOpCreate'),(279,6,'ModuleInstallation',29,'CMDBChangeOpCreate'),(280,6,'ModuleInstallation',30,'CMDBChangeOpCreate'),(281,6,'ModuleInstallation',31,'CMDBChangeOpCreate'),(282,6,'ModuleInstallation',32,'CMDBChangeOpCreate'),(283,6,'ModuleInstallation',33,'CMDBChangeOpCreate'),(284,6,'ModuleInstallation',34,'CMDBChangeOpCreate'),(285,6,'ModuleInstallation',35,'CMDBChangeOpCreate'),(286,6,'ModuleInstallation',36,'CMDBChangeOpCreate'),(287,6,'ModuleInstallation',37,'CMDBChangeOpCreate'),(288,6,'ModuleInstallation',38,'CMDBChangeOpCreate'),(289,6,'ModuleInstallation',39,'CMDBChangeOpCreate'),(290,6,'ModuleInstallation',40,'CMDBChangeOpCreate'),(291,6,'ModuleInstallation',41,'CMDBChangeOpCreate'),(292,6,'ModuleInstallation',42,'CMDBChangeOpCreate'),(293,6,'ModuleInstallation',43,'CMDBChangeOpCreate'),(294,6,'ModuleInstallation',44,'CMDBChangeOpCreate'),(295,6,'ModuleInstallation',45,'CMDBChangeOpCreate'),(296,6,'ModuleInstallation',46,'CMDBChangeOpCreate'),(297,6,'ModuleInstallation',47,'CMDBChangeOpCreate'),(298,6,'ModuleInstallation',48,'CMDBChangeOpCreate'),(299,6,'ModuleInstallation',49,'CMDBChangeOpCreate'),(300,6,'ModuleInstallation',50,'CMDBChangeOpCreate'),(301,6,'ModuleInstallation',51,'CMDBChangeOpCreate'),(302,6,'ModuleInstallation',52,'CMDBChangeOpCreate'),(303,6,'ModuleInstallation',53,'CMDBChangeOpCreate'),(304,7,'IPUsage',18,'CMDBChangeOpCreate'),(305,8,'IPConfig',1,'CMDBChangeOpCreate'),(306,8,'IPUsage',19,'CMDBChangeOpCreate'),(307,8,'IPUsage',20,'CMDBChangeOpCreate'),(308,8,'IPUsage',21,'CMDBChangeOpCreate'),(309,8,'IPv4Address',1,'CMDBChangeOpCreate');
/*!40000 ALTER TABLE `priv_changeop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_attachment_added`
--

DROP TABLE IF EXISTS `priv_changeop_attachment_added`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_attachment_added` (
  `id` int(11) NOT NULL,
  `attachment_id` int(11) DEFAULT '0',
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `attachment_id` (`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_attachment_added`
--

LOCK TABLES `priv_changeop_attachment_added` WRITE;
/*!40000 ALTER TABLE `priv_changeop_attachment_added` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_attachment_added` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_attachment_removed`
--

DROP TABLE IF EXISTS `priv_changeop_attachment_removed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_attachment_removed` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_attachment_removed`
--

LOCK TABLES `priv_changeop_attachment_removed` WRITE;
/*!40000 ALTER TABLE `priv_changeop_attachment_removed` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_attachment_removed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_create`
--

DROP TABLE IF EXISTS `priv_changeop_create`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_create` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_create`
--

LOCK TABLES `priv_changeop_create` WRITE;
/*!40000 ALTER TABLE `priv_changeop_create` DISABLE KEYS */;
INSERT INTO `priv_changeop_create` VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13),(14),(17),(18),(19),(20),(21),(22),(23),(24),(25),(26),(27),(28),(29),(30),(31),(32),(33),(34),(35),(36),(37),(38),(39),(40),(41),(42),(43),(44),(45),(46),(47),(48),(49),(51),(53),(54),(55),(56),(57),(58),(61),(64),(67),(70),(73),(76),(79),(82),(85),(89),(91),(94),(97),(101),(106),(107),(108),(111),(113),(115),(117),(118),(119),(120),(121),(124),(127),(130),(133),(135),(136),(137),(139),(141),(143),(145),(147),(149),(151),(154),(157),(159),(161),(163),(165),(167),(170),(173),(176),(179),(184),(187),(188),(189),(190),(192),(194),(196),(198),(200),(202),(204),(206),(208),(210),(212),(214),(216),(218),(220),(222),(224),(225),(226),(227),(229),(231),(235),(239),(243),(245),(247),(249),(250),(251),(252),(253),(254),(255),(256),(257),(258),(259),(260),(261),(262),(263),(264),(265),(266),(267),(268),(269),(270),(271),(272),(273),(274),(275),(276),(277),(278),(279),(280),(281),(282),(283),(284),(285),(286),(287),(288),(289),(290),(291),(292),(293),(294),(295),(296),(297),(298),(299),(300),(301),(302),(303),(304),(305),(306),(307),(308),(309);
/*!40000 ALTER TABLE `priv_changeop_create` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_delete`
--

DROP TABLE IF EXISTS `priv_changeop_delete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_delete` (
  `id` int(11) NOT NULL,
  `fclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `fname` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_delete`
--

LOCK TABLES `priv_changeop_delete` WRITE;
/*!40000 ALTER TABLE `priv_changeop_delete` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_delete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links`
--

DROP TABLE IF EXISTS `priv_changeop_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_links` (
  `id` int(11) NOT NULL,
  `item_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `item_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links`
--

LOCK TABLES `priv_changeop_links` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links` DISABLE KEYS */;
INSERT INTO `priv_changeop_links` VALUES (16,'User',1),(50,'Person',11),(52,'Person',12),(59,'Person',9),(60,'Team',17),(62,'Person',8),(63,'Team',17),(65,'Person',9),(66,'Team',15),(68,'Person',10),(69,'Team',15),(71,'Person',13),(72,'Team',15),(74,'Person',5),(75,'Team',14),(77,'Person',2),(78,'Team',14),(80,'Person',6),(81,'Team',16),(83,'Person',7),(84,'Team',16),(86,'Server',1),(87,'Server',1),(88,'Server',1),(90,'Server',2),(92,'Server',3),(93,'Server',3),(95,'Server',4),(96,'Server',4),(98,'NetworkDevice',5),(99,'NetworkDevice',5),(100,'NetworkDevice',5),(102,'NetworkDevice',6),(103,'NetworkDevice',6),(104,'NetworkDevice',6),(105,'NetworkDevice',6),(109,'DBServer',7),(110,'DBServer',7),(112,'DatabaseSchema',8),(114,'WebServer',9),(116,'WebApplication',10),(122,'FunctionalCI',8),(123,'ApplicationSolution',12),(125,'FunctionalCI',4),(126,'ApplicationSolution',13),(128,'FunctionalCI',11),(129,'ApplicationSolution',14),(131,'FunctionalCI',12),(132,'ApplicationSolution',14),(134,'Rack',15),(138,'Hypervisor',18),(140,'Hypervisor',19),(142,'Hypervisor',20),(144,'VirtualMachine',21),(146,'VirtualMachine',22),(148,'VirtualMachine',23),(150,'VirtualMachine',24),(152,'DBServer',25),(153,'DBServer',25),(155,'DBServer',26),(156,'DBServer',26),(158,'DatabaseSchema',27),(160,'DatabaseSchema',28),(162,'WebServer',29),(164,'WebApplication',30),(166,'WebApplication',31),(168,'FunctionalCI',28),(169,'ApplicationSolution',11),(171,'FunctionalCI',31),(172,'ApplicationSolution',11),(174,'FunctionalCI',30),(175,'ApplicationSolution',12),(177,'FunctionalCI',27),(178,'ApplicationSolution',13),(180,'FunctionalCI',29),(181,'ApplicationSolution',13),(182,'ApplicationSolution',13),(185,'Organization',3),(191,'ServiceSubcategory',1),(193,'ServiceSubcategory',2),(195,'ServiceSubcategory',3),(197,'ServiceSubcategory',4),(199,'ServiceSubcategory',5),(201,'ServiceSubcategory',6),(203,'ServiceSubcategory',7),(205,'ServiceSubcategory',8),(207,'ServiceSubcategory',9),(209,'ServiceSubcategory',10),(211,'ServiceSubcategory',11),(213,'ServiceSubcategory',12),(215,'ServiceSubcategory',13),(217,'ServiceSubcategory',14),(219,'ServiceSubcategory',15),(221,'ServiceSubcategory',16),(223,'ServiceSubcategory',17),(228,'SLT',1),(230,'SLT',2),(232,'Service',1),(233,'CustomerContract',1),(234,'CustomerContract',1),(236,'Service',2),(237,'CustomerContract',1),(238,'CustomerContract',1),(240,'Service',3),(241,'CustomerContract',1),(242,'CustomerContract',1),(244,'Contact',8),(246,'Contact',17),(248,'Contact',15);
/*!40000 ALTER TABLE `priv_changeop_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links_addremove`
--

DROP TABLE IF EXISTS `priv_changeop_links_addremove`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_links_addremove` (
  `id` int(11) NOT NULL,
  `type` enum('added','removed') COLLATE utf8_unicode_ci DEFAULT 'added',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links_addremove`
--

LOCK TABLES `priv_changeop_links_addremove` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links_addremove` DISABLE KEYS */;
INSERT INTO `priv_changeop_links_addremove` VALUES (16,'added'),(50,'added'),(52,'added'),(59,'added'),(60,'added'),(62,'added'),(63,'added'),(65,'added'),(66,'added'),(68,'added'),(69,'added'),(71,'added'),(72,'added'),(74,'added'),(75,'added'),(77,'added'),(78,'added'),(80,'added'),(81,'added'),(83,'added'),(84,'added'),(86,'added'),(87,'added'),(88,'added'),(90,'added'),(92,'added'),(93,'added'),(95,'added'),(96,'added'),(98,'added'),(99,'added'),(100,'added'),(102,'added'),(103,'added'),(104,'added'),(105,'added'),(109,'added'),(110,'added'),(112,'added'),(114,'added'),(116,'added'),(122,'added'),(123,'added'),(125,'added'),(126,'added'),(128,'added'),(129,'added'),(131,'added'),(132,'added'),(134,'added'),(138,'added'),(140,'added'),(142,'added'),(144,'added'),(146,'added'),(148,'added'),(150,'added'),(152,'added'),(153,'added'),(155,'added'),(156,'added'),(158,'added'),(160,'added'),(162,'added'),(164,'added'),(166,'added'),(168,'added'),(169,'added'),(171,'added'),(172,'added'),(174,'added'),(175,'added'),(177,'added'),(178,'added'),(181,'added'),(182,'removed'),(185,'added'),(191,'added'),(193,'added'),(195,'added'),(197,'added'),(199,'added'),(201,'added'),(203,'added'),(205,'added'),(207,'added'),(209,'added'),(211,'added'),(213,'added'),(215,'added'),(217,'added'),(219,'added'),(221,'added'),(223,'added'),(228,'added'),(230,'added'),(232,'added'),(233,'added'),(234,'added'),(236,'added'),(237,'added'),(238,'added'),(240,'added'),(241,'added'),(242,'added'),(244,'added'),(246,'added'),(248,'added');
/*!40000 ALTER TABLE `priv_changeop_links_addremove` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links_tune`
--

DROP TABLE IF EXISTS `priv_changeop_links_tune`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_links_tune` (
  `id` int(11) NOT NULL,
  `link_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links_tune`
--

LOCK TABLES `priv_changeop_links_tune` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links_tune` DISABLE KEYS */;
INSERT INTO `priv_changeop_links_tune` VALUES (180,2);
/*!40000 ALTER TABLE `priv_changeop_links_tune` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_plugin`
--

DROP TABLE IF EXISTS `priv_changeop_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_plugin` (
  `id` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_plugin`
--

LOCK TABLES `priv_changeop_plugin` WRITE;
/*!40000 ALTER TABLE `priv_changeop_plugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt`
--

DROP TABLE IF EXISTS `priv_changeop_setatt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt` (
  `id` int(11) NOT NULL,
  `attcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt`
--

LOCK TABLES `priv_changeop_setatt` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt` VALUES (16,'user_list'),(50,'person_list'),(52,'person_list'),(59,'persons_list'),(60,'team_list'),(62,'persons_list'),(63,'team_list'),(65,'persons_list'),(66,'team_list'),(68,'persons_list'),(69,'team_list'),(71,'persons_list'),(72,'team_list'),(74,'persons_list'),(75,'team_list'),(77,'persons_list'),(78,'team_list'),(80,'persons_list'),(81,'team_list'),(83,'persons_list'),(84,'team_list'),(86,'physicaldevice_list'),(87,'physicaldevices_list'),(88,'physicaldevices_list'),(90,'physicaldevice_list'),(92,'physicaldevices_list'),(93,'physicaldevices_list'),(95,'physicaldevices_list'),(96,'physicaldevices_list'),(98,'physicaldevice_list'),(99,'physicaldevices_list'),(100,'networkdevicesdevices_list'),(102,'physicaldevice_list'),(103,'physicaldevices_list'),(104,'physicaldevices_list'),(105,'networkdevicesdevices_list'),(109,'softwares_list'),(110,'softwareinstance_list'),(112,'dbschema_list'),(114,'softwares_list'),(116,'webapp_list'),(122,'functionalcis_list'),(123,'applicationsolution_list'),(125,'functionalcis_list'),(126,'applicationsolution_list'),(128,'functionalcis_list'),(129,'applicationsolution_list'),(131,'functionalcis_list'),(132,'applicationsolution_list'),(134,'physicaldevice_list'),(138,'hypervisor_list'),(140,'hypervisor_list'),(142,'hypervisor_list'),(144,'virtualmachine_list'),(146,'virtualmachine_list'),(148,'virtualmachine_list'),(150,'virtualmachine_list'),(152,'softwares_list'),(153,'softwareinstance_list'),(155,'softwares_list'),(156,'softwareinstance_list'),(158,'dbschema_list'),(160,'dbschema_list'),(162,'softwares_list'),(164,'webapp_list'),(166,'webapp_list'),(168,'functionalcis_list'),(169,'applicationsolution_list'),(171,'functionalcis_list'),(172,'applicationsolution_list'),(174,'functionalcis_list'),(175,'applicationsolution_list'),(177,'functionalcis_list'),(178,'applicationsolution_list'),(180,'functionalcis_list'),(181,'applicationsolution_list'),(182,'applicationsolution_list'),(183,'functionalci_id'),(185,'customers_list'),(186,'deliverymodel_id'),(191,'servicesubcategories_list'),(193,'servicesubcategories_list'),(195,'servicesubcategories_list'),(197,'servicesubcategories_list'),(199,'servicesubcategories_list'),(201,'servicesubcategories_list'),(203,'servicesubcategories_list'),(205,'servicesubcategories_list'),(207,'servicesubcategories_list'),(209,'servicesubcategories_list'),(211,'servicesubcategories_list'),(213,'servicesubcategories_list'),(215,'servicesubcategories_list'),(217,'servicesubcategories_list'),(219,'servicesubcategories_list'),(221,'servicesubcategories_list'),(223,'servicesubcategories_list'),(228,'slts_list'),(230,'slts_list'),(232,'services_list'),(233,'customercontracts_list'),(234,'customercontracts_list'),(236,'services_list'),(237,'customercontracts_list'),(238,'customercontracts_list'),(240,'services_list'),(241,'customercontracts_list'),(242,'customercontracts_list'),(244,'contacts_list'),(246,'contacts_list'),(248,'contacts_list');
/*!40000 ALTER TABLE `priv_changeop_setatt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_data`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_data` (
  `id` int(11) NOT NULL,
  `prevdata_data` longblob,
  `prevdata_mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevdata_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_data`
--

LOCK TABLES `priv_changeop_setatt_data` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_encrypted`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_encrypted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_encrypted` (
  `id` int(11) NOT NULL,
  `data` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_encrypted`
--

LOCK TABLES `priv_changeop_setatt_encrypted` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_encrypted` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_encrypted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_log`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_log` (
  `id` int(11) NOT NULL,
  `lastentry` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_log`
--

LOCK TABLES `priv_changeop_setatt_log` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_longtext`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_longtext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_longtext` (
  `id` int(11) NOT NULL,
  `prevdata` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_longtext`
--

LOCK TABLES `priv_changeop_setatt_longtext` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_longtext` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_longtext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_pwd`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_pwd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_pwd` (
  `id` int(11) NOT NULL,
  `prev_pwd_hash` tinyblob,
  `prev_pwd_salt` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_pwd`
--

LOCK TABLES `priv_changeop_setatt_pwd` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_pwd` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_pwd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_scalar`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_scalar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_scalar` (
  `id` int(11) NOT NULL,
  `oldvalue` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `newvalue` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_scalar`
--

LOCK TABLES `priv_changeop_setatt_scalar` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_scalar` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_scalar` VALUES (183,'4','29'),(186,'0','1');
/*!40000 ALTER TABLE `priv_changeop_setatt_scalar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_text`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_text` (
  `id` int(11) NOT NULL,
  `prevdata` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_text`
--

LOCK TABLES `priv_changeop_setatt_text` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_db_properties`
--

DROP TABLE IF EXISTS `priv_db_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_db_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `change_date` datetime DEFAULT NULL,
  `change_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_db_properties`
--

LOCK TABLES `priv_db_properties` WRITE;
/*!40000 ALTER TABLE `priv_db_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_db_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event`
--

DROP TABLE IF EXISTS `priv_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text COLLATE utf8_unicode_ci,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Event',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event`
--

LOCK TABLES `priv_event` WRITE;
/*!40000 ALTER TABLE `priv_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_email`
--

DROP TABLE IF EXISTS `priv_event_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to` text COLLATE utf8_unicode_ci,
  `cc` text COLLATE utf8_unicode_ci,
  `bcc` text COLLATE utf8_unicode_ci,
  `from` text COLLATE utf8_unicode_ci,
  `subject` text COLLATE utf8_unicode_ci,
  `body` longtext COLLATE utf8_unicode_ci,
  `attachments` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_email`
--

LOCK TABLES `priv_event_email` WRITE;
/*!40000 ALTER TABLE `priv_event_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_issue`
--

DROP TABLE IF EXISTS `priv_event_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_issue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `impact` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `page` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `arguments_post` longtext COLLATE utf8_unicode_ci,
  `arguments_get` longtext COLLATE utf8_unicode_ci,
  `callstack` longtext COLLATE utf8_unicode_ci,
  `data` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_issue`
--

LOCK TABLES `priv_event_issue` WRITE;
/*!40000 ALTER TABLE `priv_event_issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_loginusage`
--

DROP TABLE IF EXISTS `priv_event_loginusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_loginusage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_loginusage`
--

LOCK TABLES `priv_event_loginusage` WRITE;
/*!40000 ALTER TABLE `priv_event_loginusage` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_loginusage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_notification`
--

DROP TABLE IF EXISTS `priv_event_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trigger_id` int(11) DEFAULT '0',
  `action_id` int(11) DEFAULT '0',
  `object_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `trigger_id` (`trigger_id`),
  KEY `action_id` (`action_id`),
  KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_notification`
--

LOCK TABLES `priv_event_notification` WRITE;
/*!40000 ALTER TABLE `priv_event_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_restservice`
--

DROP TABLE IF EXISTS `priv_event_restservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_restservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operation` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `json_input` text COLLATE utf8_unicode_ci,
  `code` int(11) DEFAULT '0',
  `json_output` text COLLATE utf8_unicode_ci,
  `provider` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_restservice`
--

LOCK TABLES `priv_event_restservice` WRITE;
/*!40000 ALTER TABLE `priv_event_restservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_restservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_webservice`
--

DROP TABLE IF EXISTS `priv_event_webservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_webservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `verb` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `result` tinyint(1) DEFAULT '0',
  `log_info` text COLLATE utf8_unicode_ci,
  `log_warning` text COLLATE utf8_unicode_ci,
  `log_error` text COLLATE utf8_unicode_ci,
  `data` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_webservice`
--

LOCK TABLES `priv_event_webservice` WRITE;
/*!40000 ALTER TABLE `priv_event_webservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_webservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_internaluser`
--

DROP TABLE IF EXISTS `priv_internaluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_internaluser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reset_pwd_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_internaluser`
--

LOCK TABLES `priv_internaluser` WRITE;
/*!40000 ALTER TABLE `priv_internaluser` DISABLE KEYS */;
INSERT INTO `priv_internaluser` VALUES (1,'');
/*!40000 ALTER TABLE `priv_internaluser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_link_action_trigger`
--

DROP TABLE IF EXISTS `priv_link_action_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_link_action_trigger` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `action_id` int(11) DEFAULT '0',
  `trigger_id` int(11) DEFAULT '0',
  `order` int(11) DEFAULT '0',
  PRIMARY KEY (`link_id`),
  KEY `action_id` (`action_id`),
  KEY `trigger_id` (`trigger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_link_action_trigger`
--

LOCK TABLES `priv_link_action_trigger` WRITE;
/*!40000 ALTER TABLE `priv_link_action_trigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_link_action_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_module_install`
--

DROP TABLE IF EXISTS `priv_module_install`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_module_install` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `installed` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_module_install`
--

LOCK TABLES `priv_module_install` WRITE;
/*!40000 ALTER TABLE `priv_module_install` DISABLE KEYS */;
INSERT INTO `priv_module_install` VALUES (1,'datamodel','2.2.0','2016-06-30 03:56:12','{\"source_dir\":\"datamodels\\/2.x\\/\"}',0),(2,'iTop','2.2.1.2658','2016-06-30 03:56:12','Done by the setup program\nBuilt on 2016-02-03 17:21:40',0),(3,'authent-external','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)',2),(4,'authent-ldap','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)',2),(5,'authent-local','2.2.0','2016-06-30 03:56:12','Done by the setup program\nMandatory\nVisible (during the setup)',2),(6,'itop-backup','2.2.0','2016-06-30 03:56:12','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(7,'itop-config','1.0.2','2016-06-30 03:56:12','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(8,'itop-profiles-itil','2.2.0','2016-06-30 03:56:12','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(9,'itop-sla-computation','1.0.0','2016-06-30 03:56:12','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(10,'itop-tickets','2.2.0','2016-06-30 03:56:12','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.2.0',2),(11,'itop-welcome-itil','2.2.0','2016-06-30 03:56:12','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(12,'itop-config-mgmt','2.2.0','2016-06-30 03:56:12','Done by the setup program\nMandatory\nVisible (during the setup)',2),(13,'itop-attachments','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)',2),(14,'itop-datacenter-mgmt','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(15,'itop-endusers-devices','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(16,'itop-storage-mgmt','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(17,'itop-virtualization-mgmt','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(18,'itop-bridge-virtualization-storage','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-storage-mgmt/2.2.0\nDepends on module: itop-virtualization-mgmt/2.2.0',2),(19,'itop-service-mgmt','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',2),(20,'itop-request-mgmt','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',2),(21,'itop-change-mgmt','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',2),(22,'itop-knownerror-mgmt','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',2),(23,'itop-problem-mgmt','2.2.0','2016-06-30 03:56:12','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',2),(24,'datamodel','2.2.0','2016-06-30 04:20:50','{\"source_dir\":\"datamodels\\/2.x\\/\"}',0),(25,'iTop','2.2.1.2658','2016-06-30 04:20:50','Done by the setup program\nBuilt on 2016-02-03 17:21:40',0),(26,'authent-external','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)',25),(27,'authent-ldap','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)',25),(28,'authent-local','2.2.0','2016-06-30 04:20:50','Done by the setup program\nMandatory\nVisible (during the setup)',25),(29,'itop-backup','2.2.0','2016-06-30 04:20:50','Done by the setup program\nMandatory\nHidden (selected automatically)',25),(30,'itop-config','1.0.2','2016-06-30 04:20:50','Done by the setup program\nMandatory\nHidden (selected automatically)',25),(31,'itop-profiles-itil','2.2.0','2016-06-30 04:20:50','Done by the setup program\nMandatory\nHidden (selected automatically)',25),(32,'itop-sla-computation','1.0.0','2016-06-30 04:20:50','Done by the setup program\nMandatory\nHidden (selected automatically)',25),(33,'itop-tickets','2.2.0','2016-06-30 04:20:50','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.2.0',25),(34,'itop-welcome-itil','2.2.0','2016-06-30 04:20:50','Done by the setup program\nMandatory\nHidden (selected automatically)',25),(35,'itop-config-mgmt','2.2.0','2016-06-30 04:20:50','Done by the setup program\nMandatory\nVisible (during the setup)',25),(36,'itop-attachments','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)',25),(37,'itop-datacenter-mgmt','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',25),(38,'itop-endusers-devices','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',25),(39,'itop-storage-mgmt','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',25),(40,'itop-virtualization-mgmt','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',25),(41,'itop-bridge-virtualization-storage','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-storage-mgmt/2.2.0\nDepends on module: itop-virtualization-mgmt/2.2.0',25),(42,'itop-service-mgmt','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',25),(43,'itop-request-mgmt','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',25),(44,'itop-change-mgmt','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',25),(45,'itop-knownerror-mgmt','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',25),(46,'itop-problem-mgmt','2.2.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',25),(47,'teemip-network-mgmt','2.1.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0',25),(48,'teemip-ip-mgmt','2.1.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0\nDepends on module: itop-tickets/2.0.0\nDepends on module: teemip-network-mgmt/2.0.0',25),(49,'teemip-ipv6-mgmt','2.1.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: teemip-ip-mgmt/2.0.0',25),(50,'teemip-storage-mgmt-adaptor','2.1.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-storage-mgmt/2.0.0\nDepends on module: teemip-ip-mgmt/2.0.0',25),(51,'teemip-virtualization-mgmt-adaptor','2.1.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-virtualization-mgmt/2.0.0\nDepends on module: teemip-ip-mgmt/2.0.0',25),(52,'teemip-config-mgmt-adaptor','2.1.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0\nDepends on module: teemip-ip-mgmt/2.0.0',25),(53,'teemip-endusers-devices-adaptor','2.1.0','2016-06-30 04:20:50','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-endusers-devices/2.0.0\nDepends on module: teemip-ip-mgmt/2.0.0',25);
/*!40000 ALTER TABLE `priv_module_install` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_ownership_token`
--

DROP TABLE IF EXISTS `priv_ownership_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_ownership_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acquired` datetime DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `obj_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `obj_key` int(11) DEFAULT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_ownership_token`
--

LOCK TABLES `priv_ownership_token` WRITE;
/*!40000 ALTER TABLE `priv_ownership_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_ownership_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_query`
--

DROP TABLE IF EXISTS `priv_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_query` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `fields` text COLLATE utf8_unicode_ci,
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Query',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_query`
--

LOCK TABLES `priv_query` WRITE;
/*!40000 ALTER TABLE `priv_query` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_query` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_query_oql`
--

DROP TABLE IF EXISTS `priv_query_oql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_query_oql` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oql` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_query_oql`
--

LOCK TABLES `priv_query_oql` WRITE;
/*!40000 ALTER TABLE `priv_query_oql` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_query_oql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_shortcut`
--

DROP TABLE IF EXISTS `priv_shortcut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_shortcut` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `context` text COLLATE utf8_unicode_ci,
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Shortcut',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_shortcut`
--

LOCK TABLES `priv_shortcut` WRITE;
/*!40000 ALTER TABLE `priv_shortcut` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_shortcut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_shortcut_oql`
--

DROP TABLE IF EXISTS `priv_shortcut_oql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_shortcut_oql` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oql` text COLLATE utf8_unicode_ci,
  `auto_reload` enum('custom','none') COLLATE utf8_unicode_ci DEFAULT 'none',
  `auto_reload_sec` int(11) DEFAULT '60',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_shortcut_oql`
--

LOCK TABLES `priv_shortcut_oql` WRITE;
/*!40000 ALTER TABLE `priv_shortcut_oql` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_shortcut_oql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att`
--

DROP TABLE IF EXISTS `priv_sync_att`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_att` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_source_id` int(11) DEFAULT '0',
  `attcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `update` tinyint(1) DEFAULT '1',
  `reconcile` tinyint(1) DEFAULT '0',
  `update_policy` enum('master_locked','master_unlocked','write_if_empty') COLLATE utf8_unicode_ci DEFAULT 'master_locked',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'SynchroAttribute',
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att`
--

LOCK TABLES `priv_sync_att` WRITE;
/*!40000 ALTER TABLE `priv_sync_att` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att_extkey`
--

DROP TABLE IF EXISTS `priv_sync_att_extkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_att_extkey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reconciliation_attcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att_extkey`
--

LOCK TABLES `priv_sync_att_extkey` WRITE;
/*!40000 ALTER TABLE `priv_sync_att_extkey` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att_extkey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att_linkset`
--

DROP TABLE IF EXISTS `priv_sync_att_linkset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_att_linkset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `row_separator` varchar(255) COLLATE utf8_unicode_ci DEFAULT '|',
  `attribute_separator` varchar(255) COLLATE utf8_unicode_ci DEFAULT ';',
  `value_separator` varchar(255) COLLATE utf8_unicode_ci DEFAULT ':',
  `attribute_qualifier` varchar(255) COLLATE utf8_unicode_ci DEFAULT '''',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att_linkset`
--

LOCK TABLES `priv_sync_att_linkset` WRITE;
/*!40000 ALTER TABLE `priv_sync_att_linkset` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att_linkset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_datasource`
--

DROP TABLE IF EXISTS `priv_sync_datasource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_datasource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT 'implementation',
  `user_id` int(11) DEFAULT '0',
  `notify_contact_id` int(11) DEFAULT '0',
  `scope_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'ASNumber',
  `database_table_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `scope_restriction` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `full_load_periodicity` int(11) unsigned DEFAULT NULL,
  `reconciliation_policy` enum('use_attributes','use_primary_key') COLLATE utf8_unicode_ci DEFAULT 'use_attributes',
  `action_on_zero` enum('create','error') COLLATE utf8_unicode_ci DEFAULT 'create',
  `action_on_one` enum('error','update') COLLATE utf8_unicode_ci DEFAULT 'update',
  `action_on_multiple` enum('create','error','take_first') COLLATE utf8_unicode_ci DEFAULT 'error',
  `delete_policy` enum('delete','ignore','update','update_then_delete') COLLATE utf8_unicode_ci DEFAULT 'ignore',
  `delete_policy_update` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `delete_policy_retention` int(11) unsigned DEFAULT NULL,
  `user_delete_policy` enum('administrators','everybody','nobody') COLLATE utf8_unicode_ci DEFAULT 'nobody',
  `url_icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `url_application` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `notify_contact_id` (`notify_contact_id`),
  KEY `scope_class` (`scope_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_datasource`
--

LOCK TABLES `priv_sync_datasource` WRITE;
/*!40000 ALTER TABLE `priv_sync_datasource` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_datasource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_log`
--

DROP TABLE IF EXISTS `priv_sync_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_source_id` int(11) DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` enum('completed','error','running') COLLATE utf8_unicode_ci DEFAULT 'running',
  `status_curr_job` int(11) DEFAULT '0',
  `status_curr_pos` int(11) DEFAULT '0',
  `stats_nb_replica_seen` int(11) DEFAULT '0',
  `stats_nb_replica_total` int(11) DEFAULT '0',
  `stats_nb_obj_deleted` int(11) DEFAULT '0',
  `stats_deleted_errors` int(11) DEFAULT '0',
  `stats_nb_obj_obsoleted` int(11) DEFAULT '0',
  `stats_nb_obj_obsoleted_errors` int(11) DEFAULT '0',
  `stats_nb_obj_created` int(11) DEFAULT '0',
  `stats_nb_obj_created_errors` int(11) DEFAULT '0',
  `stats_nb_obj_created_warnings` int(11) DEFAULT '0',
  `stats_nb_obj_updated` int(11) DEFAULT '0',
  `stats_nb_obj_updated_errors` int(11) DEFAULT '0',
  `stats_nb_obj_updated_warnings` int(11) DEFAULT '0',
  `stats_nb_obj_unchanged_warnings` int(11) DEFAULT '0',
  `stats_nb_replica_reconciled_errors` int(11) DEFAULT '0',
  `stats_nb_replica_disappeared_no_action` int(11) DEFAULT '0',
  `stats_nb_obj_new_updated` int(11) DEFAULT '0',
  `stats_nb_obj_new_updated_warnings` int(11) DEFAULT '0',
  `stats_nb_obj_new_unchanged` int(11) DEFAULT '0',
  `stats_nb_obj_new_unchanged_warnings` int(11) DEFAULT '0',
  `last_error` text COLLATE utf8_unicode_ci,
  `traces` longtext COLLATE utf8_unicode_ci,
  `memory_usage_peak` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_log`
--

LOCK TABLES `priv_sync_log` WRITE;
/*!40000 ALTER TABLE `priv_sync_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_replica`
--

DROP TABLE IF EXISTS `priv_sync_replica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_replica` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_source_id` int(11) DEFAULT '0',
  `dest_id` int(11) DEFAULT '0',
  `dest_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Organization',
  `status_last_seen` datetime DEFAULT NULL,
  `status` enum('modified','new','obsolete','orphan','synchronized') COLLATE utf8_unicode_ci DEFAULT 'new',
  `status_dest_creator` tinyint(1) DEFAULT '0',
  `status_last_error` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status_last_warning` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `info_creation_date` datetime DEFAULT NULL,
  `info_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`),
  KEY `dest_class` (`dest_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_replica`
--

LOCK TABLES `priv_sync_replica` WRITE;
/*!40000 ALTER TABLE `priv_sync_replica` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_replica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger`
--

DROP TABLE IF EXISTS `priv_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `realclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Trigger',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger`
--

LOCK TABLES `priv_trigger` WRITE;
/*!40000 ALTER TABLE `priv_trigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjcreate`
--

DROP TABLE IF EXISTS `priv_trigger_onobjcreate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onobjcreate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjcreate`
--

LOCK TABLES `priv_trigger_onobjcreate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjcreate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobjcreate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobject`
--

DROP TABLE IF EXISTS `priv_trigger_onobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onobject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'ASNumber',
  `filter` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `target_class` (`target_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobject`
--

LOCK TABLES `priv_trigger_onobject` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onportalupdate`
--

DROP TABLE IF EXISTS `priv_trigger_onportalupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onportalupdate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onportalupdate`
--

LOCK TABLES `priv_trigger_onportalupdate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onportalupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onportalupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstatechange`
--

DROP TABLE IF EXISTS `priv_trigger_onstatechange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onstatechange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstatechange`
--

LOCK TABLES `priv_trigger_onstatechange` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstatechange` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstatechange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstateenter`
--

DROP TABLE IF EXISTS `priv_trigger_onstateenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onstateenter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstateenter`
--

LOCK TABLES `priv_trigger_onstateenter` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstateenter` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstateenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstateleave`
--

DROP TABLE IF EXISTS `priv_trigger_onstateleave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onstateleave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstateleave`
--

LOCK TABLES `priv_trigger_onstateleave` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstateleave` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstateleave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onwatermark`
--

DROP TABLE IF EXISTS `priv_trigger_onwatermark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onwatermark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) DEFAULT '0',
  `target_class` enum('IPv4Range','IPv4Subnet','IPv6Range','IPv6Subnet') COLLATE utf8_unicode_ci DEFAULT 'IPv4Subnet',
  `event` enum('cross_high','cross_low') COLLATE utf8_unicode_ci DEFAULT 'cross_high',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onwatermark`
--

LOCK TABLES `priv_trigger_onwatermark` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onwatermark` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onwatermark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_threshold`
--

DROP TABLE IF EXISTS `priv_trigger_threshold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_threshold` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stop_watch_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `threshold_index` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_threshold`
--

LOCK TABLES `priv_trigger_threshold` WRITE;
/*!40000 ALTER TABLE `priv_trigger_threshold` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_threshold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_profiles`
--

DROP TABLE IF EXISTS `priv_urp_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_urp_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_profiles`
--

LOCK TABLES `priv_urp_profiles` WRITE;
/*!40000 ALTER TABLE `priv_urp_profiles` DISABLE KEYS */;
INSERT INTO `priv_urp_profiles` VALUES (1,'Administrator','Has the rights on everything (bypassing any control)'),(2,'Portal user','Has the rights to access to the user portal. People having this profile will not be allowed to access the standard application, they will be automatically redirected to the user portal.'),(3,'Configuration Manager','Person in charge of the documentation of the managed CIs'),(4,'Service Desk Agent','Person in charge of creating incident reports'),(5,'Support Agent','Person analyzing and solving the current incidents'),(6,'Problem Manager','Person analyzing and solving the current problems'),(7,'Change Implementor','Person executing the changes'),(8,'Change Supervisor','Person responsible for the overall change execution'),(9,'Change Approver','Person who could be impacted by some changes'),(10,'Service Manager','Person responsible for the service delivered to the [internal] customer'),(11,'Document author','Any person who could contribute to documentation'),(12,'Portal power user','Users having this profile will have the rights to see all the tickets for a customer in the portal. Must be used in conjunction with other profiles (e.g. Portal User).'),(20,'Hostmaster','Person handling the IP space and looking after the IP changes');
/*!40000 ALTER TABLE `priv_urp_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_userorg`
--

DROP TABLE IF EXISTS `priv_urp_userorg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_urp_userorg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT '0',
  `allowed_org_id` int(11) DEFAULT '0',
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `allowed_org_id` (`allowed_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_userorg`
--

LOCK TABLES `priv_urp_userorg` WRITE;
/*!40000 ALTER TABLE `priv_urp_userorg` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_urp_userorg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_userprofile`
--

DROP TABLE IF EXISTS `priv_urp_userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_urp_userprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT '0',
  `profileid` int(11) DEFAULT '0',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `profileid` (`profileid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_userprofile`
--

LOCK TABLES `priv_urp_userprofile` WRITE;
/*!40000 ALTER TABLE `priv_urp_userprofile` DISABLE KEYS */;
INSERT INTO `priv_urp_userprofile` VALUES (1,1,1,'By definition, the administrator must have the administrator profile');
/*!40000 ALTER TABLE `priv_urp_userprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user`
--

DROP TABLE IF EXISTS `priv_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contactid` int(11) DEFAULT '0',
  `login` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'EN US',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'User',
  PRIMARY KEY (`id`),
  KEY `contactid` (`contactid`),
  KEY `language` (`language`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user`
--

LOCK TABLES `priv_user` WRITE;
/*!40000 ALTER TABLE `priv_user` DISABLE KEYS */;
INSERT INTO `priv_user` VALUES (1,1,'admin','EN US','UserLocal');
/*!40000 ALTER TABLE `priv_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user_local`
--

DROP TABLE IF EXISTS `priv_user_local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_user_local` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password_hash` tinyblob,
  `password_salt` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user_local`
--

LOCK TABLES `priv_user_local` WRITE;
/*!40000 ALTER TABLE `priv_user_local` DISABLE KEYS */;
INSERT INTO `priv_user_local` VALUES (1,'76007e9c000e0ca3929ea5b3b4dce7ac328ba00e3947815dc04ab74721f37852','�����C��ڸ�\"���2');
/*!40000 ALTER TABLE `priv_user_local` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providercontract`
--

DROP TABLE IF EXISTS `providercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sla` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `coverage` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providercontract`
--

LOCK TABLES `providercontract` WRITE;
/*!40000 ALTER TABLE `providercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `providercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rack`
--

DROP TABLE IF EXISTS `rack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nb_u` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rack`
--

LOCK TABLES `rack` WRITE;
/*!40000 ALTER TABLE `rack` DISABLE KEYS */;
INSERT INTO `rack` VALUES (15,NULL);
/*!40000 ALTER TABLE `rack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sanswitch`
--

DROP TABLE IF EXISTS `sanswitch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sanswitch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sanswitch`
--

LOCK TABLES `sanswitch` WRITE;
/*!40000 ALTER TABLE `sanswitch` DISABLE KEYS */;
/*!40000 ALTER TABLE `sanswitch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osfamily_id` int(11) DEFAULT '0',
  `osversion_id` int(11) DEFAULT '0',
  `oslicence_id` int(11) DEFAULT '0',
  `cpu` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `oslicence_id` (`oslicence_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
INSERT INTO `server` VALUES (1,6,8,0,'',''),(2,0,0,0,'',''),(3,6,8,0,'',''),(4,6,8,0,'','');
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `servicefamily_id` int(11) DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `servicefamily_id` (`servicefamily_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (1,'Computers and peripherals',2,0,'Ordering of new hardware (Desktop computer, laptop computer, monitor, mouse, keyboard...) and support in case of hardware failure.','production'),(2,'Software',2,0,'Management of computer software and applications. Installation, upgrade, troubleshooting and removal of software.','production'),(3,'Telecom and connectivity',2,0,'Ordering and configuration of new mobile phones, computer connectivity requests, cabling, etc...','production');
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicefamily`
--

DROP TABLE IF EXISTS `servicefamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicefamily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicefamily`
--

LOCK TABLES `servicefamily` WRITE;
/*!40000 ALTER TABLE `servicefamily` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicefamily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicesubcategory`
--

DROP TABLE IF EXISTS `servicesubcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicesubcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `service_id` int(11) DEFAULT '0',
  `request_type` enum('incident','service_request') COLLATE utf8_unicode_ci DEFAULT 'incident',
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicesubcategory`
--

LOCK TABLES `servicesubcategory` WRITE;
/*!40000 ALTER TABLE `servicesubcategory` DISABLE KEYS */;
INSERT INTO `servicesubcategory` VALUES (1,'Microsoft Office Support','Request assistance about MS Office software: Word, Excel, PowerPoint, Outlook, SharePoint.',2,'service_request','production'),(2,'Mobile phone/SIM locking','Request for locking the SIM when a mobile phone has been lost or stolen.',3,'service_request','production'),(3,'Mobile phone/SIM unlocking','Request for unlocking the SIM of your mobile phone.',3,'incident','production'),(4,'Network Troubleshooting','Ask for help troubleshooting a network related issue.',3,'incident','production'),(5,'New desktop ordering','Order a new desktop computer, for a new employee or for replacing an old system.',1,'service_request','production'),(6,'New DNS name','Request a new DNS name for a fixed system (Desktop computer or server).',3,'service_request','production'),(7,'New IP address','Request a new IP address for a fixed system (Desktop computer or server)',3,'service_request','production'),(8,'New laptop ordering','Order a new laptop computer, for a new mobile employee or for replacing an old laptop.',1,'service_request','production'),(9,'New LCD monitor ordering','Order a new LCD monitor, for a new employee or for replacing an old monitor.',1,'service_request','production'),(10,'New mobile phone ordering','Order a new mobile phone, for a new employee or for replacing a broken phone.',3,'service_request','production'),(11,'New peripheral','Order a peripheral: keyboard, mouse, personal printer...',1,'service_request','production'),(12,'Repair','Ask for assistance about a hardware failure.',1,'incident','production'),(13,'Software Installation / Upgrade','Ask for installing or upgrading software on a computer.',2,'service_request','production'),(14,'Software removal','Ask for removing software from your computer.',2,'service_request','production'),(15,'Troubleshooting','Ask for assistance about a software related issue.',2,'incident','production'),(16,'Troubleshooting','Ask for help troubleshooting a hardware issue.',1,'incident','production'),(17,'Windows installation/upgrade','Ask for installing or upgrading Windows on a computer.',2,'service_request','production');
/*!40000 ALTER TABLE `servicesubcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla`
--

DROP TABLE IF EXISTS `sla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sla` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `org_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla`
--

LOCK TABLES `sla` WRITE;
/*!40000 ALTER TABLE `sla` DISABLE KEYS */;
INSERT INTO `sla` VALUES (1,'Standard SLA','',3);
/*!40000 ALTER TABLE `sla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slt`
--

DROP TABLE IF EXISTS `slt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `priority` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT NULL,
  `request_type` enum('incident','service_request') COLLATE utf8_unicode_ci DEFAULT NULL,
  `metric` enum('tto','ttr') COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `unit` enum('hours','minutes') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slt`
--

LOCK TABLES `slt` WRITE;
/*!40000 ALTER TABLE `slt` DISABLE KEYS */;
INSERT INTO `slt` VALUES (1,'TTO priority high Incident 5mn','1','incident','tto',5,'minutes'),(2,'TTR priority high incident 15 mn','1','incident','ttr',15,'minutes');
/*!40000 ALTER TABLE `slt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `software`
--

DROP TABLE IF EXISTS `software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `software` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `vendor` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `type` enum('DBServer','Middleware','OtherSoftware','PCSoftware','WebServer') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `software`
--

LOCK TABLES `software` WRITE;
/*!40000 ALTER TABLE `software` DISABLE KEYS */;
INSERT INTO `software` VALUES (1,'MySql','Oracle','5.3','DBServer'),(2,'Oracle DB engine','Oracle','11i','DBServer');
/*!40000 ALTER TABLE `software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwareinstance`
--

DROP TABLE IF EXISTS `softwareinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwareinstance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) DEFAULT '0',
  `software_id` int(11) DEFAULT '0',
  `softwarelicence_id` int(11) DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `software_id` (`software_id`),
  KEY `softwarelicence_id` (`softwarelicence_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwareinstance`
--

LOCK TABLES `softwareinstance` WRITE;
/*!40000 ALTER TABLE `softwareinstance` DISABLE KEYS */;
INSERT INTO `softwareinstance` VALUES (7,2,1,0,'',NULL),(9,4,0,0,'','active'),(25,22,2,0,'',NULL),(26,23,1,0,'',NULL),(29,21,0,0,'',NULL);
/*!40000 ALTER TABLE `softwareinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwarelicence`
--

DROP TABLE IF EXISTS `softwarelicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwarelicence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwarelicence`
--

LOCK TABLES `softwarelicence` WRITE;
/*!40000 ALTER TABLE `softwarelicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarelicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwarepatch`
--

DROP TABLE IF EXISTS `softwarepatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwarepatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwarepatch`
--

LOCK TABLES `softwarepatch` WRITE;
/*!40000 ALTER TABLE `softwarepatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarepatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storagesystem`
--

DROP TABLE IF EXISTS `storagesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storagesystem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storagesystem`
--

LOCK TABLES `storagesystem` WRITE;
/*!40000 ALTER TABLE `storagesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `storagesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subnet`
--

DROP TABLE IF EXISTS `subnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subnet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8_unicode_ci,
  `subnet_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ip_mask` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subnet`
--

LOCK TABLES `subnet` WRITE;
/*!40000 ALTER TABLE `subnet` DISABLE KEYS */;
/*!40000 ALTER TABLE `subnet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tablet`
--

DROP TABLE IF EXISTS `tablet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tablet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ipaddress_id` (`ipaddress_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tablet`
--

LOCK TABLES `tablet` WRITE;
/*!40000 ALTER TABLE `tablet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tablet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tape`
--

DROP TABLE IF EXISTS `tape`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tape` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `tapelibrary_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tapelibrary_id` (`tapelibrary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tape`
--

LOCK TABLES `tape` WRITE;
/*!40000 ALTER TABLE `tape` DISABLE KEYS */;
/*!40000 ALTER TABLE `tape` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tapelibrary`
--

DROP TABLE IF EXISTS `tapelibrary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tapelibrary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tapelibrary`
--

LOCK TABLES `tapelibrary` WRITE;
/*!40000 ALTER TABLE `tapelibrary` DISABLE KEYS */;
/*!40000 ALTER TABLE `tapelibrary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (14),(15),(16),(17);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telephonyci`
--

DROP TABLE IF EXISTS `telephonyci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telephonyci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telephonyci`
--

LOCK TABLES `telephonyci` WRITE;
/*!40000 ALTER TABLE `telephonyci` DISABLE KEYS */;
/*!40000 ALTER TABLE `telephonyci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `org_id` int(11) DEFAULT '0',
  `caller_id` int(11) DEFAULT '0',
  `team_id` int(11) DEFAULT '0',
  `agent_id` int(11) DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `close_date` datetime DEFAULT NULL,
  `private_log` longtext COLLATE utf8_unicode_ci,
  `private_log_index` blob,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Ticket',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `caller_id` (`caller_id`),
  KEY `team_id` (`team_id`),
  KEY `agent_id` (`agent_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_change`
--

DROP TABLE IF EXISTS `ticket_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('approved','assigned','closed','new','planned','rejected') COLLATE utf8_unicode_ci DEFAULT 'new',
  `category` enum('application','hardware','network','other','software','system') COLLATE utf8_unicode_ci DEFAULT 'hardware',
  `reject_reason` text COLLATE utf8_unicode_ci,
  `changemanager_id` int(11) DEFAULT '0',
  `parent_id` int(11) DEFAULT '0',
  `creation_date` datetime DEFAULT NULL,
  `approval_date` datetime DEFAULT NULL,
  `fallback_plan` text COLLATE utf8_unicode_ci,
  `outage` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `changemanager_id` (`changemanager_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_change`
--

LOCK TABLES `ticket_change` WRITE;
/*!40000 ALTER TABLE `ticket_change` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_problem`
--

DROP TABLE IF EXISTS `ticket_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_problem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('assigned','closed','new','resolved') COLLATE utf8_unicode_ci DEFAULT 'new',
  `service_id` int(11) DEFAULT '0',
  `servicesubcategory_id` int(11) DEFAULT '0',
  `product` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `impact` enum('1','2','3') COLLATE utf8_unicode_ci DEFAULT '1',
  `urgency` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT '1',
  `priority` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT '1',
  `related_change_id` int(11) DEFAULT '0',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `related_change_id` (`related_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_problem`
--

LOCK TABLES `ticket_problem` WRITE;
/*!40000 ALTER TABLE `ticket_problem` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_problem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_request`
--

DROP TABLE IF EXISTS `ticket_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('approved','assigned','closed','escalated_tto','escalated_ttr','new','pending','rejected','resolved','waiting_for_approval') COLLATE utf8_unicode_ci DEFAULT 'new',
  `request_type` enum('incident','service_request') COLLATE utf8_unicode_ci DEFAULT 'incident',
  `impact` enum('1','2','3') COLLATE utf8_unicode_ci DEFAULT '1',
  `priority` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT '4',
  `urgency` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT '4',
  `origin` enum('mail','monitoring','phone','portal') COLLATE utf8_unicode_ci DEFAULT 'phone',
  `approver_id` int(11) DEFAULT '0',
  `service_id` int(11) DEFAULT '0',
  `servicesubcategory_id` int(11) DEFAULT '0',
  `escalation_flag` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT 'no',
  `escalation_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  `last_pending_date` datetime DEFAULT NULL,
  `cumulatedpending_timespent` int(11) unsigned DEFAULT NULL,
  `cumulatedpending_started` datetime DEFAULT NULL,
  `cumulatedpending_laststart` datetime DEFAULT NULL,
  `cumulatedpending_stopped` datetime DEFAULT NULL,
  `tto_timespent` int(11) unsigned DEFAULT NULL,
  `tto_started` datetime DEFAULT NULL,
  `tto_laststart` datetime DEFAULT NULL,
  `tto_stopped` datetime DEFAULT NULL,
  `tto_75_deadline` datetime DEFAULT NULL,
  `tto_75_passed` tinyint(1) unsigned DEFAULT NULL,
  `tto_75_triggered` tinyint(1) DEFAULT NULL,
  `tto_75_overrun` int(11) unsigned DEFAULT NULL,
  `tto_100_deadline` datetime DEFAULT NULL,
  `tto_100_passed` tinyint(1) unsigned DEFAULT NULL,
  `tto_100_triggered` tinyint(1) DEFAULT NULL,
  `tto_100_overrun` int(11) unsigned DEFAULT NULL,
  `ttr_timespent` int(11) unsigned DEFAULT NULL,
  `ttr_started` datetime DEFAULT NULL,
  `ttr_laststart` datetime DEFAULT NULL,
  `ttr_stopped` datetime DEFAULT NULL,
  `ttr_75_deadline` datetime DEFAULT NULL,
  `ttr_75_passed` tinyint(1) unsigned DEFAULT NULL,
  `ttr_75_triggered` tinyint(1) DEFAULT NULL,
  `ttr_75_overrun` int(11) unsigned DEFAULT NULL,
  `ttr_100_deadline` datetime DEFAULT NULL,
  `ttr_100_passed` tinyint(1) unsigned DEFAULT NULL,
  `ttr_100_triggered` tinyint(1) DEFAULT NULL,
  `ttr_100_overrun` int(11) unsigned DEFAULT NULL,
  `time_spent` int(11) unsigned DEFAULT NULL,
  `resolution_code` enum('assistance','bug fixed','hardware repair','other','software patch','system update','training') COLLATE utf8_unicode_ci DEFAULT 'assistance',
  `solution` text COLLATE utf8_unicode_ci,
  `pending_reason` text COLLATE utf8_unicode_ci,
  `parent_request_id` int(11) DEFAULT '0',
  `parent_problem_id` int(11) DEFAULT '0',
  `parent_change_id` int(11) DEFAULT '0',
  `public_log` longtext COLLATE utf8_unicode_ci,
  `public_log_index` blob,
  `user_satisfaction` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT '1',
  `user_commment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `approver_id` (`approver_id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `parent_request_id` (`parent_request_id`),
  KEY `parent_problem_id` (`parent_problem_id`),
  KEY `parent_change_id` (`parent_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_request`
--

LOCK TABLES `ticket_request` WRITE;
/*!40000 ALTER TABLE `ticket_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typology`
--

DROP TABLE IF EXISTS `typology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typology` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `finalclass` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Typology',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typology`
--

LOCK TABLES `typology` WRITE;
/*!40000 ALTER TABLE `typology` DISABLE KEYS */;
INSERT INTO `typology` VALUES (1,'Cisco','Brand'),(2,'HP','Brand'),(3,'Cisco 6500','Model'),(4,'DL380','Model'),(5,'Procurve 2450','Model'),(6,'Linux','OSFamily'),(7,'Windows','OSFamily'),(8,'Unbuntu 11.10','OSVersion'),(9,'Windows 2008 Server','OSVersion'),(10,'Router','NetworkDeviceType'),(11,'Switch','NetworkDeviceType'),(12,'Customer manager','ContactType'),(13,'Helpdesk','ContactType'),(14,'Manager','ContactType'),(15,'Support Agent','ContactType'),(16,'Support level1','ContactType'),(17,'Team leader','ContactType'),(18,'mission','IPUsage'),(19,'Network IP','IPUsage'),(20,'Gateway','IPUsage'),(21,'Broadcast','IPUsage');
/*!40000 ALTER TABLE `typology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `view_ASNumber`
--

DROP TABLE IF EXISTS `view_ASNumber`;
/*!50001 DROP VIEW IF EXISTS `view_ASNumber`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_ASNumber` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `number` tinyint NOT NULL,
  `registrar_id` tinyint NOT NULL,
  `registrar_name` tinyint NOT NULL,
  `whois` tinyint NOT NULL,
  `validity_end` tinyint NOT NULL,
  `renewal_date` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `registrar_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ApplicationSolution`
--

DROP TABLE IF EXISTS `view_ApplicationSolution`;
/*!50001 DROP VIEW IF EXISTS `view_ApplicationSolution`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_ApplicationSolution` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `redundancy` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Attachment`
--

DROP TABLE IF EXISTS `view_Attachment`;
/*!50001 DROP VIEW IF EXISTS `view_Attachment`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Attachment` (
  `id` tinyint NOT NULL,
  `expire` tinyint NOT NULL,
  `temp_id` tinyint NOT NULL,
  `item_class` tinyint NOT NULL,
  `item_id` tinyint NOT NULL,
  `item_org_id` tinyint NOT NULL,
  `contents` tinyint NOT NULL,
  `contents_data` tinyint NOT NULL,
  `contents_filename` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Brand`
--

DROP TABLE IF EXISTS `view_Brand`;
/*!50001 DROP VIEW IF EXISTS `view_Brand`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Brand` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_BusinessProcess`
--

DROP TABLE IF EXISTS `view_BusinessProcess`;
/*!50001 DROP VIEW IF EXISTS `view_BusinessProcess`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_BusinessProcess` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Change`
--

DROP TABLE IF EXISTS `view_Change`;
/*!50001 DROP VIEW IF EXISTS `view_Change`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Change` (
  `id` tinyint NOT NULL,
  `ref` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `caller_id` tinyint NOT NULL,
  `caller_name` tinyint NOT NULL,
  `team_id` tinyint NOT NULL,
  `team_name` tinyint NOT NULL,
  `agent_id` tinyint NOT NULL,
  `agent_name` tinyint NOT NULL,
  `title` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `last_update` tinyint NOT NULL,
  `close_date` tinyint NOT NULL,
  `private_log` tinyint NOT NULL,
  `private_log_index` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `category` tinyint NOT NULL,
  `reject_reason` tinyint NOT NULL,
  `changemanager_id` tinyint NOT NULL,
  `changemanager_email` tinyint NOT NULL,
  `parent_id` tinyint NOT NULL,
  `parent_name` tinyint NOT NULL,
  `creation_date` tinyint NOT NULL,
  `approval_date` tinyint NOT NULL,
  `fallback_plan` tinyint NOT NULL,
  `outage` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `caller_id_friendlyname` tinyint NOT NULL,
  `team_id_friendlyname` tinyint NOT NULL,
  `agent_id_friendlyname` tinyint NOT NULL,
  `changemanager_id_friendlyname` tinyint NOT NULL,
  `parent_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ConnectableCI`
--

DROP TABLE IF EXISTS `view_ConnectableCI`;
/*!50001 DROP VIEW IF EXISTS `view_ConnectableCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_ConnectableCI` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Contact`
--

DROP TABLE IF EXISTS `view_Contact`;
/*!50001 DROP VIEW IF EXISTS `view_Contact`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Contact` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `phone` tinyint NOT NULL,
  `notify` tinyint NOT NULL,
  `function` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ContactType`
--

DROP TABLE IF EXISTS `view_ContactType`;
/*!50001 DROP VIEW IF EXISTS `view_ContactType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_ContactType` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Contract`
--

DROP TABLE IF EXISTS `view_Contract`;
/*!50001 DROP VIEW IF EXISTS `view_Contract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Contract` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `cost` tinyint NOT NULL,
  `cost_currency` tinyint NOT NULL,
  `contracttype_id` tinyint NOT NULL,
  `contracttype_name` tinyint NOT NULL,
  `billing_frequency` tinyint NOT NULL,
  `cost_unit` tinyint NOT NULL,
  `provider_id` tinyint NOT NULL,
  `provider_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `contracttype_id_friendlyname` tinyint NOT NULL,
  `provider_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ContractType`
--

DROP TABLE IF EXISTS `view_ContractType`;
/*!50001 DROP VIEW IF EXISTS `view_ContractType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_ContractType` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_CustomerContract`
--

DROP TABLE IF EXISTS `view_CustomerContract`;
/*!50001 DROP VIEW IF EXISTS `view_CustomerContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_CustomerContract` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `cost` tinyint NOT NULL,
  `cost_currency` tinyint NOT NULL,
  `contracttype_id` tinyint NOT NULL,
  `contracttype_name` tinyint NOT NULL,
  `billing_frequency` tinyint NOT NULL,
  `cost_unit` tinyint NOT NULL,
  `provider_id` tinyint NOT NULL,
  `provider_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `contracttype_id_friendlyname` tinyint NOT NULL,
  `provider_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DBServer`
--

DROP TABLE IF EXISTS `view_DBServer`;
/*!50001 DROP VIEW IF EXISTS `view_DBServer`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_DBServer` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `system_id` tinyint NOT NULL,
  `system_name` tinyint NOT NULL,
  `software_id` tinyint NOT NULL,
  `software_name` tinyint NOT NULL,
  `softwarelicence_id` tinyint NOT NULL,
  `softwarelicence_name` tinyint NOT NULL,
  `path` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `system_id_friendlyname` tinyint NOT NULL,
  `system_id_finalclass_recall` tinyint NOT NULL,
  `software_id_friendlyname` tinyint NOT NULL,
  `softwarelicence_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DNSObject`
--

DROP TABLE IF EXISTS `view_DNSObject`;
/*!50001 DROP VIEW IF EXISTS `view_DNSObject`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_DNSObject` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DatabaseSchema`
--

DROP TABLE IF EXISTS `view_DatabaseSchema`;
/*!50001 DROP VIEW IF EXISTS `view_DatabaseSchema`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_DatabaseSchema` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `dbserver_id` tinyint NOT NULL,
  `dbserver_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `dbserver_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DatacenterDevice`
--

DROP TABLE IF EXISTS `view_DatacenterDevice`;
/*!50001 DROP VIEW IF EXISTS `view_DatacenterDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_DatacenterDevice` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `rack_id` tinyint NOT NULL,
  `rack_name` tinyint NOT NULL,
  `enclosure_id` tinyint NOT NULL,
  `enclosure_name` tinyint NOT NULL,
  `nb_u` tinyint NOT NULL,
  `powerA_id` tinyint NOT NULL,
  `powerA_name` tinyint NOT NULL,
  `powerB_id` tinyint NOT NULL,
  `powerB_name` tinyint NOT NULL,
  `redundancy` tinyint NOT NULL,
  `managementip_id` tinyint NOT NULL,
  `managementip_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `rack_id_friendlyname` tinyint NOT NULL,
  `enclosure_id_friendlyname` tinyint NOT NULL,
  `powerA_id_friendlyname` tinyint NOT NULL,
  `powerA_id_finalclass_recall` tinyint NOT NULL,
  `powerB_id_friendlyname` tinyint NOT NULL,
  `powerB_id_finalclass_recall` tinyint NOT NULL,
  `managementip_id_friendlyname` tinyint NOT NULL,
  `managementip_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DeliveryModel`
--

DROP TABLE IF EXISTS `view_DeliveryModel`;
/*!50001 DROP VIEW IF EXISTS `view_DeliveryModel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_DeliveryModel` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Document`
--

DROP TABLE IF EXISTS `view_Document`;
/*!50001 DROP VIEW IF EXISTS `view_Document`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Document` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `documenttype_id` tinyint NOT NULL,
  `documenttype_name` tinyint NOT NULL,
  `version` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `documenttype_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DocumentFile`
--

DROP TABLE IF EXISTS `view_DocumentFile`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentFile`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_DocumentFile` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `documenttype_id` tinyint NOT NULL,
  `documenttype_name` tinyint NOT NULL,
  `version` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `file` tinyint NOT NULL,
  `file_data` tinyint NOT NULL,
  `file_filename` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `documenttype_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DocumentNote`
--

DROP TABLE IF EXISTS `view_DocumentNote`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentNote`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_DocumentNote` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `documenttype_id` tinyint NOT NULL,
  `documenttype_name` tinyint NOT NULL,
  `version` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `text` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `documenttype_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DocumentType`
--

DROP TABLE IF EXISTS `view_DocumentType`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_DocumentType` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_DocumentWeb`
--

DROP TABLE IF EXISTS `view_DocumentWeb`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentWeb`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_DocumentWeb` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `documenttype_id` tinyint NOT NULL,
  `documenttype_name` tinyint NOT NULL,
  `version` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `url` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `documenttype_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Domain`
--

DROP TABLE IF EXISTS `view_Domain`;
/*!50001 DROP VIEW IF EXISTS `view_Domain`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Domain` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `parent_id` tinyint NOT NULL,
  `parent_name` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `registrar_id` tinyint NOT NULL,
  `registrar_name` tinyint NOT NULL,
  `validity_start` tinyint NOT NULL,
  `validity_end` tinyint NOT NULL,
  `renewal` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `parent_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `registrar_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Enclosure`
--

DROP TABLE IF EXISTS `view_Enclosure`;
/*!50001 DROP VIEW IF EXISTS `view_Enclosure`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Enclosure` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `rack_id` tinyint NOT NULL,
  `rack_name` tinyint NOT NULL,
  `nb_u` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `rack_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_FAQ`
--

DROP TABLE IF EXISTS `view_FAQ`;
/*!50001 DROP VIEW IF EXISTS `view_FAQ`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_FAQ` (
  `id` tinyint NOT NULL,
  `title` tinyint NOT NULL,
  `summary` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `category_id` tinyint NOT NULL,
  `category_name` tinyint NOT NULL,
  `error_code` tinyint NOT NULL,
  `key_words` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `category_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_FAQCategory`
--

DROP TABLE IF EXISTS `view_FAQCategory`;
/*!50001 DROP VIEW IF EXISTS `view_FAQCategory`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_FAQCategory` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Farm`
--

DROP TABLE IF EXISTS `view_Farm`;
/*!50001 DROP VIEW IF EXISTS `view_Farm`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Farm` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `redundancy` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_FiberChannelInterface`
--

DROP TABLE IF EXISTS `view_FiberChannelInterface`;
/*!50001 DROP VIEW IF EXISTS `view_FiberChannelInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_FiberChannelInterface` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `speed` tinyint NOT NULL,
  `topology` tinyint NOT NULL,
  `wwn` tinyint NOT NULL,
  `datacenterdevice_id` tinyint NOT NULL,
  `datacenterdevice_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `datacenterdevice_id_friendlyname` tinyint NOT NULL,
  `datacenterdevice_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_FunctionalCI`
--

DROP TABLE IF EXISTS `view_FunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_FunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_FunctionalCI` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Group`
--

DROP TABLE IF EXISTS `view_Group`;
/*!50001 DROP VIEW IF EXISTS `view_Group`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Group` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `owner_name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `parent_id` tinyint NOT NULL,
  `parent_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `parent_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Hypervisor`
--

DROP TABLE IF EXISTS `view_Hypervisor`;
/*!50001 DROP VIEW IF EXISTS `view_Hypervisor`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Hypervisor` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `farm_id` tinyint NOT NULL,
  `farm_name` tinyint NOT NULL,
  `server_id` tinyint NOT NULL,
  `server_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `farm_id_friendlyname` tinyint NOT NULL,
  `server_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IOSVersion`
--

DROP TABLE IF EXISTS `view_IOSVersion`;
/*!50001 DROP VIEW IF EXISTS `view_IOSVersion`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IOSVersion` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPAddress`
--

DROP TABLE IF EXISTS `view_IPAddress`;
/*!50001 DROP VIEW IF EXISTS `view_IPAddress`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPAddress` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `short_name` tinyint NOT NULL,
  `domain_id` tinyint NOT NULL,
  `domain_name` tinyint NOT NULL,
  `fqdn` tinyint NOT NULL,
  `aliases` tinyint NOT NULL,
  `usage_id` tinyint NOT NULL,
  `usage_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `domain_id_friendlyname` tinyint NOT NULL,
  `usage_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPBlock`
--

DROP TABLE IF EXISTS `view_IPBlock`;
/*!50001 DROP VIEW IF EXISTS `view_IPBlock`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPBlock` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `parent_org_id` tinyint NOT NULL,
  `parent_org_name` tinyint NOT NULL,
  `write_reason` tinyint NOT NULL,
  `occupancy` tinyint NOT NULL,
  `children_occupancy` tinyint NOT NULL,
  `subnet_occupancy` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `parent_org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPConfig`
--

DROP TABLE IF EXISTS `view_IPConfig`;
/*!50001 DROP VIEW IF EXISTS `view_IPConfig`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPConfig` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `ipv4_block_min_size` tinyint NOT NULL,
  `ipv4_block_cidr_aligned` tinyint NOT NULL,
  `delegate_to_children_only` tinyint NOT NULL,
  `reserve_subnet_IPs` tinyint NOT NULL,
  `ipv4_gateway_ip_format` tinyint NOT NULL,
  `subnet_low_watermark` tinyint NOT NULL,
  `subnet_high_watermark` tinyint NOT NULL,
  `iprange_low_watermark` tinyint NOT NULL,
  `iprange_high_watermark` tinyint NOT NULL,
  `ip_allow_duplicate_name` tinyint NOT NULL,
  `mac_address_format` tinyint NOT NULL,
  `ping_before_assign` tinyint NOT NULL,
  `ipv6_block_min_prefix` tinyint NOT NULL,
  `ipv6_block_cidr_aligned` tinyint NOT NULL,
  `ipv6_gateway_ip_format` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPInterface`
--

DROP TABLE IF EXISTS `view_IPInterface`;
/*!50001 DROP VIEW IF EXISTS `view_IPInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPInterface` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `speed` tinyint NOT NULL,
  `macaddress` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPObject`
--

DROP TABLE IF EXISTS `view_IPObject`;
/*!50001 DROP VIEW IF EXISTS `view_IPObject`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPObject` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPPhone`
--

DROP TABLE IF EXISTS `view_IPPhone`;
/*!50001 DROP VIEW IF EXISTS `view_IPPhone`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPPhone` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `phonenumber` tinyint NOT NULL,
  `ipaddress_id` tinyint NOT NULL,
  `ipaddress_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPRange`
--

DROP TABLE IF EXISTS `view_IPRange`;
/*!50001 DROP VIEW IF EXISTS `view_IPRange`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPRange` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `range` tinyint NOT NULL,
  `usage_id` tinyint NOT NULL,
  `usage_name` tinyint NOT NULL,
  `dhcp` tinyint NOT NULL,
  `write_reason` tinyint NOT NULL,
  `occupancy` tinyint NOT NULL,
  `alarm_water_mark` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `usage_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPRangeUsage`
--

DROP TABLE IF EXISTS `view_IPRangeUsage`;
/*!50001 DROP VIEW IF EXISTS `view_IPRangeUsage`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPRangeUsage` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPSubnet`
--

DROP TABLE IF EXISTS `view_IPSubnet`;
/*!50001 DROP VIEW IF EXISTS `view_IPSubnet`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPSubnet` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `write_reason` tinyint NOT NULL,
  `ip_occupancy` tinyint NOT NULL,
  `range_occupancy` tinyint NOT NULL,
  `alarm_water_mark` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPTriggerOnWaterMark`
--

DROP TABLE IF EXISTS `view_IPTriggerOnWaterMark`;
/*!50001 DROP VIEW IF EXISTS `view_IPTriggerOnWaterMark`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPTriggerOnWaterMark` (
  `id` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `target_class` tinyint NOT NULL,
  `event` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPUsage`
--

DROP TABLE IF EXISTS `view_IPUsage`;
/*!50001 DROP VIEW IF EXISTS `view_IPUsage`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPUsage` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPv4Address`
--

DROP TABLE IF EXISTS `view_IPv4Address`;
/*!50001 DROP VIEW IF EXISTS `view_IPv4Address`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPv4Address` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `short_name` tinyint NOT NULL,
  `domain_id` tinyint NOT NULL,
  `domain_name` tinyint NOT NULL,
  `fqdn` tinyint NOT NULL,
  `aliases` tinyint NOT NULL,
  `usage_id` tinyint NOT NULL,
  `usage_name` tinyint NOT NULL,
  `subnet_id` tinyint NOT NULL,
  `subnet_ip` tinyint NOT NULL,
  `range_id` tinyint NOT NULL,
  `range_name` tinyint NOT NULL,
  `ip` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `domain_id_friendlyname` tinyint NOT NULL,
  `usage_id_friendlyname` tinyint NOT NULL,
  `subnet_id_friendlyname` tinyint NOT NULL,
  `range_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPv4Block`
--

DROP TABLE IF EXISTS `view_IPv4Block`;
/*!50001 DROP VIEW IF EXISTS `view_IPv4Block`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPv4Block` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `parent_org_id` tinyint NOT NULL,
  `parent_org_name` tinyint NOT NULL,
  `write_reason` tinyint NOT NULL,
  `occupancy` tinyint NOT NULL,
  `children_occupancy` tinyint NOT NULL,
  `subnet_occupancy` tinyint NOT NULL,
  `parent_id` tinyint NOT NULL,
  `parent_name` tinyint NOT NULL,
  `firstip` tinyint NOT NULL,
  `lastip` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `parent_org_id_friendlyname` tinyint NOT NULL,
  `parent_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPv4Range`
--

DROP TABLE IF EXISTS `view_IPv4Range`;
/*!50001 DROP VIEW IF EXISTS `view_IPv4Range`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPv4Range` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `range` tinyint NOT NULL,
  `usage_id` tinyint NOT NULL,
  `usage_name` tinyint NOT NULL,
  `dhcp` tinyint NOT NULL,
  `write_reason` tinyint NOT NULL,
  `occupancy` tinyint NOT NULL,
  `alarm_water_mark` tinyint NOT NULL,
  `subnet_id` tinyint NOT NULL,
  `subnet_ip` tinyint NOT NULL,
  `firstip` tinyint NOT NULL,
  `lastip` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `usage_id_friendlyname` tinyint NOT NULL,
  `subnet_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPv4Subnet`
--

DROP TABLE IF EXISTS `view_IPv4Subnet`;
/*!50001 DROP VIEW IF EXISTS `view_IPv4Subnet`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPv4Subnet` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `write_reason` tinyint NOT NULL,
  `ip_occupancy` tinyint NOT NULL,
  `range_occupancy` tinyint NOT NULL,
  `alarm_water_mark` tinyint NOT NULL,
  `block_id` tinyint NOT NULL,
  `block_name` tinyint NOT NULL,
  `ip` tinyint NOT NULL,
  `mask` tinyint NOT NULL,
  `gatewayip` tinyint NOT NULL,
  `broadcastip` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `block_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPv6Address`
--

DROP TABLE IF EXISTS `view_IPv6Address`;
/*!50001 DROP VIEW IF EXISTS `view_IPv6Address`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPv6Address` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `short_name` tinyint NOT NULL,
  `domain_id` tinyint NOT NULL,
  `domain_name` tinyint NOT NULL,
  `fqdn` tinyint NOT NULL,
  `aliases` tinyint NOT NULL,
  `usage_id` tinyint NOT NULL,
  `usage_name` tinyint NOT NULL,
  `subnet_id` tinyint NOT NULL,
  `subnet_ip` tinyint NOT NULL,
  `range_id` tinyint NOT NULL,
  `range_name` tinyint NOT NULL,
  `ip` tinyint NOT NULL,
  `ip_text` tinyint NOT NULL,
  `ip_high` tinyint NOT NULL,
  `ip_low` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `domain_id_friendlyname` tinyint NOT NULL,
  `usage_id_friendlyname` tinyint NOT NULL,
  `subnet_id_friendlyname` tinyint NOT NULL,
  `range_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPv6Block`
--

DROP TABLE IF EXISTS `view_IPv6Block`;
/*!50001 DROP VIEW IF EXISTS `view_IPv6Block`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPv6Block` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `parent_org_id` tinyint NOT NULL,
  `parent_org_name` tinyint NOT NULL,
  `write_reason` tinyint NOT NULL,
  `occupancy` tinyint NOT NULL,
  `children_occupancy` tinyint NOT NULL,
  `subnet_occupancy` tinyint NOT NULL,
  `parent_id` tinyint NOT NULL,
  `parent_name` tinyint NOT NULL,
  `firstip` tinyint NOT NULL,
  `firstip_text` tinyint NOT NULL,
  `firstip_high` tinyint NOT NULL,
  `firstip_low` tinyint NOT NULL,
  `lastip` tinyint NOT NULL,
  `lastip_text` tinyint NOT NULL,
  `lastip_high` tinyint NOT NULL,
  `lastip_low` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `parent_org_id_friendlyname` tinyint NOT NULL,
  `parent_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPv6Range`
--

DROP TABLE IF EXISTS `view_IPv6Range`;
/*!50001 DROP VIEW IF EXISTS `view_IPv6Range`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPv6Range` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `range` tinyint NOT NULL,
  `usage_id` tinyint NOT NULL,
  `usage_name` tinyint NOT NULL,
  `dhcp` tinyint NOT NULL,
  `write_reason` tinyint NOT NULL,
  `occupancy` tinyint NOT NULL,
  `alarm_water_mark` tinyint NOT NULL,
  `subnet_id` tinyint NOT NULL,
  `subnet_ip` tinyint NOT NULL,
  `firstip` tinyint NOT NULL,
  `firstip_text` tinyint NOT NULL,
  `firstip_high` tinyint NOT NULL,
  `firstip_low` tinyint NOT NULL,
  `lastip` tinyint NOT NULL,
  `lastip_text` tinyint NOT NULL,
  `lastip_high` tinyint NOT NULL,
  `lastip_low` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `usage_id_friendlyname` tinyint NOT NULL,
  `subnet_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_IPv6Subnet`
--

DROP TABLE IF EXISTS `view_IPv6Subnet`;
/*!50001 DROP VIEW IF EXISTS `view_IPv6Subnet`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_IPv6Subnet` (
  `id` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `requestor_id` tinyint NOT NULL,
  `requestor_name` tinyint NOT NULL,
  `allocation_date` tinyint NOT NULL,
  `release_date` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `write_reason` tinyint NOT NULL,
  `ip_occupancy` tinyint NOT NULL,
  `range_occupancy` tinyint NOT NULL,
  `alarm_water_mark` tinyint NOT NULL,
  `block_id` tinyint NOT NULL,
  `block_name` tinyint NOT NULL,
  `ip` tinyint NOT NULL,
  `ip_text` tinyint NOT NULL,
  `ip_high` tinyint NOT NULL,
  `ip_low` tinyint NOT NULL,
  `mask` tinyint NOT NULL,
  `gatewayip` tinyint NOT NULL,
  `gatewayip_text` tinyint NOT NULL,
  `gatewayip_high` tinyint NOT NULL,
  `gatewayip_low` tinyint NOT NULL,
  `lastip` tinyint NOT NULL,
  `lastip_text` tinyint NOT NULL,
  `lastip_high` tinyint NOT NULL,
  `lastip_low` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `requestor_id_friendlyname` tinyint NOT NULL,
  `block_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_KnownError`
--

DROP TABLE IF EXISTS `view_KnownError`;
/*!50001 DROP VIEW IF EXISTS `view_KnownError`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_KnownError` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `cust_name` tinyint NOT NULL,
  `problem_id` tinyint NOT NULL,
  `problem_ref` tinyint NOT NULL,
  `symptom` tinyint NOT NULL,
  `root_cause` tinyint NOT NULL,
  `workaround` tinyint NOT NULL,
  `solution` tinyint NOT NULL,
  `error_code` tinyint NOT NULL,
  `domain` tinyint NOT NULL,
  `vendor` tinyint NOT NULL,
  `model` tinyint NOT NULL,
  `version` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `problem_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Licence`
--

DROP TABLE IF EXISTS `view_Licence`;
/*!50001 DROP VIEW IF EXISTS `view_Licence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Licence` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `usage_limit` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `licence_key` tinyint NOT NULL,
  `perpetual` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Location`
--

DROP TABLE IF EXISTS `view_Location`;
/*!50001 DROP VIEW IF EXISTS `view_Location`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Location` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `address` tinyint NOT NULL,
  `postal_code` tinyint NOT NULL,
  `city` tinyint NOT NULL,
  `country` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_LogicalInterface`
--

DROP TABLE IF EXISTS `view_LogicalInterface`;
/*!50001 DROP VIEW IF EXISTS `view_LogicalInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_LogicalInterface` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `speed` tinyint NOT NULL,
  `macaddress` tinyint NOT NULL,
  `virtualmachine_id` tinyint NOT NULL,
  `virtualmachine_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `virtualmachine_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_LogicalVolume`
--

DROP TABLE IF EXISTS `view_LogicalVolume`;
/*!50001 DROP VIEW IF EXISTS `view_LogicalVolume`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_LogicalVolume` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `lun_id` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `raid_level` tinyint NOT NULL,
  `size` tinyint NOT NULL,
  `storagesystem_id` tinyint NOT NULL,
  `storagesystem_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `storagesystem_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Middleware`
--

DROP TABLE IF EXISTS `view_Middleware`;
/*!50001 DROP VIEW IF EXISTS `view_Middleware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Middleware` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `system_id` tinyint NOT NULL,
  `system_name` tinyint NOT NULL,
  `software_id` tinyint NOT NULL,
  `software_name` tinyint NOT NULL,
  `softwarelicence_id` tinyint NOT NULL,
  `softwarelicence_name` tinyint NOT NULL,
  `path` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `system_id_friendlyname` tinyint NOT NULL,
  `system_id_finalclass_recall` tinyint NOT NULL,
  `software_id_friendlyname` tinyint NOT NULL,
  `softwarelicence_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_MiddlewareInstance`
--

DROP TABLE IF EXISTS `view_MiddlewareInstance`;
/*!50001 DROP VIEW IF EXISTS `view_MiddlewareInstance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_MiddlewareInstance` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `middleware_id` tinyint NOT NULL,
  `middleware_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `middleware_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_MobilePhone`
--

DROP TABLE IF EXISTS `view_MobilePhone`;
/*!50001 DROP VIEW IF EXISTS `view_MobilePhone`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_MobilePhone` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `phonenumber` tinyint NOT NULL,
  `imei` tinyint NOT NULL,
  `hw_pin` tinyint NOT NULL,
  `ipaddress_id` tinyint NOT NULL,
  `ipaddress_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Model`
--

DROP TABLE IF EXISTS `view_Model`;
/*!50001 DROP VIEW IF EXISTS `view_Model`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Model` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NAS`
--

DROP TABLE IF EXISTS `view_NAS`;
/*!50001 DROP VIEW IF EXISTS `view_NAS`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_NAS` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `rack_id` tinyint NOT NULL,
  `rack_name` tinyint NOT NULL,
  `enclosure_id` tinyint NOT NULL,
  `enclosure_name` tinyint NOT NULL,
  `nb_u` tinyint NOT NULL,
  `powerA_id` tinyint NOT NULL,
  `powerA_name` tinyint NOT NULL,
  `powerB_id` tinyint NOT NULL,
  `powerB_name` tinyint NOT NULL,
  `redundancy` tinyint NOT NULL,
  `managementip_id` tinyint NOT NULL,
  `managementip_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `rack_id_friendlyname` tinyint NOT NULL,
  `enclosure_id_friendlyname` tinyint NOT NULL,
  `powerA_id_friendlyname` tinyint NOT NULL,
  `powerA_id_finalclass_recall` tinyint NOT NULL,
  `powerB_id_friendlyname` tinyint NOT NULL,
  `powerB_id_finalclass_recall` tinyint NOT NULL,
  `managementip_id_friendlyname` tinyint NOT NULL,
  `managementip_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NASFileSystem`
--

DROP TABLE IF EXISTS `view_NASFileSystem`;
/*!50001 DROP VIEW IF EXISTS `view_NASFileSystem`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_NASFileSystem` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `raid_level` tinyint NOT NULL,
  `size` tinyint NOT NULL,
  `nas_id` tinyint NOT NULL,
  `nas_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `nas_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NetworkDevice`
--

DROP TABLE IF EXISTS `view_NetworkDevice`;
/*!50001 DROP VIEW IF EXISTS `view_NetworkDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_NetworkDevice` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `rack_id` tinyint NOT NULL,
  `rack_name` tinyint NOT NULL,
  `enclosure_id` tinyint NOT NULL,
  `enclosure_name` tinyint NOT NULL,
  `nb_u` tinyint NOT NULL,
  `powerA_id` tinyint NOT NULL,
  `powerA_name` tinyint NOT NULL,
  `powerB_id` tinyint NOT NULL,
  `powerB_name` tinyint NOT NULL,
  `redundancy` tinyint NOT NULL,
  `managementip_id` tinyint NOT NULL,
  `managementip_name` tinyint NOT NULL,
  `networkdevicetype_id` tinyint NOT NULL,
  `networkdevicetype_name` tinyint NOT NULL,
  `iosversion_id` tinyint NOT NULL,
  `iosversion_name` tinyint NOT NULL,
  `ram` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `rack_id_friendlyname` tinyint NOT NULL,
  `enclosure_id_friendlyname` tinyint NOT NULL,
  `powerA_id_friendlyname` tinyint NOT NULL,
  `powerA_id_finalclass_recall` tinyint NOT NULL,
  `powerB_id_friendlyname` tinyint NOT NULL,
  `powerB_id_finalclass_recall` tinyint NOT NULL,
  `managementip_id_friendlyname` tinyint NOT NULL,
  `managementip_id_finalclass_recall` tinyint NOT NULL,
  `networkdevicetype_id_friendlyname` tinyint NOT NULL,
  `iosversion_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NetworkDeviceType`
--

DROP TABLE IF EXISTS `view_NetworkDeviceType`;
/*!50001 DROP VIEW IF EXISTS `view_NetworkDeviceType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_NetworkDeviceType` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_NetworkInterface`
--

DROP TABLE IF EXISTS `view_NetworkInterface`;
/*!50001 DROP VIEW IF EXISTS `view_NetworkInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_NetworkInterface` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_OSFamily`
--

DROP TABLE IF EXISTS `view_OSFamily`;
/*!50001 DROP VIEW IF EXISTS `view_OSFamily`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_OSFamily` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_OSLicence`
--

DROP TABLE IF EXISTS `view_OSLicence`;
/*!50001 DROP VIEW IF EXISTS `view_OSLicence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_OSLicence` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `usage_limit` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `licence_key` tinyint NOT NULL,
  `perpetual` tinyint NOT NULL,
  `osversion_id` tinyint NOT NULL,
  `osversion_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `osversion_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_OSPatch`
--

DROP TABLE IF EXISTS `view_OSPatch`;
/*!50001 DROP VIEW IF EXISTS `view_OSPatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_OSPatch` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `osversion_id` tinyint NOT NULL,
  `osversion_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `osversion_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_OSVersion`
--

DROP TABLE IF EXISTS `view_OSVersion`;
/*!50001 DROP VIEW IF EXISTS `view_OSVersion`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_OSVersion` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `osfamily_id` tinyint NOT NULL,
  `osfamily_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `osfamily_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Organization`
--

DROP TABLE IF EXISTS `view_Organization`;
/*!50001 DROP VIEW IF EXISTS `view_Organization`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Organization` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `code` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `parent_id` tinyint NOT NULL,
  `parent_name` tinyint NOT NULL,
  `deliverymodel_id` tinyint NOT NULL,
  `deliverymodel_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `parent_id_friendlyname` tinyint NOT NULL,
  `deliverymodel_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_OtherSoftware`
--

DROP TABLE IF EXISTS `view_OtherSoftware`;
/*!50001 DROP VIEW IF EXISTS `view_OtherSoftware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_OtherSoftware` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `system_id` tinyint NOT NULL,
  `system_name` tinyint NOT NULL,
  `software_id` tinyint NOT NULL,
  `software_name` tinyint NOT NULL,
  `softwarelicence_id` tinyint NOT NULL,
  `softwarelicence_name` tinyint NOT NULL,
  `path` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `system_id_friendlyname` tinyint NOT NULL,
  `system_id_finalclass_recall` tinyint NOT NULL,
  `software_id_friendlyname` tinyint NOT NULL,
  `softwarelicence_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PC`
--

DROP TABLE IF EXISTS `view_PC`;
/*!50001 DROP VIEW IF EXISTS `view_PC`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_PC` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `osfamily_id` tinyint NOT NULL,
  `osfamily_name` tinyint NOT NULL,
  `osversion_id` tinyint NOT NULL,
  `osversion_name` tinyint NOT NULL,
  `cpu` tinyint NOT NULL,
  `ram` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `ipaddress_id` tinyint NOT NULL,
  `ipaddress_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `osfamily_id_friendlyname` tinyint NOT NULL,
  `osversion_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PCSoftware`
--

DROP TABLE IF EXISTS `view_PCSoftware`;
/*!50001 DROP VIEW IF EXISTS `view_PCSoftware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_PCSoftware` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `system_id` tinyint NOT NULL,
  `system_name` tinyint NOT NULL,
  `software_id` tinyint NOT NULL,
  `software_name` tinyint NOT NULL,
  `softwarelicence_id` tinyint NOT NULL,
  `softwarelicence_name` tinyint NOT NULL,
  `path` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `system_id_friendlyname` tinyint NOT NULL,
  `system_id_finalclass_recall` tinyint NOT NULL,
  `software_id_friendlyname` tinyint NOT NULL,
  `softwarelicence_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PDU`
--

DROP TABLE IF EXISTS `view_PDU`;
/*!50001 DROP VIEW IF EXISTS `view_PDU`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_PDU` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `rack_id` tinyint NOT NULL,
  `rack_name` tinyint NOT NULL,
  `powerstart_id` tinyint NOT NULL,
  `powerstart_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `rack_id_friendlyname` tinyint NOT NULL,
  `powerstart_id_friendlyname` tinyint NOT NULL,
  `powerstart_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Patch`
--

DROP TABLE IF EXISTS `view_Patch`;
/*!50001 DROP VIEW IF EXISTS `view_Patch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Patch` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Peripheral`
--

DROP TABLE IF EXISTS `view_Peripheral`;
/*!50001 DROP VIEW IF EXISTS `view_Peripheral`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Peripheral` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Person`
--

DROP TABLE IF EXISTS `view_Person`;
/*!50001 DROP VIEW IF EXISTS `view_Person`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Person` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `phone` tinyint NOT NULL,
  `notify` tinyint NOT NULL,
  `function` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `employee_number` tinyint NOT NULL,
  `mobile_phone` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `manager_id` tinyint NOT NULL,
  `manager_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `manager_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Phone`
--

DROP TABLE IF EXISTS `view_Phone`;
/*!50001 DROP VIEW IF EXISTS `view_Phone`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Phone` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `phonenumber` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PhysicalDevice`
--

DROP TABLE IF EXISTS `view_PhysicalDevice`;
/*!50001 DROP VIEW IF EXISTS `view_PhysicalDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_PhysicalDevice` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PhysicalInterface`
--

DROP TABLE IF EXISTS `view_PhysicalInterface`;
/*!50001 DROP VIEW IF EXISTS `view_PhysicalInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_PhysicalInterface` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `comment` tinyint NOT NULL,
  `speed` tinyint NOT NULL,
  `macaddress` tinyint NOT NULL,
  `connectableci_id` tinyint NOT NULL,
  `connectableci_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `connectableci_id_friendlyname` tinyint NOT NULL,
  `connectableci_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PowerConnection`
--

DROP TABLE IF EXISTS `view_PowerConnection`;
/*!50001 DROP VIEW IF EXISTS `view_PowerConnection`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_PowerConnection` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PowerSource`
--

DROP TABLE IF EXISTS `view_PowerSource`;
/*!50001 DROP VIEW IF EXISTS `view_PowerSource`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_PowerSource` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Printer`
--

DROP TABLE IF EXISTS `view_Printer`;
/*!50001 DROP VIEW IF EXISTS `view_Printer`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Printer` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `ipaddress_id` tinyint NOT NULL,
  `ipaddress_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Problem`
--

DROP TABLE IF EXISTS `view_Problem`;
/*!50001 DROP VIEW IF EXISTS `view_Problem`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Problem` (
  `id` tinyint NOT NULL,
  `ref` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `caller_id` tinyint NOT NULL,
  `caller_name` tinyint NOT NULL,
  `team_id` tinyint NOT NULL,
  `team_name` tinyint NOT NULL,
  `agent_id` tinyint NOT NULL,
  `agent_name` tinyint NOT NULL,
  `title` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `last_update` tinyint NOT NULL,
  `close_date` tinyint NOT NULL,
  `private_log` tinyint NOT NULL,
  `private_log_index` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `service_id` tinyint NOT NULL,
  `service_name` tinyint NOT NULL,
  `servicesubcategory_id` tinyint NOT NULL,
  `servicesubcategory_name` tinyint NOT NULL,
  `product` tinyint NOT NULL,
  `impact` tinyint NOT NULL,
  `urgency` tinyint NOT NULL,
  `priority` tinyint NOT NULL,
  `related_change_id` tinyint NOT NULL,
  `related_change_ref` tinyint NOT NULL,
  `assignment_date` tinyint NOT NULL,
  `resolution_date` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `caller_id_friendlyname` tinyint NOT NULL,
  `team_id_friendlyname` tinyint NOT NULL,
  `agent_id_friendlyname` tinyint NOT NULL,
  `service_id_friendlyname` tinyint NOT NULL,
  `servicesubcategory_id_friendlyname` tinyint NOT NULL,
  `related_change_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ProviderContract`
--

DROP TABLE IF EXISTS `view_ProviderContract`;
/*!50001 DROP VIEW IF EXISTS `view_ProviderContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_ProviderContract` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `cost` tinyint NOT NULL,
  `cost_currency` tinyint NOT NULL,
  `contracttype_id` tinyint NOT NULL,
  `contracttype_name` tinyint NOT NULL,
  `billing_frequency` tinyint NOT NULL,
  `cost_unit` tinyint NOT NULL,
  `provider_id` tinyint NOT NULL,
  `provider_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `sla` tinyint NOT NULL,
  `coverage` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `contracttype_id_friendlyname` tinyint NOT NULL,
  `provider_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Rack`
--

DROP TABLE IF EXISTS `view_Rack`;
/*!50001 DROP VIEW IF EXISTS `view_Rack`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Rack` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `nb_u` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SANSwitch`
--

DROP TABLE IF EXISTS `view_SANSwitch`;
/*!50001 DROP VIEW IF EXISTS `view_SANSwitch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_SANSwitch` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `rack_id` tinyint NOT NULL,
  `rack_name` tinyint NOT NULL,
  `enclosure_id` tinyint NOT NULL,
  `enclosure_name` tinyint NOT NULL,
  `nb_u` tinyint NOT NULL,
  `powerA_id` tinyint NOT NULL,
  `powerA_name` tinyint NOT NULL,
  `powerB_id` tinyint NOT NULL,
  `powerB_name` tinyint NOT NULL,
  `redundancy` tinyint NOT NULL,
  `managementip_id` tinyint NOT NULL,
  `managementip_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `rack_id_friendlyname` tinyint NOT NULL,
  `enclosure_id_friendlyname` tinyint NOT NULL,
  `powerA_id_friendlyname` tinyint NOT NULL,
  `powerA_id_finalclass_recall` tinyint NOT NULL,
  `powerB_id_friendlyname` tinyint NOT NULL,
  `powerB_id_finalclass_recall` tinyint NOT NULL,
  `managementip_id_friendlyname` tinyint NOT NULL,
  `managementip_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SLA`
--

DROP TABLE IF EXISTS `view_SLA`;
/*!50001 DROP VIEW IF EXISTS `view_SLA`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_SLA` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SLT`
--

DROP TABLE IF EXISTS `view_SLT`;
/*!50001 DROP VIEW IF EXISTS `view_SLT`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_SLT` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `priority` tinyint NOT NULL,
  `request_type` tinyint NOT NULL,
  `metric` tinyint NOT NULL,
  `value` tinyint NOT NULL,
  `unit` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Server`
--

DROP TABLE IF EXISTS `view_Server`;
/*!50001 DROP VIEW IF EXISTS `view_Server`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Server` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `rack_id` tinyint NOT NULL,
  `rack_name` tinyint NOT NULL,
  `enclosure_id` tinyint NOT NULL,
  `enclosure_name` tinyint NOT NULL,
  `nb_u` tinyint NOT NULL,
  `powerA_id` tinyint NOT NULL,
  `powerA_name` tinyint NOT NULL,
  `powerB_id` tinyint NOT NULL,
  `powerB_name` tinyint NOT NULL,
  `redundancy` tinyint NOT NULL,
  `managementip_id` tinyint NOT NULL,
  `managementip_name` tinyint NOT NULL,
  `osfamily_id` tinyint NOT NULL,
  `osfamily_name` tinyint NOT NULL,
  `osversion_id` tinyint NOT NULL,
  `osversion_name` tinyint NOT NULL,
  `oslicence_id` tinyint NOT NULL,
  `oslicence_name` tinyint NOT NULL,
  `cpu` tinyint NOT NULL,
  `ram` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `rack_id_friendlyname` tinyint NOT NULL,
  `enclosure_id_friendlyname` tinyint NOT NULL,
  `powerA_id_friendlyname` tinyint NOT NULL,
  `powerA_id_finalclass_recall` tinyint NOT NULL,
  `powerB_id_friendlyname` tinyint NOT NULL,
  `powerB_id_finalclass_recall` tinyint NOT NULL,
  `managementip_id_friendlyname` tinyint NOT NULL,
  `managementip_id_finalclass_recall` tinyint NOT NULL,
  `osfamily_id_friendlyname` tinyint NOT NULL,
  `osversion_id_friendlyname` tinyint NOT NULL,
  `oslicence_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Service`
--

DROP TABLE IF EXISTS `view_Service`;
/*!50001 DROP VIEW IF EXISTS `view_Service`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Service` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `servicefamily_id` tinyint NOT NULL,
  `servicefamily_name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `servicefamily_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ServiceFamily`
--

DROP TABLE IF EXISTS `view_ServiceFamily`;
/*!50001 DROP VIEW IF EXISTS `view_ServiceFamily`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_ServiceFamily` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_ServiceSubcategory`
--

DROP TABLE IF EXISTS `view_ServiceSubcategory`;
/*!50001 DROP VIEW IF EXISTS `view_ServiceSubcategory`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_ServiceSubcategory` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `service_id` tinyint NOT NULL,
  `service_org_id` tinyint NOT NULL,
  `service_name` tinyint NOT NULL,
  `service_provider` tinyint NOT NULL,
  `request_type` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `service_id_friendlyname` tinyint NOT NULL,
  `service_org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Software`
--

DROP TABLE IF EXISTS `view_Software`;
/*!50001 DROP VIEW IF EXISTS `view_Software`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Software` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `vendor` tinyint NOT NULL,
  `version` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SoftwareInstance`
--

DROP TABLE IF EXISTS `view_SoftwareInstance`;
/*!50001 DROP VIEW IF EXISTS `view_SoftwareInstance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_SoftwareInstance` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `system_id` tinyint NOT NULL,
  `system_name` tinyint NOT NULL,
  `software_id` tinyint NOT NULL,
  `software_name` tinyint NOT NULL,
  `softwarelicence_id` tinyint NOT NULL,
  `softwarelicence_name` tinyint NOT NULL,
  `path` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `system_id_friendlyname` tinyint NOT NULL,
  `system_id_finalclass_recall` tinyint NOT NULL,
  `software_id_friendlyname` tinyint NOT NULL,
  `softwarelicence_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SoftwareLicence`
--

DROP TABLE IF EXISTS `view_SoftwareLicence`;
/*!50001 DROP VIEW IF EXISTS `view_SoftwareLicence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_SoftwareLicence` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `usage_limit` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `licence_key` tinyint NOT NULL,
  `perpetual` tinyint NOT NULL,
  `software_id` tinyint NOT NULL,
  `software_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `software_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_SoftwarePatch`
--

DROP TABLE IF EXISTS `view_SoftwarePatch`;
/*!50001 DROP VIEW IF EXISTS `view_SoftwarePatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_SoftwarePatch` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `software_id` tinyint NOT NULL,
  `software_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `software_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_StorageSystem`
--

DROP TABLE IF EXISTS `view_StorageSystem`;
/*!50001 DROP VIEW IF EXISTS `view_StorageSystem`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_StorageSystem` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `rack_id` tinyint NOT NULL,
  `rack_name` tinyint NOT NULL,
  `enclosure_id` tinyint NOT NULL,
  `enclosure_name` tinyint NOT NULL,
  `nb_u` tinyint NOT NULL,
  `powerA_id` tinyint NOT NULL,
  `powerA_name` tinyint NOT NULL,
  `powerB_id` tinyint NOT NULL,
  `powerB_name` tinyint NOT NULL,
  `redundancy` tinyint NOT NULL,
  `managementip_id` tinyint NOT NULL,
  `managementip_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `rack_id_friendlyname` tinyint NOT NULL,
  `enclosure_id_friendlyname` tinyint NOT NULL,
  `powerA_id_friendlyname` tinyint NOT NULL,
  `powerA_id_finalclass_recall` tinyint NOT NULL,
  `powerB_id_friendlyname` tinyint NOT NULL,
  `powerB_id_finalclass_recall` tinyint NOT NULL,
  `managementip_id_friendlyname` tinyint NOT NULL,
  `managementip_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Subnet`
--

DROP TABLE IF EXISTS `view_Subnet`;
/*!50001 DROP VIEW IF EXISTS `view_Subnet`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Subnet` (
  `id` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `subnet_name` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `ip` tinyint NOT NULL,
  `ip_mask` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Tablet`
--

DROP TABLE IF EXISTS `view_Tablet`;
/*!50001 DROP VIEW IF EXISTS `view_Tablet`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Tablet` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `ipaddress_id` tinyint NOT NULL,
  `ipaddress_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Tape`
--

DROP TABLE IF EXISTS `view_Tape`;
/*!50001 DROP VIEW IF EXISTS `view_Tape`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Tape` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `size` tinyint NOT NULL,
  `tapelibrary_id` tinyint NOT NULL,
  `tapelibrary_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `tapelibrary_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_TapeLibrary`
--

DROP TABLE IF EXISTS `view_TapeLibrary`;
/*!50001 DROP VIEW IF EXISTS `view_TapeLibrary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_TapeLibrary` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `rack_id` tinyint NOT NULL,
  `rack_name` tinyint NOT NULL,
  `enclosure_id` tinyint NOT NULL,
  `enclosure_name` tinyint NOT NULL,
  `nb_u` tinyint NOT NULL,
  `powerA_id` tinyint NOT NULL,
  `powerA_name` tinyint NOT NULL,
  `powerB_id` tinyint NOT NULL,
  `powerB_name` tinyint NOT NULL,
  `redundancy` tinyint NOT NULL,
  `managementip_id` tinyint NOT NULL,
  `managementip_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL,
  `rack_id_friendlyname` tinyint NOT NULL,
  `enclosure_id_friendlyname` tinyint NOT NULL,
  `powerA_id_friendlyname` tinyint NOT NULL,
  `powerA_id_finalclass_recall` tinyint NOT NULL,
  `powerB_id_friendlyname` tinyint NOT NULL,
  `powerB_id_finalclass_recall` tinyint NOT NULL,
  `managementip_id_friendlyname` tinyint NOT NULL,
  `managementip_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Team`
--

DROP TABLE IF EXISTS `view_Team`;
/*!50001 DROP VIEW IF EXISTS `view_Team`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Team` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `phone` tinyint NOT NULL,
  `notify` tinyint NOT NULL,
  `function` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_TelephonyCI`
--

DROP TABLE IF EXISTS `view_TelephonyCI`;
/*!50001 DROP VIEW IF EXISTS `view_TelephonyCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_TelephonyCI` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `brand_id` tinyint NOT NULL,
  `brand_name` tinyint NOT NULL,
  `model_id` tinyint NOT NULL,
  `model_name` tinyint NOT NULL,
  `asset_number` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `end_of_warranty` tinyint NOT NULL,
  `phonenumber` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL,
  `brand_id_friendlyname` tinyint NOT NULL,
  `model_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Ticket`
--

DROP TABLE IF EXISTS `view_Ticket`;
/*!50001 DROP VIEW IF EXISTS `view_Ticket`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Ticket` (
  `id` tinyint NOT NULL,
  `ref` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `caller_id` tinyint NOT NULL,
  `caller_name` tinyint NOT NULL,
  `team_id` tinyint NOT NULL,
  `team_name` tinyint NOT NULL,
  `agent_id` tinyint NOT NULL,
  `agent_name` tinyint NOT NULL,
  `title` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `last_update` tinyint NOT NULL,
  `close_date` tinyint NOT NULL,
  `private_log` tinyint NOT NULL,
  `private_log_index` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `caller_id_friendlyname` tinyint NOT NULL,
  `team_id_friendlyname` tinyint NOT NULL,
  `agent_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Typology`
--

DROP TABLE IF EXISTS `view_Typology`;
/*!50001 DROP VIEW IF EXISTS `view_Typology`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_Typology` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_UserRequest`
--

DROP TABLE IF EXISTS `view_UserRequest`;
/*!50001 DROP VIEW IF EXISTS `view_UserRequest`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_UserRequest` (
  `id` tinyint NOT NULL,
  `ref` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `caller_id` tinyint NOT NULL,
  `caller_name` tinyint NOT NULL,
  `team_id` tinyint NOT NULL,
  `team_name` tinyint NOT NULL,
  `agent_id` tinyint NOT NULL,
  `agent_name` tinyint NOT NULL,
  `title` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `last_update` tinyint NOT NULL,
  `close_date` tinyint NOT NULL,
  `private_log` tinyint NOT NULL,
  `private_log_index` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `request_type` tinyint NOT NULL,
  `impact` tinyint NOT NULL,
  `priority` tinyint NOT NULL,
  `urgency` tinyint NOT NULL,
  `origin` tinyint NOT NULL,
  `approver_id` tinyint NOT NULL,
  `approver_email` tinyint NOT NULL,
  `service_id` tinyint NOT NULL,
  `service_name` tinyint NOT NULL,
  `servicesubcategory_id` tinyint NOT NULL,
  `servicesubcategory_name` tinyint NOT NULL,
  `escalation_flag` tinyint NOT NULL,
  `escalation_reason` tinyint NOT NULL,
  `assignment_date` tinyint NOT NULL,
  `resolution_date` tinyint NOT NULL,
  `last_pending_date` tinyint NOT NULL,
  `cumulatedpending` tinyint NOT NULL,
  `cumulatedpending_started` tinyint NOT NULL,
  `cumulatedpending_laststart` tinyint NOT NULL,
  `cumulatedpending_stopped` tinyint NOT NULL,
  `tto` tinyint NOT NULL,
  `tto_started` tinyint NOT NULL,
  `tto_laststart` tinyint NOT NULL,
  `tto_stopped` tinyint NOT NULL,
  `tto_75_deadline` tinyint NOT NULL,
  `tto_75_passed` tinyint NOT NULL,
  `tto_75_triggered` tinyint NOT NULL,
  `tto_75_overrun` tinyint NOT NULL,
  `tto_100_deadline` tinyint NOT NULL,
  `tto_100_passed` tinyint NOT NULL,
  `tto_100_triggered` tinyint NOT NULL,
  `tto_100_overrun` tinyint NOT NULL,
  `ttr` tinyint NOT NULL,
  `ttr_started` tinyint NOT NULL,
  `ttr_laststart` tinyint NOT NULL,
  `ttr_stopped` tinyint NOT NULL,
  `ttr_75_deadline` tinyint NOT NULL,
  `ttr_75_passed` tinyint NOT NULL,
  `ttr_75_triggered` tinyint NOT NULL,
  `ttr_75_overrun` tinyint NOT NULL,
  `ttr_100_deadline` tinyint NOT NULL,
  `ttr_100_passed` tinyint NOT NULL,
  `ttr_100_triggered` tinyint NOT NULL,
  `ttr_100_overrun` tinyint NOT NULL,
  `tto_escalation_deadline` tinyint NOT NULL,
  `sla_tto_passed` tinyint NOT NULL,
  `sla_tto_over` tinyint NOT NULL,
  `ttr_escalation_deadline` tinyint NOT NULL,
  `sla_ttr_passed` tinyint NOT NULL,
  `sla_ttr_over` tinyint NOT NULL,
  `time_spent` tinyint NOT NULL,
  `resolution_code` tinyint NOT NULL,
  `solution` tinyint NOT NULL,
  `pending_reason` tinyint NOT NULL,
  `parent_request_id` tinyint NOT NULL,
  `parent_request_ref` tinyint NOT NULL,
  `parent_problem_id` tinyint NOT NULL,
  `parent_problem_ref` tinyint NOT NULL,
  `parent_change_id` tinyint NOT NULL,
  `parent_change_ref` tinyint NOT NULL,
  `public_log` tinyint NOT NULL,
  `public_log_index` tinyint NOT NULL,
  `user_satisfaction` tinyint NOT NULL,
  `user_comment` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `caller_id_friendlyname` tinyint NOT NULL,
  `team_id_friendlyname` tinyint NOT NULL,
  `agent_id_friendlyname` tinyint NOT NULL,
  `approver_id_friendlyname` tinyint NOT NULL,
  `service_id_friendlyname` tinyint NOT NULL,
  `servicesubcategory_id_friendlyname` tinyint NOT NULL,
  `parent_request_id_friendlyname` tinyint NOT NULL,
  `parent_problem_id_friendlyname` tinyint NOT NULL,
  `parent_change_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_VLAN`
--

DROP TABLE IF EXISTS `view_VLAN`;
/*!50001 DROP VIEW IF EXISTS `view_VLAN`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_VLAN` (
  `id` tinyint NOT NULL,
  `vlan_tag` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `org_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_VRF`
--

DROP TABLE IF EXISTS `view_VRF`;
/*!50001 DROP VIEW IF EXISTS `view_VRF`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_VRF` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `route_dist` tinyint NOT NULL,
  `route_trgt` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_VirtualDevice`
--

DROP TABLE IF EXISTS `view_VirtualDevice`;
/*!50001 DROP VIEW IF EXISTS `view_VirtualDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_VirtualDevice` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_VirtualHost`
--

DROP TABLE IF EXISTS `view_VirtualHost`;
/*!50001 DROP VIEW IF EXISTS `view_VirtualHost`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_VirtualHost` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_VirtualMachine`
--

DROP TABLE IF EXISTS `view_VirtualMachine`;
/*!50001 DROP VIEW IF EXISTS `view_VirtualMachine`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_VirtualMachine` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `virtualhost_id` tinyint NOT NULL,
  `virtualhost_name` tinyint NOT NULL,
  `osfamily_id` tinyint NOT NULL,
  `osfamily_name` tinyint NOT NULL,
  `osversion_id` tinyint NOT NULL,
  `osversion_name` tinyint NOT NULL,
  `oslicence_id` tinyint NOT NULL,
  `oslicence_name` tinyint NOT NULL,
  `cpu` tinyint NOT NULL,
  `ram` tinyint NOT NULL,
  `managementip_id` tinyint NOT NULL,
  `managementip_name` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `virtualhost_id_friendlyname` tinyint NOT NULL,
  `virtualhost_id_finalclass_recall` tinyint NOT NULL,
  `osfamily_id_friendlyname` tinyint NOT NULL,
  `osversion_id_friendlyname` tinyint NOT NULL,
  `oslicence_id_friendlyname` tinyint NOT NULL,
  `managementip_id_friendlyname` tinyint NOT NULL,
  `managementip_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_WANLink`
--

DROP TABLE IF EXISTS `view_WANLink`;
/*!50001 DROP VIEW IF EXISTS `view_WANLink`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_WANLink` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `location_id1` tinyint NOT NULL,
  `location_name1` tinyint NOT NULL,
  `location_id2` tinyint NOT NULL,
  `location_name2` tinyint NOT NULL,
  `type_id` tinyint NOT NULL,
  `type_name` tinyint NOT NULL,
  `rate` tinyint NOT NULL,
  `burst_rate` tinyint NOT NULL,
  `underlying_rate` tinyint NOT NULL,
  `networkinterface_id1` tinyint NOT NULL,
  `networkinterface_name1` tinyint NOT NULL,
  `networkinterface_id2` tinyint NOT NULL,
  `networkinterface_name2` tinyint NOT NULL,
  `carrier_id` tinyint NOT NULL,
  `carrier_name` tinyint NOT NULL,
  `carrier_reference` tinyint NOT NULL,
  `internal_reference` tinyint NOT NULL,
  `purchase_date` tinyint NOT NULL,
  `renewal_date` tinyint NOT NULL,
  `decommissioning_date` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `location_id1_friendlyname` tinyint NOT NULL,
  `location_id2_friendlyname` tinyint NOT NULL,
  `type_id_friendlyname` tinyint NOT NULL,
  `networkinterface_id1_friendlyname` tinyint NOT NULL,
  `networkinterface_id1_finalclass_recall` tinyint NOT NULL,
  `networkinterface_id2_friendlyname` tinyint NOT NULL,
  `networkinterface_id2_finalclass_recall` tinyint NOT NULL,
  `carrier_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_WANType`
--

DROP TABLE IF EXISTS `view_WANType`;
/*!50001 DROP VIEW IF EXISTS `view_WANType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_WANType` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_WebApplication`
--

DROP TABLE IF EXISTS `view_WebApplication`;
/*!50001 DROP VIEW IF EXISTS `view_WebApplication`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_WebApplication` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `webserver_id` tinyint NOT NULL,
  `webserver_name` tinyint NOT NULL,
  `url` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `webserver_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_WebServer`
--

DROP TABLE IF EXISTS `view_WebServer`;
/*!50001 DROP VIEW IF EXISTS `view_WebServer`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_WebServer` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `org_id` tinyint NOT NULL,
  `organization_name` tinyint NOT NULL,
  `business_criticity` tinyint NOT NULL,
  `move2production` tinyint NOT NULL,
  `system_id` tinyint NOT NULL,
  `system_name` tinyint NOT NULL,
  `software_id` tinyint NOT NULL,
  `software_name` tinyint NOT NULL,
  `softwarelicence_id` tinyint NOT NULL,
  `softwarelicence_name` tinyint NOT NULL,
  `path` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `finalclass` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `org_id_friendlyname` tinyint NOT NULL,
  `system_id_friendlyname` tinyint NOT NULL,
  `system_id_finalclass_recall` tinyint NOT NULL,
  `software_id_friendlyname` tinyint NOT NULL,
  `softwarelicence_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_WorkOrder`
--

DROP TABLE IF EXISTS `view_WorkOrder`;
/*!50001 DROP VIEW IF EXISTS `view_WorkOrder`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_WorkOrder` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `ticket_id` tinyint NOT NULL,
  `ticket_ref` tinyint NOT NULL,
  `team_id` tinyint NOT NULL,
  `team_name` tinyint NOT NULL,
  `agent_id` tinyint NOT NULL,
  `agent_email` tinyint NOT NULL,
  `start_date` tinyint NOT NULL,
  `end_date` tinyint NOT NULL,
  `log` tinyint NOT NULL,
  `log_index` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ticket_id_friendlyname` tinyint NOT NULL,
  `ticket_id_finalclass_recall` tinyint NOT NULL,
  `team_id_friendlyname` tinyint NOT NULL,
  `agent_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkApplicationSolutionToBusinessProcess`
--

DROP TABLE IF EXISTS `view_lnkApplicationSolutionToBusinessProcess`;
/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToBusinessProcess`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkApplicationSolutionToBusinessProcess` (
  `id` tinyint NOT NULL,
  `businessprocess_id` tinyint NOT NULL,
  `businessprocess_name` tinyint NOT NULL,
  `applicationsolution_id` tinyint NOT NULL,
  `applicationsolution_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `businessprocess_id_friendlyname` tinyint NOT NULL,
  `applicationsolution_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkApplicationSolutionToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkApplicationSolutionToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkApplicationSolutionToFunctionalCI` (
  `id` tinyint NOT NULL,
  `applicationsolution_id` tinyint NOT NULL,
  `applicationsolution_name` tinyint NOT NULL,
  `functionalci_id` tinyint NOT NULL,
  `functionalci_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `applicationsolution_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkConnectableCIToNetworkDevice`
--

DROP TABLE IF EXISTS `view_lnkConnectableCIToNetworkDevice`;
/*!50001 DROP VIEW IF EXISTS `view_lnkConnectableCIToNetworkDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkConnectableCIToNetworkDevice` (
  `id` tinyint NOT NULL,
  `networkdevice_id` tinyint NOT NULL,
  `networkdevice_name` tinyint NOT NULL,
  `connectableci_id` tinyint NOT NULL,
  `connectableci_name` tinyint NOT NULL,
  `network_port` tinyint NOT NULL,
  `device_port` tinyint NOT NULL,
  `connection_type` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `networkdevice_id_friendlyname` tinyint NOT NULL,
  `connectableci_id_friendlyname` tinyint NOT NULL,
  `connectableci_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContactToContract`
--

DROP TABLE IF EXISTS `view_lnkContactToContract`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkContactToContract` (
  `id` tinyint NOT NULL,
  `contract_id` tinyint NOT NULL,
  `contract_name` tinyint NOT NULL,
  `contact_id` tinyint NOT NULL,
  `contact_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `contract_id_friendlyname` tinyint NOT NULL,
  `contract_id_finalclass_recall` tinyint NOT NULL,
  `contact_id_friendlyname` tinyint NOT NULL,
  `contact_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContactToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkContactToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkContactToFunctionalCI` (
  `id` tinyint NOT NULL,
  `functionalci_id` tinyint NOT NULL,
  `functionalci_name` tinyint NOT NULL,
  `contact_id` tinyint NOT NULL,
  `contact_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `functionalci_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_finalclass_recall` tinyint NOT NULL,
  `contact_id_friendlyname` tinyint NOT NULL,
  `contact_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContactToIPObject`
--

DROP TABLE IF EXISTS `view_lnkContactToIPObject`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToIPObject`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkContactToIPObject` (
  `id` tinyint NOT NULL,
  `ipobject_id` tinyint NOT NULL,
  `contact_id` tinyint NOT NULL,
  `contact_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ipobject_id_friendlyname` tinyint NOT NULL,
  `ipobject_id_finalclass_recall` tinyint NOT NULL,
  `contact_id_friendlyname` tinyint NOT NULL,
  `contact_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContactToService`
--

DROP TABLE IF EXISTS `view_lnkContactToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkContactToService` (
  `id` tinyint NOT NULL,
  `service_id` tinyint NOT NULL,
  `service_name` tinyint NOT NULL,
  `contact_id` tinyint NOT NULL,
  `contact_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `service_id_friendlyname` tinyint NOT NULL,
  `contact_id_friendlyname` tinyint NOT NULL,
  `contact_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContactToTicket`
--

DROP TABLE IF EXISTS `view_lnkContactToTicket`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToTicket`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkContactToTicket` (
  `id` tinyint NOT NULL,
  `ticket_id` tinyint NOT NULL,
  `ticket_ref` tinyint NOT NULL,
  `contact_id` tinyint NOT NULL,
  `contact_email` tinyint NOT NULL,
  `role` tinyint NOT NULL,
  `role_code` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ticket_id_friendlyname` tinyint NOT NULL,
  `ticket_id_finalclass_recall` tinyint NOT NULL,
  `contact_id_friendlyname` tinyint NOT NULL,
  `contact_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkContractToDocument`
--

DROP TABLE IF EXISTS `view_lnkContractToDocument`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContractToDocument`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkContractToDocument` (
  `id` tinyint NOT NULL,
  `contract_id` tinyint NOT NULL,
  `contract_name` tinyint NOT NULL,
  `document_id` tinyint NOT NULL,
  `document_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `contract_id_friendlyname` tinyint NOT NULL,
  `contract_id_finalclass_recall` tinyint NOT NULL,
  `document_id_friendlyname` tinyint NOT NULL,
  `document_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkCustomerContractToService`
--

DROP TABLE IF EXISTS `view_lnkCustomerContractToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkCustomerContractToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkCustomerContractToService` (
  `id` tinyint NOT NULL,
  `customercontract_id` tinyint NOT NULL,
  `customercontract_name` tinyint NOT NULL,
  `service_id` tinyint NOT NULL,
  `service_name` tinyint NOT NULL,
  `sla_id` tinyint NOT NULL,
  `sla_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `customercontract_id_friendlyname` tinyint NOT NULL,
  `service_id_friendlyname` tinyint NOT NULL,
  `sla_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDeliveryModelToContact`
--

DROP TABLE IF EXISTS `view_lnkDeliveryModelToContact`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDeliveryModelToContact`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkDeliveryModelToContact` (
  `id` tinyint NOT NULL,
  `deliverymodel_id` tinyint NOT NULL,
  `deliverymodel_name` tinyint NOT NULL,
  `contact_id` tinyint NOT NULL,
  `contact_name` tinyint NOT NULL,
  `role_id` tinyint NOT NULL,
  `role_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `deliverymodel_id_friendlyname` tinyint NOT NULL,
  `contact_id_friendlyname` tinyint NOT NULL,
  `contact_id_finalclass_recall` tinyint NOT NULL,
  `role_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocToIPObject`
--

DROP TABLE IF EXISTS `view_lnkDocToIPObject`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocToIPObject`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkDocToIPObject` (
  `id` tinyint NOT NULL,
  `ipobject_id` tinyint NOT NULL,
  `document_id` tinyint NOT NULL,
  `document_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ipobject_id_friendlyname` tinyint NOT NULL,
  `ipobject_id_finalclass_recall` tinyint NOT NULL,
  `document_id_friendlyname` tinyint NOT NULL,
  `document_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToError`
--

DROP TABLE IF EXISTS `view_lnkDocumentToError`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToError`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkDocumentToError` (
  `id` tinyint NOT NULL,
  `document_id` tinyint NOT NULL,
  `document_name` tinyint NOT NULL,
  `error_id` tinyint NOT NULL,
  `error_name` tinyint NOT NULL,
  `link_type` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `document_id_friendlyname` tinyint NOT NULL,
  `document_id_finalclass_recall` tinyint NOT NULL,
  `error_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkDocumentToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkDocumentToFunctionalCI` (
  `id` tinyint NOT NULL,
  `functionalci_id` tinyint NOT NULL,
  `functionalci_name` tinyint NOT NULL,
  `document_id` tinyint NOT NULL,
  `document_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `functionalci_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_finalclass_recall` tinyint NOT NULL,
  `document_id_friendlyname` tinyint NOT NULL,
  `document_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToLicence`
--

DROP TABLE IF EXISTS `view_lnkDocumentToLicence`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToLicence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkDocumentToLicence` (
  `id` tinyint NOT NULL,
  `licence_id` tinyint NOT NULL,
  `licence_name` tinyint NOT NULL,
  `document_id` tinyint NOT NULL,
  `document_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `licence_id_friendlyname` tinyint NOT NULL,
  `licence_id_finalclass_recall` tinyint NOT NULL,
  `document_id_friendlyname` tinyint NOT NULL,
  `document_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToPatch`
--

DROP TABLE IF EXISTS `view_lnkDocumentToPatch`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToPatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkDocumentToPatch` (
  `id` tinyint NOT NULL,
  `patch_id` tinyint NOT NULL,
  `patch_name` tinyint NOT NULL,
  `document_id` tinyint NOT NULL,
  `document_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `patch_id_friendlyname` tinyint NOT NULL,
  `patch_id_finalclass_recall` tinyint NOT NULL,
  `document_id_friendlyname` tinyint NOT NULL,
  `document_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToService`
--

DROP TABLE IF EXISTS `view_lnkDocumentToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkDocumentToService` (
  `id` tinyint NOT NULL,
  `service_id` tinyint NOT NULL,
  `service_name` tinyint NOT NULL,
  `document_id` tinyint NOT NULL,
  `document_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `service_id_friendlyname` tinyint NOT NULL,
  `document_id_friendlyname` tinyint NOT NULL,
  `document_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkDocumentToSoftware`
--

DROP TABLE IF EXISTS `view_lnkDocumentToSoftware`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToSoftware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkDocumentToSoftware` (
  `id` tinyint NOT NULL,
  `software_id` tinyint NOT NULL,
  `software_name` tinyint NOT NULL,
  `document_id` tinyint NOT NULL,
  `document_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `software_id_friendlyname` tinyint NOT NULL,
  `document_id_friendlyname` tinyint NOT NULL,
  `document_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkErrorToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkErrorToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkErrorToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkErrorToFunctionalCI` (
  `id` tinyint NOT NULL,
  `functionalci_id` tinyint NOT NULL,
  `functionalci_name` tinyint NOT NULL,
  `error_id` tinyint NOT NULL,
  `error_name` tinyint NOT NULL,
  `reason` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `functionalci_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_finalclass_recall` tinyint NOT NULL,
  `error_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkFunctionalCIToOSPatch`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToOSPatch`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToOSPatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkFunctionalCIToOSPatch` (
  `id` tinyint NOT NULL,
  `ospatch_id` tinyint NOT NULL,
  `ospatch_name` tinyint NOT NULL,
  `functionalci_id` tinyint NOT NULL,
  `functionalci_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ospatch_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkFunctionalCIToProviderContract`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToProviderContract`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToProviderContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkFunctionalCIToProviderContract` (
  `id` tinyint NOT NULL,
  `providercontract_id` tinyint NOT NULL,
  `providercontract_name` tinyint NOT NULL,
  `functionalci_id` tinyint NOT NULL,
  `functionalci_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `providercontract_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkFunctionalCIToService`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkFunctionalCIToService` (
  `id` tinyint NOT NULL,
  `service_id` tinyint NOT NULL,
  `service_name` tinyint NOT NULL,
  `functionalci_id` tinyint NOT NULL,
  `functionalci_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `service_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkFunctionalCIToTicket`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToTicket`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToTicket`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkFunctionalCIToTicket` (
  `id` tinyint NOT NULL,
  `ticket_id` tinyint NOT NULL,
  `ticket_ref` tinyint NOT NULL,
  `ticket_title` tinyint NOT NULL,
  `functionalci_id` tinyint NOT NULL,
  `functionalci_name` tinyint NOT NULL,
  `impact` tinyint NOT NULL,
  `impact_code` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ticket_id_friendlyname` tinyint NOT NULL,
  `ticket_id_finalclass_recall` tinyint NOT NULL,
  `functionalci_id_friendlyname` tinyint NOT NULL,
  `functionalci_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkGroupToCI`
--

DROP TABLE IF EXISTS `view_lnkGroupToCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkGroupToCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkGroupToCI` (
  `id` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `group_name` tinyint NOT NULL,
  `ci_id` tinyint NOT NULL,
  `ci_name` tinyint NOT NULL,
  `reason` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `group_id_friendlyname` tinyint NOT NULL,
  `ci_id_friendlyname` tinyint NOT NULL,
  `ci_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkIPAdressToIPAddress`
--

DROP TABLE IF EXISTS `view_lnkIPAdressToIPAddress`;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPAdressToIPAddress`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkIPAdressToIPAddress` (
  `id` tinyint NOT NULL,
  `ip1_id` tinyint NOT NULL,
  `ip1_fqdn` tinyint NOT NULL,
  `ip2_id` tinyint NOT NULL,
  `ip2_fqdn` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ip1_id_friendlyname` tinyint NOT NULL,
  `ip1_id_finalclass_recall` tinyint NOT NULL,
  `ip2_id_friendlyname` tinyint NOT NULL,
  `ip2_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkIPBlockToLocation`
--

DROP TABLE IF EXISTS `view_lnkIPBlockToLocation`;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPBlockToLocation`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkIPBlockToLocation` (
  `id` tinyint NOT NULL,
  `ipblock_id` tinyint NOT NULL,
  `ipblock_name` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ipblock_id_friendlyname` tinyint NOT NULL,
  `ipblock_id_finalclass_recall` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkIPInterfaceToIPAddress`
--

DROP TABLE IF EXISTS `view_lnkIPInterfaceToIPAddress`;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPInterfaceToIPAddress`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkIPInterfaceToIPAddress` (
  `id` tinyint NOT NULL,
  `ipinterface_id` tinyint NOT NULL,
  `ipinterface_name` tinyint NOT NULL,
  `ipaddress_id` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ipinterface_id_friendlyname` tinyint NOT NULL,
  `ipinterface_id_finalclass_recall` tinyint NOT NULL,
  `ipaddress_id_friendlyname` tinyint NOT NULL,
  `ipaddress_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkIPObjectToTicket`
--

DROP TABLE IF EXISTS `view_lnkIPObjectToTicket`;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPObjectToTicket`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkIPObjectToTicket` (
  `id` tinyint NOT NULL,
  `ipobject_id` tinyint NOT NULL,
  `ticket_id` tinyint NOT NULL,
  `ticket_ref` tinyint NOT NULL,
  `ticket_title` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ipobject_id_friendlyname` tinyint NOT NULL,
  `ipobject_id_finalclass_recall` tinyint NOT NULL,
  `ticket_id_friendlyname` tinyint NOT NULL,
  `ticket_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkIPSubnetToLocation`
--

DROP TABLE IF EXISTS `view_lnkIPSubnetToLocation`;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPSubnetToLocation`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkIPSubnetToLocation` (
  `id` tinyint NOT NULL,
  `ipsubnet_id` tinyint NOT NULL,
  `ipsubnet_name` tinyint NOT NULL,
  `location_id` tinyint NOT NULL,
  `location_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ipsubnet_id_friendlyname` tinyint NOT NULL,
  `ipsubnet_id_finalclass_recall` tinyint NOT NULL,
  `location_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkIPSubnetToVLAN`
--

DROP TABLE IF EXISTS `view_lnkIPSubnetToVLAN`;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPSubnetToVLAN`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkIPSubnetToVLAN` (
  `id` tinyint NOT NULL,
  `ipsubnet_id` tinyint NOT NULL,
  `ipsubnet_name` tinyint NOT NULL,
  `vlan_id` tinyint NOT NULL,
  `vlan_tag` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ipsubnet_id_friendlyname` tinyint NOT NULL,
  `ipsubnet_id_finalclass_recall` tinyint NOT NULL,
  `vlan_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkIPSubnetToVRF`
--

DROP TABLE IF EXISTS `view_lnkIPSubnetToVRF`;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPSubnetToVRF`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkIPSubnetToVRF` (
  `id` tinyint NOT NULL,
  `ipsubnet_id` tinyint NOT NULL,
  `ipsubnet_name` tinyint NOT NULL,
  `vrf_id` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `ipsubnet_id_friendlyname` tinyint NOT NULL,
  `ipsubnet_id_finalclass_recall` tinyint NOT NULL,
  `vrf_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkPersonToTeam`
--

DROP TABLE IF EXISTS `view_lnkPersonToTeam`;
/*!50001 DROP VIEW IF EXISTS `view_lnkPersonToTeam`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkPersonToTeam` (
  `id` tinyint NOT NULL,
  `team_id` tinyint NOT NULL,
  `team_name` tinyint NOT NULL,
  `person_id` tinyint NOT NULL,
  `person_name` tinyint NOT NULL,
  `role_id` tinyint NOT NULL,
  `role_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `team_id_friendlyname` tinyint NOT NULL,
  `person_id_friendlyname` tinyint NOT NULL,
  `role_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkPhysicalInterfaceToVLAN`
--

DROP TABLE IF EXISTS `view_lnkPhysicalInterfaceToVLAN`;
/*!50001 DROP VIEW IF EXISTS `view_lnkPhysicalInterfaceToVLAN`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkPhysicalInterfaceToVLAN` (
  `id` tinyint NOT NULL,
  `physicalinterface_id` tinyint NOT NULL,
  `physicalinterface_name` tinyint NOT NULL,
  `physicalinterface_device_id` tinyint NOT NULL,
  `physicalinterface_device_name` tinyint NOT NULL,
  `vlan_id` tinyint NOT NULL,
  `vlan_tag` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `physicalinterface_id_friendlyname` tinyint NOT NULL,
  `physicalinterface_device_id_friendlyname` tinyint NOT NULL,
  `vlan_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkPhysicalInterfaceToVRF`
--

DROP TABLE IF EXISTS `view_lnkPhysicalInterfaceToVRF`;
/*!50001 DROP VIEW IF EXISTS `view_lnkPhysicalInterfaceToVRF`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkPhysicalInterfaceToVRF` (
  `id` tinyint NOT NULL,
  `physicalinterface_id` tinyint NOT NULL,
  `physicalinterface_name` tinyint NOT NULL,
  `physicalinterface_device_id` tinyint NOT NULL,
  `physicalinterface_device_name` tinyint NOT NULL,
  `vrf_id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `physicalinterface_id_friendlyname` tinyint NOT NULL,
  `physicalinterface_device_id_friendlyname` tinyint NOT NULL,
  `vrf_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkProviderContractToService`
--

DROP TABLE IF EXISTS `view_lnkProviderContractToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkProviderContractToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkProviderContractToService` (
  `id` tinyint NOT NULL,
  `service_id` tinyint NOT NULL,
  `service_name` tinyint NOT NULL,
  `providercontract_id` tinyint NOT NULL,
  `providercontract_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `service_id_friendlyname` tinyint NOT NULL,
  `providercontract_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkSLAToSLT`
--

DROP TABLE IF EXISTS `view_lnkSLAToSLT`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSLAToSLT`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkSLAToSLT` (
  `id` tinyint NOT NULL,
  `sla_id` tinyint NOT NULL,
  `sla_name` tinyint NOT NULL,
  `slt_id` tinyint NOT NULL,
  `slt_name` tinyint NOT NULL,
  `slt_metric` tinyint NOT NULL,
  `slt_request_type` tinyint NOT NULL,
  `slt_ticket_priority` tinyint NOT NULL,
  `slt_value` tinyint NOT NULL,
  `slt_value_unit` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `sla_id_friendlyname` tinyint NOT NULL,
  `slt_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkSanToDatacenterDevice`
--

DROP TABLE IF EXISTS `view_lnkSanToDatacenterDevice`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSanToDatacenterDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkSanToDatacenterDevice` (
  `id` tinyint NOT NULL,
  `san_id` tinyint NOT NULL,
  `san_name` tinyint NOT NULL,
  `datacenterdevice_id` tinyint NOT NULL,
  `datacenterdevice_name` tinyint NOT NULL,
  `san_port` tinyint NOT NULL,
  `datacenterdevice_port` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `san_id_friendlyname` tinyint NOT NULL,
  `datacenterdevice_id_friendlyname` tinyint NOT NULL,
  `datacenterdevice_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkServerToVolume`
--

DROP TABLE IF EXISTS `view_lnkServerToVolume`;
/*!50001 DROP VIEW IF EXISTS `view_lnkServerToVolume`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkServerToVolume` (
  `id` tinyint NOT NULL,
  `volume_id` tinyint NOT NULL,
  `volume_name` tinyint NOT NULL,
  `server_id` tinyint NOT NULL,
  `server_name` tinyint NOT NULL,
  `size_used` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `volume_id_friendlyname` tinyint NOT NULL,
  `server_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkSoftwareInstanceToSoftwarePatch`
--

DROP TABLE IF EXISTS `view_lnkSoftwareInstanceToSoftwarePatch`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSoftwareInstanceToSoftwarePatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkSoftwareInstanceToSoftwarePatch` (
  `id` tinyint NOT NULL,
  `softwarepatch_id` tinyint NOT NULL,
  `softwarepatch_name` tinyint NOT NULL,
  `softwareinstance_id` tinyint NOT NULL,
  `softwareinstance_name` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `softwarepatch_id_friendlyname` tinyint NOT NULL,
  `softwareinstance_id_friendlyname` tinyint NOT NULL,
  `softwareinstance_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkSubnetToVLAN`
--

DROP TABLE IF EXISTS `view_lnkSubnetToVLAN`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSubnetToVLAN`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkSubnetToVLAN` (
  `id` tinyint NOT NULL,
  `subnet_id` tinyint NOT NULL,
  `subnet_ip` tinyint NOT NULL,
  `subnet_name` tinyint NOT NULL,
  `vlan_id` tinyint NOT NULL,
  `vlan_tag` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `subnet_id_friendlyname` tinyint NOT NULL,
  `vlan_id_friendlyname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_lnkVirtualDeviceToVolume`
--

DROP TABLE IF EXISTS `view_lnkVirtualDeviceToVolume`;
/*!50001 DROP VIEW IF EXISTS `view_lnkVirtualDeviceToVolume`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_lnkVirtualDeviceToVolume` (
  `id` tinyint NOT NULL,
  `volume_id` tinyint NOT NULL,
  `volume_name` tinyint NOT NULL,
  `virtualdevice_id` tinyint NOT NULL,
  `virtualdevice_name` tinyint NOT NULL,
  `size_used` tinyint NOT NULL,
  `friendlyname` tinyint NOT NULL,
  `volume_id_friendlyname` tinyint NOT NULL,
  `virtualdevice_id_friendlyname` tinyint NOT NULL,
  `virtualdevice_id_finalclass_recall` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `virtualdevice`
--

DROP TABLE IF EXISTS `virtualdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtualdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('implementation','obsolete','production','stock') COLLATE utf8_unicode_ci DEFAULT 'production',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualdevice`
--

LOCK TABLES `virtualdevice` WRITE;
/*!40000 ALTER TABLE `virtualdevice` DISABLE KEYS */;
INSERT INTO `virtualdevice` VALUES (16,'production'),(17,'production'),(18,'production'),(19,'production'),(20,'production'),(21,'production'),(22,'production'),(23,'production'),(24,'production');
/*!40000 ALTER TABLE `virtualdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualhost`
--

DROP TABLE IF EXISTS `virtualhost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtualhost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualhost`
--

LOCK TABLES `virtualhost` WRITE;
/*!40000 ALTER TABLE `virtualhost` DISABLE KEYS */;
INSERT INTO `virtualhost` VALUES (16),(17),(18),(19),(20);
/*!40000 ALTER TABLE `virtualhost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualmachine`
--

DROP TABLE IF EXISTS `virtualmachine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtualmachine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `virtualhost_id` int(11) DEFAULT '0',
  `osfamily_id` int(11) DEFAULT '0',
  `osversion_id` int(11) DEFAULT '0',
  `oslicence_id` int(11) DEFAULT '0',
  `cpu` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `managementip` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `managementip_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `virtualhost_id` (`virtualhost_id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `oslicence_id` (`oslicence_id`),
  KEY `managementip_id` (`managementip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualmachine`
--

LOCK TABLES `virtualmachine` WRITE;
/*!40000 ALTER TABLE `virtualmachine` DISABLE KEYS */;
INSERT INTO `virtualmachine` VALUES (21,16,6,8,0,'','','',0),(22,16,7,9,0,'','','',0),(23,16,6,8,0,'','','',0),(24,17,7,9,0,'','','',0);
/*!40000 ALTER TABLE `virtualmachine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vlan`
--

DROP TABLE IF EXISTS `vlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vlan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vlan_tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `description` text COLLATE utf8_unicode_ci,
  `org_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vlan`
--

LOCK TABLES `vlan` WRITE;
/*!40000 ALTER TABLE `vlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `vlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vrf`
--

DROP TABLE IF EXISTS `vrf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vrf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_dist` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `route_trgt` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vrf`
--

LOCK TABLES `vrf` WRITE;
/*!40000 ALTER TABLE `vrf` DISABLE KEYS */;
/*!40000 ALTER TABLE `vrf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wanlink`
--

DROP TABLE IF EXISTS `wanlink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wanlink` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('implementation','obsolete','production','stock') COLLATE utf8_unicode_ci DEFAULT 'production',
  `location_id1` int(11) DEFAULT '0',
  `location_id2` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `rate` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `burst_rate` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `underlying_rate` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `networkinterface_id1` int(11) DEFAULT '0',
  `networkinterface_id2` int(11) DEFAULT '0',
  `carrier_id` int(11) DEFAULT '0',
  `carrier_ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `internal_reference` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `purchase_date` date DEFAULT NULL,
  `renewal_date` date DEFAULT NULL,
  `decommissioning_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id1` (`location_id1`),
  KEY `location_id2` (`location_id2`),
  KEY `type_id` (`type_id`),
  KEY `networkinterface_id1` (`networkinterface_id1`),
  KEY `networkinterface_id2` (`networkinterface_id2`),
  KEY `carrier_id` (`carrier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wanlink`
--

LOCK TABLES `wanlink` WRITE;
/*!40000 ALTER TABLE `wanlink` DISABLE KEYS */;
/*!40000 ALTER TABLE `wanlink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wantype`
--

DROP TABLE IF EXISTS `wantype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wantype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wantype`
--

LOCK TABLES `wantype` WRITE;
/*!40000 ALTER TABLE `wantype` DISABLE KEYS */;
/*!40000 ALTER TABLE `wantype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webapplication`
--

DROP TABLE IF EXISTS `webapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webapplication` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `webserver_id` int(11) DEFAULT '0',
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `webserver_id` (`webserver_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webapplication`
--

LOCK TABLES `webapplication` WRITE;
/*!40000 ALTER TABLE `webapplication` DISABLE KEYS */;
INSERT INTO `webapplication` VALUES (10,9,''),(30,29,''),(31,29,'');
/*!40000 ALTER TABLE `webapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webserver`
--

DROP TABLE IF EXISTS `webserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webserver` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webserver`
--

LOCK TABLES `webserver` WRITE;
/*!40000 ALTER TABLE `webserver` DISABLE KEYS */;
INSERT INTO `webserver` VALUES (9),(29);
/*!40000 ALTER TABLE `webserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workorder`
--

DROP TABLE IF EXISTS `workorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `status` enum('closed','open') COLLATE utf8_unicode_ci DEFAULT 'open',
  `description` text COLLATE utf8_unicode_ci,
  `ticket_id` int(11) DEFAULT '0',
  `team_id` int(11) DEFAULT '0',
  `owner_id` int(11) DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `log` longtext COLLATE utf8_unicode_ci,
  `log_index` blob,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `team_id` (`team_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workorder`
--

LOCK TABLES `workorder` WRITE;
/*!40000 ALTER TABLE `workorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `workorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `view_ASNumber`
--

/*!50001 DROP TABLE IF EXISTS `view_ASNumber`*/;
/*!50001 DROP VIEW IF EXISTS `view_ASNumber`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ASNumber` AS select distinct `_asnumber`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_asnumber`.`number` AS `number`,`_asnumber`.`registrar_id` AS `registrar_id`,`Organization_registrar_id_organization`.`name` AS `registrar_name`,`_asnumber`.`whois` AS `whois`,`_asnumber`.`validity_end` AS `validity_end`,`_asnumber`.`renewal_date` AS `renewal_date`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Organization_registrar_id_organization`.`name`,'')) as char charset utf8) AS `registrar_id_friendlyname` from ((`asnumber` `_asnumber` left join `organization` `Organization_registrar_id_organization` on((`_asnumber`.`registrar_id` = `Organization_registrar_id_organization`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_asnumber`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ApplicationSolution`
--

/*!50001 DROP TABLE IF EXISTS `view_ApplicationSolution`*/;
/*!50001 DROP VIEW IF EXISTS `view_ApplicationSolution`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ApplicationSolution` AS select distinct `_applicationsolution`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_applicationsolution`.`status` AS `status`,`_applicationsolution`.`redundancy` AS `redundancy`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`applicationsolution` `_applicationsolution` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_applicationsolution`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Attachment`
--

/*!50001 DROP TABLE IF EXISTS `view_Attachment`*/;
/*!50001 DROP VIEW IF EXISTS `view_Attachment`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Attachment` AS select distinct `_attachment`.`id` AS `id`,`_attachment`.`expire` AS `expire`,`_attachment`.`temp_id` AS `temp_id`,`_attachment`.`item_class` AS `item_class`,`_attachment`.`item_id` AS `item_id`,`_attachment`.`item_org_id` AS `item_org_id`,`_attachment`.`contents_mimetype` AS `contents`,`_attachment`.`contents_data` AS `contents_data`,`_attachment`.`contents_filename` AS `contents_filename`,cast(concat(coalesce(`_attachment`.`item_class`,''),coalesce(' ',''),coalesce(`_attachment`.`temp_id`,'')) as char charset utf8) AS `friendlyname` from `attachment` `_attachment` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Brand`
--

/*!50001 DROP TABLE IF EXISTS `view_Brand`*/;
/*!50001 DROP VIEW IF EXISTS `view_Brand`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Brand` AS select distinct `_brand`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`brand` `_brand` join `typology` `_typology` on((`_brand`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_BusinessProcess`
--

/*!50001 DROP TABLE IF EXISTS `view_BusinessProcess`*/;
/*!50001 DROP VIEW IF EXISTS `view_BusinessProcess`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_BusinessProcess` AS select distinct `_businessprocess`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_businessprocess`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`businessprocess` `_businessprocess` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_businessprocess`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Change`
--

/*!50001 DROP TABLE IF EXISTS `view_Change`*/;
/*!50001 DROP VIEW IF EXISTS `view_Change`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Change` AS select distinct `_ticket_change`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket_change`.`status` AS `status`,`_ticket_change`.`category` AS `category`,`_ticket_change`.`reject_reason` AS `reject_reason`,`_ticket_change`.`changemanager_id` AS `changemanager_id`,`Person_changemanager_id_contact`.`email` AS `changemanager_email`,`_ticket_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_ticket_change`.`creation_date` AS `creation_date`,`_ticket_change`.`approval_date` AS `approval_date`,`_ticket_change`.`fallback_plan` AS `fallback_plan`,`_ticket_change`.`outage` AS `outage`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_changemanager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_changemanager_id_contact`.`name`,'')) as char charset utf8) AS `changemanager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname` from (((`ticket_change` `_ticket_change` left join (`person` `Person_changemanager_id_person` join `contact` `Person_changemanager_id_contact` on((`Person_changemanager_id_person`.`id` = `Person_changemanager_id_contact`.`id`))) on((`_ticket_change`.`changemanager_id` = `Person_changemanager_id_person`.`id`))) left join (`ticket_change` `Change_parent_id_ticket_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_ticket_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_ticket_change`.`parent_id` = `Change_parent_id_ticket_change`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_ticket_change`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ConnectableCI`
--

/*!50001 DROP TABLE IF EXISTS `view_ConnectableCI`*/;
/*!50001 DROP VIEW IF EXISTS `view_ConnectableCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ConnectableCI` AS select distinct `_connectableci`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`connectableci` `_connectableci` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_connectableci`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_connectableci`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Contact`
--

/*!50001 DROP TABLE IF EXISTS `view_Contact`*/;
/*!50001 DROP VIEW IF EXISTS `view_Contact`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Contact` AS select distinct `_contact`.`id` AS `id`,`_contact`.`name` AS `name`,`_contact`.`status` AS `status`,`_contact`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_contact`.`email` AS `email`,`_contact`.`phone` AS `phone`,`_contact`.`notify` AS `notify`,`_contact`.`function` AS `function`,`_contact`.`finalclass` AS `finalclass`,if((`_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`_contact`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`contact` `_contact` join `organization` `Organization_org_id_organization` on((`_contact`.`org_id` = `Organization_org_id_organization`.`id`))) left join `person` `_fn_Person_person` on((`_contact`.`id` = `_fn_Person_person`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ContactType`
--

/*!50001 DROP TABLE IF EXISTS `view_ContactType`*/;
/*!50001 DROP VIEW IF EXISTS `view_ContactType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ContactType` AS select distinct `_contacttype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`contacttype` `_contacttype` join `typology` `_typology` on((`_contacttype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Contract`
--

/*!50001 DROP TABLE IF EXISTS `view_Contract`*/;
/*!50001 DROP VIEW IF EXISTS `view_Contract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Contract` AS select distinct `_contract`.`id` AS `id`,`_contract`.`name` AS `name`,`_contract`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_contract`.`description` AS `description`,`_contract`.`start_date` AS `start_date`,`_contract`.`end_date` AS `end_date`,`_contract`.`cost` AS `cost`,`_contract`.`cost_currency` AS `cost_currency`,`_contract`.`contracttype_id` AS `contracttype_id`,`ContractType_contracttype_id_typology`.`name` AS `contracttype_name`,`_contract`.`billing_frequency` AS `billing_frequency`,`_contract`.`cost_unit` AS `cost_unit`,`_contract`.`provider_id` AS `provider_id`,`Organization_provider_id_organization`.`name` AS `provider_name`,`_contract`.`status` AS `status`,`_contract`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contract`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ContractType_contracttype_id_typology`.`name`,'')) as char charset utf8) AS `contracttype_id_friendlyname`,cast(concat(coalesce(`Organization_provider_id_organization`.`name`,'')) as char charset utf8) AS `provider_id_friendlyname` from (((`contract` `_contract` join `organization` `Organization_org_id_organization` on((`_contract`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`contracttype` `ContractType_contracttype_id_contracttype` join `typology` `ContractType_contracttype_id_typology` on((`ContractType_contracttype_id_contracttype`.`id` = `ContractType_contracttype_id_typology`.`id`))) on((`_contract`.`contracttype_id` = `ContractType_contracttype_id_contracttype`.`id`))) join `organization` `Organization_provider_id_organization` on((`_contract`.`provider_id` = `Organization_provider_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ContractType`
--

/*!50001 DROP TABLE IF EXISTS `view_ContractType`*/;
/*!50001 DROP VIEW IF EXISTS `view_ContractType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ContractType` AS select distinct `_contracttype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`contracttype` `_contracttype` join `typology` `_typology` on((`_contracttype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_CustomerContract`
--

/*!50001 DROP TABLE IF EXISTS `view_CustomerContract`*/;
/*!50001 DROP VIEW IF EXISTS `view_CustomerContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_CustomerContract` AS select distinct `_customercontract`.`id` AS `id`,`_contract`.`name` AS `name`,`_contract`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_contract`.`description` AS `description`,`_contract`.`start_date` AS `start_date`,`_contract`.`end_date` AS `end_date`,`_contract`.`cost` AS `cost`,`_contract`.`cost_currency` AS `cost_currency`,`_contract`.`contracttype_id` AS `contracttype_id`,`ContractType_contracttype_id_typology`.`name` AS `contracttype_name`,`_contract`.`billing_frequency` AS `billing_frequency`,`_contract`.`cost_unit` AS `cost_unit`,`_contract`.`provider_id` AS `provider_id`,`Organization_provider_id_organization`.`name` AS `provider_name`,`_contract`.`status` AS `status`,`_contract`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contract`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ContractType_contracttype_id_typology`.`name`,'')) as char charset utf8) AS `contracttype_id_friendlyname`,cast(concat(coalesce(`Organization_provider_id_organization`.`name`,'')) as char charset utf8) AS `provider_id_friendlyname` from (`customercontract` `_customercontract` join (((`contract` `_contract` join `organization` `Organization_org_id_organization` on((`_contract`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`contracttype` `ContractType_contracttype_id_contracttype` join `typology` `ContractType_contracttype_id_typology` on((`ContractType_contracttype_id_contracttype`.`id` = `ContractType_contracttype_id_typology`.`id`))) on((`_contract`.`contracttype_id` = `ContractType_contracttype_id_contracttype`.`id`))) join `organization` `Organization_provider_id_organization` on((`_contract`.`provider_id` = `Organization_provider_id_organization`.`id`))) on((`_customercontract`.`id` = `_contract`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DBServer`
--

/*!50001 DROP TABLE IF EXISTS `view_DBServer`*/;
/*!50001 DROP VIEW IF EXISTS `view_DBServer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DBServer` AS select distinct `_dbserver`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`dbserver` `_dbserver` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_dbserver`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_dbserver`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DNSObject`
--

/*!50001 DROP TABLE IF EXISTS `view_DNSObject`*/;
/*!50001 DROP VIEW IF EXISTS `view_DNSObject`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DNSObject` AS select distinct `_dnsobject`.`id` AS `id`,`_dnsobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_dnsobject`.`name` AS `name`,`_dnsobject`.`comment` AS `comment`,`_dnsobject`.`finalclass` AS `finalclass`,if((`_dnsobject`.`finalclass` = 'DNSObject'),cast(concat(coalesce('DNSObject','')) as char charset utf8),cast(concat(coalesce(`_dnsobject`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`dnsobject` `_dnsobject` join `organization` `Organization_org_id_organization` on((`_dnsobject`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DatabaseSchema`
--

/*!50001 DROP TABLE IF EXISTS `view_DatabaseSchema`*/;
/*!50001 DROP VIEW IF EXISTS `view_DatabaseSchema`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DatabaseSchema` AS select distinct `_databaseschema`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_databaseschema`.`dbserver_id` AS `dbserver_id`,`DBServer_dbserver_id_functionalci`.`name` AS `dbserver_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DBServer_dbserver_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `dbserver_id_friendlyname` from ((`databaseschema` `_databaseschema` join ((`dbserver` `DBServer_dbserver_id_dbserver` join `functionalci` `DBServer_dbserver_id_functionalci` on((`DBServer_dbserver_id_dbserver`.`id` = `DBServer_dbserver_id_functionalci`.`id`))) join (`softwareinstance` `DBServer_dbserver_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`DBServer_dbserver_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`DBServer_dbserver_id_dbserver`.`id` = `DBServer_dbserver_id_softwareinstance`.`id`))) on((`_databaseschema`.`dbserver_id` = `DBServer_dbserver_id_dbserver`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_databaseschema`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DatacenterDevice`
--

/*!50001 DROP TABLE IF EXISTS `view_DatacenterDevice`*/;
/*!50001 DROP VIEW IF EXISTS `view_DatacenterDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DatacenterDevice` AS select distinct `_datacenterdevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_datacenterdevice`.`managementip_id` AS `managementip_id`,`IPAddress_managementip_id_ipaddress`.`fqdn` AS `managementip_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `managementip_id_friendlyname`,`IPAddress_managementip_id_ipobject`.`finalclass` AS `managementip_id_finalclass_recall` from (((((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) left join (((`ipaddress` `IPAddress_managementip_id_ipaddress` join `ipobject` `IPAddress_managementip_id_ipobject` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_datacenterdevice`.`managementip_id` = `IPAddress_managementip_id_ipaddress`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_datacenterdevice`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_datacenterdevice`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DeliveryModel`
--

/*!50001 DROP TABLE IF EXISTS `view_DeliveryModel`*/;
/*!50001 DROP VIEW IF EXISTS `view_DeliveryModel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DeliveryModel` AS select distinct `_deliverymodel`.`id` AS `id`,`_deliverymodel`.`name` AS `name`,`_deliverymodel`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_deliverymodel`.`description` AS `description`,cast(concat(coalesce(`_deliverymodel`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`deliverymodel` `_deliverymodel` join `organization` `Organization_org_id_organization` on((`_deliverymodel`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Document`
--

/*!50001 DROP TABLE IF EXISTS `view_Document`*/;
/*!50001 DROP VIEW IF EXISTS `view_Document`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Document` AS select distinct `_document`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_document`.`finalclass` AS `finalclass`,if((`_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentFile`
--

/*!50001 DROP TABLE IF EXISTS `view_DocumentFile`*/;
/*!50001 DROP VIEW IF EXISTS `view_DocumentFile`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentFile` AS select distinct `_documentfile`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_documentfile`.`file_mimetype` AS `file`,`_documentfile`.`file_data` AS `file_data`,`_documentfile`.`file_filename` AS `file_filename`,`_document`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from (`documentfile` `_documentfile` join ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) on((`_documentfile`.`id` = `_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentNote`
--

/*!50001 DROP TABLE IF EXISTS `view_DocumentNote`*/;
/*!50001 DROP VIEW IF EXISTS `view_DocumentNote`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentNote` AS select distinct `_documentnote`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_documentnote`.`text` AS `text`,`_document`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from (`documentnote` `_documentnote` join ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) on((`_documentnote`.`id` = `_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentType`
--

/*!50001 DROP TABLE IF EXISTS `view_DocumentType`*/;
/*!50001 DROP VIEW IF EXISTS `view_DocumentType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentType` AS select distinct `_documenttype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`documenttype` `_documenttype` join `typology` `_typology` on((`_documenttype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentWeb`
--

/*!50001 DROP TABLE IF EXISTS `view_DocumentWeb`*/;
/*!50001 DROP VIEW IF EXISTS `view_DocumentWeb`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentWeb` AS select distinct `_documentweb`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_documentweb`.`url` AS `url`,`_document`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from (`documentweb` `_documentweb` join ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) on((`_documentweb`.`id` = `_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Domain`
--

/*!50001 DROP TABLE IF EXISTS `view_Domain`*/;
/*!50001 DROP VIEW IF EXISTS `view_Domain`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Domain` AS select distinct `_domain`.`id` AS `id`,`_dnsobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_dnsobject`.`name` AS `name`,`_dnsobject`.`comment` AS `comment`,`_domain`.`parent_id` AS `parent_id`,`Domain_parent_id_dnsobject`.`name` AS `parent_name`,`_domain`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_domain`.`release_date` AS `release_date`,`_domain`.`registrar_id` AS `registrar_id`,`Organization_registrar_id_organization`.`name` AS `registrar_name`,`_domain`.`validity_start` AS `validity_start`,`_domain`.`validity_end` AS `validity_end`,`_domain`.`renewal` AS `renewal`,`_dnsobject`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_dnsobject`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Domain_parent_id_dnsobject`.`name`,'')) as char charset utf8) AS `parent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Organization_registrar_id_organization`.`name`,'')) as char charset utf8) AS `registrar_id_friendlyname` from ((((`domain` `_domain` left join (`domain` `Domain_parent_id_domain` join `dnsobject` `Domain_parent_id_dnsobject` on((`Domain_parent_id_domain`.`id` = `Domain_parent_id_dnsobject`.`id`))) on((`_domain`.`parent_id` = `Domain_parent_id_domain`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_domain`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join `organization` `Organization_registrar_id_organization` on((`_domain`.`registrar_id` = `Organization_registrar_id_organization`.`id`))) join (`dnsobject` `_dnsobject` join `organization` `Organization_org_id_organization` on((`_dnsobject`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_domain`.`id` = `_dnsobject`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Enclosure`
--

/*!50001 DROP TABLE IF EXISTS `view_Enclosure`*/;
/*!50001 DROP VIEW IF EXISTS `view_Enclosure`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Enclosure` AS select distinct `_enclosure`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_enclosure`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_enclosure`.`nb_u` AS `nb_u`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname` from (((`enclosure` `_enclosure` join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_enclosure`.`rack_id` = `Rack_rack_id_rack`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_enclosure`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_enclosure`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FAQ`
--

/*!50001 DROP TABLE IF EXISTS `view_FAQ`*/;
/*!50001 DROP VIEW IF EXISTS `view_FAQ`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FAQ` AS select distinct `_faq`.`id` AS `id`,`_faq`.`title` AS `title`,`_faq`.`summary` AS `summary`,`_faq`.`description` AS `description`,`_faq`.`category_id` AS `category_id`,`FAQCategory_category_id_faqcategory`.`nam` AS `category_name`,`_faq`.`error_code` AS `error_code`,`_faq`.`key_words` AS `key_words`,cast(concat(coalesce(`_faq`.`title`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`FAQCategory_category_id_faqcategory`.`nam`,'')) as char charset utf8) AS `category_id_friendlyname` from (`faq` `_faq` join `faqcategory` `FAQCategory_category_id_faqcategory` on((`_faq`.`category_id` = `FAQCategory_category_id_faqcategory`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FAQCategory`
--

/*!50001 DROP TABLE IF EXISTS `view_FAQCategory`*/;
/*!50001 DROP VIEW IF EXISTS `view_FAQCategory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FAQCategory` AS select distinct `_faqcategory`.`id` AS `id`,`_faqcategory`.`nam` AS `name`,cast(concat(coalesce(`_faqcategory`.`nam`,'')) as char charset utf8) AS `friendlyname` from `faqcategory` `_faqcategory` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Farm`
--

/*!50001 DROP TABLE IF EXISTS `view_Farm`*/;
/*!50001 DROP VIEW IF EXISTS `view_Farm`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Farm` AS select distinct `_farm`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_farm`.`redundancy` AS `redundancy`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`farm` `_farm` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_farm`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_farm`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FiberChannelInterface`
--

/*!50001 DROP TABLE IF EXISTS `view_FiberChannelInterface`*/;
/*!50001 DROP VIEW IF EXISTS `view_FiberChannelInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FiberChannelInterface` AS select distinct `_fiberchannelinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_fiberchannelinterface`.`speed` AS `speed`,`_fiberchannelinterface`.`topology` AS `topology`,`_fiberchannelinterface`.`wwn` AS `wwn`,`_fiberchannelinterface`.`datacenterdevice_id` AS `datacenterdevice_id`,`DatacenterDevice_datacenterdevice_id_functionalci`.`name` AS `datacenterdevice_name`,`_networkinterface`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `datacenterdevice_id_friendlyname`,`DatacenterDevice_datacenterdevice_id_functionalci`.`finalclass` AS `datacenterdevice_id_finalclass_recall` from ((`fiberchannelinterface` `_fiberchannelinterface` join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id_functionalci` on((`DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id_functionalci`.`id`))) on((`_fiberchannelinterface`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id`))) join `networkinterface` `_networkinterface` on((`_fiberchannelinterface`.`id` = `_networkinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FunctionalCI`
--

/*!50001 DROP TABLE IF EXISTS `view_FunctionalCI`*/;
/*!50001 DROP VIEW IF EXISTS `view_FunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FunctionalCI` AS select distinct `_functionalci`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_functionalci`.`finalclass` AS `finalclass`,if((`_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`softwareinstance` `_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`_functionalci`.`id` = `_fn_SoftwareInstance_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Group`
--

/*!50001 DROP TABLE IF EXISTS `view_Group`*/;
/*!50001 DROP VIEW IF EXISTS `view_Group`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Group` AS select distinct `_group`.`id` AS `id`,`_group`.`name` AS `name`,`_group`.`status` AS `status`,`_group`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `owner_name`,`_group`.`description` AS `description`,`_group`.`type` AS `type`,`_group`.`parent_id` AS `parent_id`,`Group_parent_id_group`.`name` AS `parent_name`,cast(concat(coalesce(`_group`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Group_parent_id_group`.`name`,'')) as char charset utf8) AS `parent_id_friendlyname` from ((`group` `_group` join `organization` `Organization_org_id_organization` on((`_group`.`org_id` = `Organization_org_id_organization`.`id`))) left join `group` `Group_parent_id_group` on((`_group`.`parent_id` = `Group_parent_id_group`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Hypervisor`
--

/*!50001 DROP TABLE IF EXISTS `view_Hypervisor`*/;
/*!50001 DROP VIEW IF EXISTS `view_Hypervisor`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Hypervisor` AS select distinct `_hypervisor`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_hypervisor`.`farm_id` AS `farm_id`,`Farm_farm_id_functionalci`.`name` AS `farm_name`,`_hypervisor`.`server_id` AS `server_id`,`Server_server_id_functionalci`.`name` AS `server_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Farm_farm_id_functionalci`.`name`,'')) as char charset utf8) AS `farm_id_friendlyname`,cast(concat(coalesce(`Server_server_id_functionalci`.`name`,'')) as char charset utf8) AS `server_id_friendlyname` from ((((`hypervisor` `_hypervisor` left join (`farm` `Farm_farm_id_farm` join `functionalci` `Farm_farm_id_functionalci` on((`Farm_farm_id_farm`.`id` = `Farm_farm_id_functionalci`.`id`))) on((`_hypervisor`.`farm_id` = `Farm_farm_id_farm`.`id`))) left join (`server` `Server_server_id_server` join `functionalci` `Server_server_id_functionalci` on((`Server_server_id_server`.`id` = `Server_server_id_functionalci`.`id`))) on((`_hypervisor`.`server_id` = `Server_server_id_server`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_hypervisor`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_hypervisor`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IOSVersion`
--

/*!50001 DROP TABLE IF EXISTS `view_IOSVersion`*/;
/*!50001 DROP VIEW IF EXISTS `view_IOSVersion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IOSVersion` AS select distinct `_iosversion`.`id` AS `id`,`_typology`.`name` AS `name`,`_iosversion`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,''),coalesce(' ',''),coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname` from ((`iosversion` `_iosversion` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_iosversion`.`brand_id` = `Brand_brand_id_brand`.`id`))) join `typology` `_typology` on((`_iosversion`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPAddress`
--

/*!50001 DROP TABLE IF EXISTS `view_IPAddress`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPAddress`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPAddress` AS select distinct `_ipaddress`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_ipaddress`.`short_name` AS `short_name`,`_ipaddress`.`domain_id` AS `domain_id`,`Domain_domain_id_dnsobject`.`name` AS `domain_name`,`_ipaddress`.`fqdn` AS `fqdn`,`_ipaddress`.`aliases` AS `aliases`,`_ipaddress`.`usage_id` AS `usage_id`,`IPUsage_usage_id_typology`.`name` AS `usage_name`,`_ipobject`.`finalclass` AS `finalclass`,if((`_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Domain_domain_id_dnsobject`.`name`,'')) as char charset utf8) AS `domain_id_friendlyname`,cast(concat(coalesce(`IPUsage_usage_id_typology`.`name`,'')) as char charset utf8) AS `usage_id_friendlyname` from (((((`ipaddress` `_ipaddress` left join (`domain` `Domain_domain_id_domain` join `dnsobject` `Domain_domain_id_dnsobject` on((`Domain_domain_id_domain`.`id` = `Domain_domain_id_dnsobject`.`id`))) on((`_ipaddress`.`domain_id` = `Domain_domain_id_domain`.`id`))) left join (`ipusage` `IPUsage_usage_id_ipusage` join `typology` `IPUsage_usage_id_typology` on((`IPUsage_usage_id_ipusage`.`id` = `IPUsage_usage_id_typology`.`id`))) on((`_ipaddress`.`usage_id` = `IPUsage_usage_id_ipusage`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_ipaddress`.`id` = `_ipobject`.`id`))) left join `ipaddressv6` `_fn_IPv6Address_ipaddressv6` on((`_ipaddress`.`id` = `_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `_fn_IPv4Address_ipaddressv4` on((`_ipaddress`.`id` = `_fn_IPv4Address_ipaddressv4`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPBlock`
--

/*!50001 DROP TABLE IF EXISTS `view_IPBlock`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPBlock`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPBlock` AS select distinct `_ipblock`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_ipblock`.`name` AS `name`,`_ipblock`.`type` AS `type`,`_ipblock`.`parent_org_id` AS `parent_org_id`,`Organization_parent_org_id_organization`.`name` AS `parent_org_name`,`_ipblock`.`write_reason` AS `write_reason`,`_ipblock`.`occupancy` AS `occupancy`,`_ipblock`.`children_occupancy` AS `children_occupancy`,`_ipblock`.`subnet_occupancy` AS `subnet_occupancy`,`_ipobject`.`finalclass` AS `finalclass`,if((`_ipobject`.`finalclass` = 'IPBlock'),cast(concat(coalesce('IPBlock','')) as char charset utf8),cast(concat(coalesce(`_ipblock`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Organization_parent_org_id_organization`.`name`,'')) as char charset utf8) AS `parent_org_id_friendlyname` from ((`ipblock` `_ipblock` left join `organization` `Organization_parent_org_id_organization` on((`_ipblock`.`parent_org_id` = `Organization_parent_org_id_organization`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_ipblock`.`id` = `_ipobject`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPConfig`
--

/*!50001 DROP TABLE IF EXISTS `view_IPConfig`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPConfig`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPConfig` AS select distinct `_ipconfig`.`id` AS `id`,`_ipconfig`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipconfig`.`name` AS `name`,`_ipconfig`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipconfig`.`ipv4_block_min_size` AS `ipv4_block_min_size`,`_ipconfig`.`ipv4_block_cidr_aligned` AS `ipv4_block_cidr_aligned`,`_ipconfig`.`delegate_to_children_only` AS `delegate_to_children_only`,`_ipconfig`.`reserve_subnet_IPs` AS `reserve_subnet_IPs`,`_ipconfig`.`ipv4_gateway_ip_format` AS `ipv4_gateway_ip_format`,`_ipconfig`.`subnet_low_watermark` AS `subnet_low_watermark`,`_ipconfig`.`subnet_high_watermark` AS `subnet_high_watermark`,`_ipconfig`.`iprange_low_watermark` AS `iprange_low_watermark`,`_ipconfig`.`iprange_high_watermark` AS `iprange_high_watermark`,`_ipconfig`.`ip_allow_duplicate_name` AS `ip_allow_duplicate_name`,`_ipconfig`.`mac_address_format` AS `mac_address_format`,`_ipconfig`.`ping_before_assign` AS `ping_before_assign`,`_ipconfig`.`ipv6_block_min_prefix` AS `ipv6_block_min_prefix`,`_ipconfig`.`ipv6_block_cidr_aligned` AS `ipv6_block_cidr_aligned`,`_ipconfig`.`ipv6_gateway_ip_format` AS `ipv6_gateway_ip_format`,cast(concat(coalesce(`_ipconfig`.`name`,''),coalesce(' ',''),coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname` from ((`ipconfig` `_ipconfig` join `organization` `Organization_org_id_organization` on((`_ipconfig`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipconfig`.`requestor_id` = `Person_requestor_id_person`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPInterface`
--

/*!50001 DROP TABLE IF EXISTS `view_IPInterface`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPInterface` AS select distinct `_ipinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_ipinterface`.`comment` AS `comment`,`_ipinterface`.`speed` AS `speed`,`_ipinterface`.`macaddress` AS `macaddress`,`_networkinterface`.`finalclass` AS `finalclass`,if((`_networkinterface`.`finalclass` = 'IPInterface'),cast(concat(coalesce(`_networkinterface`.`name`,'')) as char charset utf8),if((`_networkinterface`.`finalclass` = 'LogicalInterface'),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8))) AS `friendlyname` from (((`ipinterface` `_ipinterface` join `networkinterface` `_networkinterface` on((`_ipinterface`.`id` = `_networkinterface`.`id`))) left join (`logicalinterface` `_fn_LogicalInterface_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`_fn_LogicalInterface_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) on((`_ipinterface`.`id` = `_fn_LogicalInterface_logicalinterface`.`id`))) left join (`physicalinterface` `_fn_PhysicalInterface_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_fn_PhysicalInterface_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) on((`_ipinterface`.`id` = `_fn_PhysicalInterface_physicalinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPObject`
--

/*!50001 DROP TABLE IF EXISTS `view_IPObject`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPObject`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPObject` AS select distinct `_ipobject`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_ipobject`.`finalclass` AS `finalclass`,if((`_ipobject`.`finalclass` = 'IPObject'),cast(concat(coalesce('IPObject','')) as char charset utf8),if((`_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),if((`_ipobject`.`finalclass` = 'IPv6Subnet'),cast(concat(coalesce(`_fn_IPv6Subnet_ipsubnetv6`.`ip_text`,'')) as char charset utf8),if((`_ipobject`.`finalclass` = 'IPv4Address'),cast(concat(coalesce(`_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8),if((`_ipobject`.`finalclass` in ('IPv4Range','IPv6Range')),cast(concat(coalesce(`_fn_IPRange_iprange`.`range`,'')) as char charset utf8),if((`_ipobject`.`finalclass` = 'IPv4Subnet'),cast(concat(coalesce(`_fn_IPv4Subnet_ipsubnetv4`.`ip`,'')) as char charset utf8),cast(concat(coalesce(`_fn_IPBlock_ipblock`.`name`,'')) as char charset utf8))))))) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname` from ((((((((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join `ipaddressv6` `_fn_IPv6Address_ipaddressv6` on((`_ipobject`.`id` = `_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipsubnetv6` `_fn_IPv6Subnet_ipsubnetv6` on((`_ipobject`.`id` = `_fn_IPv6Subnet_ipsubnetv6`.`id`))) left join `ipaddressv4` `_fn_IPv4Address_ipaddressv4` on((`_ipobject`.`id` = `_fn_IPv4Address_ipaddressv4`.`id`))) left join `iprange` `_fn_IPRange_iprange` on((`_ipobject`.`id` = `_fn_IPRange_iprange`.`id`))) left join `ipsubnetv4` `_fn_IPv4Subnet_ipsubnetv4` on((`_ipobject`.`id` = `_fn_IPv4Subnet_ipsubnetv4`.`id`))) left join `ipblock` `_fn_IPBlock_ipblock` on((`_ipobject`.`id` = `_fn_IPBlock_ipblock`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPPhone`
--

/*!50001 DROP TABLE IF EXISTS `view_IPPhone`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPPhone`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPPhone` AS select distinct `_ipphone`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_ipphone`.`ipaddress_id` AS `ipaddress_id`,`IPAddress_ipaddress_id_ipaddress`.`fqdn` AS `ipaddress_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `ipaddress_id_friendlyname`,`IPAddress_ipaddress_id_ipobject`.`finalclass` AS `ipaddress_id_finalclass_recall` from ((((`ipphone` `_ipphone` left join (((`ipaddress` `IPAddress_ipaddress_id_ipaddress` join `ipobject` `IPAddress_ipaddress_id_ipobject` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_ipphone`.`ipaddress_id` = `IPAddress_ipaddress_id_ipaddress`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_ipphone`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_ipphone`.`id` = `_physicaldevice`.`id`))) join `telephonyci` `_telephonyci` on((`_ipphone`.`id` = `_telephonyci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPRange`
--

/*!50001 DROP TABLE IF EXISTS `view_IPRange`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPRange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPRange` AS select distinct `_iprange`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_iprange`.`range` AS `range`,`_iprange`.`usage_id` AS `usage_id`,`IPRangeUsage_usage_id_typology`.`name` AS `usage_name`,`_iprange`.`dhcp` AS `dhcp`,`_iprange`.`write_reason` AS `write_reason`,`_iprange`.`occupancy` AS `occupancy`,`_iprange`.`alarm_water_mark` AS `alarm_water_mark`,`_ipobject`.`finalclass` AS `finalclass`,if((`_ipobject`.`finalclass` = 'IPRange'),cast(concat(coalesce('IPRange','')) as char charset utf8),cast(concat(coalesce(`_iprange`.`range`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`IPRangeUsage_usage_id_typology`.`name`,'')) as char charset utf8) AS `usage_id_friendlyname` from ((`iprange` `_iprange` left join (`iprangeusage` `IPRangeUsage_usage_id_iprangeusage` join `typology` `IPRangeUsage_usage_id_typology` on((`IPRangeUsage_usage_id_iprangeusage`.`id` = `IPRangeUsage_usage_id_typology`.`id`))) on((`_iprange`.`usage_id` = `IPRangeUsage_usage_id_iprangeusage`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_iprange`.`id` = `_ipobject`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPRangeUsage`
--

/*!50001 DROP TABLE IF EXISTS `view_IPRangeUsage`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPRangeUsage`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPRangeUsage` AS select distinct `_iprangeusage`.`id` AS `id`,`_typology`.`name` AS `name`,`_iprangeusage`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_iprangeusage`.`description` AS `description`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`iprangeusage` `_iprangeusage` join `organization` `Organization_org_id_organization` on((`_iprangeusage`.`org_id` = `Organization_org_id_organization`.`id`))) join `typology` `_typology` on((`_iprangeusage`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPSubnet`
--

/*!50001 DROP TABLE IF EXISTS `view_IPSubnet`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPSubnet`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPSubnet` AS select distinct `_ipsubnet`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_ipsubnet`.`name` AS `name`,`_ipsubnet`.`type` AS `type`,`_ipsubnet`.`write_reason` AS `write_reason`,`_ipsubnet`.`ip_occupancy` AS `ip_occupancy`,`_ipsubnet`.`range_occupancy` AS `range_occupancy`,`_ipsubnet`.`alarm_water_mark` AS `alarm_water_mark`,`_ipobject`.`finalclass` AS `finalclass`,if((`_ipobject`.`finalclass` = 'IPSubnet'),cast(concat(coalesce('IPSubnet','')) as char charset utf8),if((`_ipobject`.`finalclass` = 'IPv6Subnet'),cast(concat(coalesce(`_fn_IPv6Subnet_ipsubnetv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`_fn_IPv4Subnet_ipsubnetv4`.`ip`,'')) as char charset utf8))) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname` from (((`ipsubnet` `_ipsubnet` join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_ipsubnet`.`id` = `_ipobject`.`id`))) left join `ipsubnetv6` `_fn_IPv6Subnet_ipsubnetv6` on((`_ipsubnet`.`id` = `_fn_IPv6Subnet_ipsubnetv6`.`id`))) left join `ipsubnetv4` `_fn_IPv4Subnet_ipsubnetv4` on((`_ipsubnet`.`id` = `_fn_IPv4Subnet_ipsubnetv4`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPTriggerOnWaterMark`
--

/*!50001 DROP TABLE IF EXISTS `view_IPTriggerOnWaterMark`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPTriggerOnWaterMark`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPTriggerOnWaterMark` AS select distinct `_priv_trigger_onwatermark`.`id` AS `id`,`_priv_trigger`.`description` AS `description`,`_priv_trigger_onwatermark`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_priv_trigger_onwatermark`.`target_class` AS `target_class`,`_priv_trigger_onwatermark`.`event` AS `event`,`_priv_trigger`.`realclass` AS `finalclass`,cast(concat(coalesce(`_priv_trigger`.`description`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`priv_trigger_onwatermark` `_priv_trigger_onwatermark` join `organization` `Organization_org_id_organization` on((`_priv_trigger_onwatermark`.`org_id` = `Organization_org_id_organization`.`id`))) join `priv_trigger` `_priv_trigger` on((`_priv_trigger_onwatermark`.`id` = `_priv_trigger`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPUsage`
--

/*!50001 DROP TABLE IF EXISTS `view_IPUsage`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPUsage`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPUsage` AS select distinct `_ipusage`.`id` AS `id`,`_typology`.`name` AS `name`,`_ipusage`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipusage`.`description` AS `description`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`ipusage` `_ipusage` join `organization` `Organization_org_id_organization` on((`_ipusage`.`org_id` = `Organization_org_id_organization`.`id`))) join `typology` `_typology` on((`_ipusage`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPv4Address`
--

/*!50001 DROP TABLE IF EXISTS `view_IPv4Address`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPv4Address`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPv4Address` AS select distinct `_ipaddressv4`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_ipaddress`.`short_name` AS `short_name`,`_ipaddress`.`domain_id` AS `domain_id`,`Domain_domain_id_dnsobject`.`name` AS `domain_name`,`_ipaddress`.`fqdn` AS `fqdn`,`_ipaddress`.`aliases` AS `aliases`,`_ipaddress`.`usage_id` AS `usage_id`,`IPUsage_usage_id_typology`.`name` AS `usage_name`,`_ipaddressv4`.`subnet_id` AS `subnet_id`,`IPv4Subnet_subnet_id_ipsubnetv4`.`ip` AS `subnet_ip`,`_ipaddressv4`.`range_id` AS `range_id`,`IPv4Range_range_id_iprange`.`range` AS `range_name`,`_ipaddressv4`.`ip` AS `ip`,`_ipobject`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ipaddressv4`.`ip`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Domain_domain_id_dnsobject`.`name`,'')) as char charset utf8) AS `domain_id_friendlyname`,cast(concat(coalesce(`IPUsage_usage_id_typology`.`name`,'')) as char charset utf8) AS `usage_id_friendlyname`,cast(concat(coalesce(`IPv4Subnet_subnet_id_ipsubnetv4`.`ip`,'')) as char charset utf8) AS `subnet_id_friendlyname`,cast(concat(coalesce(`IPv4Range_range_id_iprange`.`range`,'')) as char charset utf8) AS `range_id_friendlyname` from ((((`ipaddressv4` `_ipaddressv4` left join `ipsubnetv4` `IPv4Subnet_subnet_id_ipsubnetv4` on((`_ipaddressv4`.`subnet_id` = `IPv4Subnet_subnet_id_ipsubnetv4`.`id`))) left join (`iprangev4` `IPv4Range_range_id_iprangev4` join `iprange` `IPv4Range_range_id_iprange` on((`IPv4Range_range_id_iprangev4`.`id` = `IPv4Range_range_id_iprange`.`id`))) on((`_ipaddressv4`.`range_id` = `IPv4Range_range_id_iprangev4`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_ipaddressv4`.`id` = `_ipobject`.`id`))) join ((`ipaddress` `_ipaddress` left join (`domain` `Domain_domain_id_domain` join `dnsobject` `Domain_domain_id_dnsobject` on((`Domain_domain_id_domain`.`id` = `Domain_domain_id_dnsobject`.`id`))) on((`_ipaddress`.`domain_id` = `Domain_domain_id_domain`.`id`))) left join (`ipusage` `IPUsage_usage_id_ipusage` join `typology` `IPUsage_usage_id_typology` on((`IPUsage_usage_id_ipusage`.`id` = `IPUsage_usage_id_typology`.`id`))) on((`_ipaddress`.`usage_id` = `IPUsage_usage_id_ipusage`.`id`))) on((`_ipaddressv4`.`id` = `_ipaddress`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPv4Block`
--

/*!50001 DROP TABLE IF EXISTS `view_IPv4Block`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPv4Block`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPv4Block` AS select distinct `_ipblockv4`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_ipblock`.`name` AS `name`,`_ipblock`.`type` AS `type`,`_ipblock`.`parent_org_id` AS `parent_org_id`,`Organization_parent_org_id_organization`.`name` AS `parent_org_name`,`_ipblock`.`write_reason` AS `write_reason`,`_ipblock`.`occupancy` AS `occupancy`,`_ipblock`.`children_occupancy` AS `children_occupancy`,`_ipblock`.`subnet_occupancy` AS `subnet_occupancy`,`_ipblockv4`.`parent_id` AS `parent_id`,`IPv4Block_parent_id_ipblock`.`name` AS `parent_name`,`_ipblockv4`.`firstip` AS `firstip`,`_ipblockv4`.`lastip` AS `lastip`,`_ipobject`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ipblock`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Organization_parent_org_id_organization`.`name`,'')) as char charset utf8) AS `parent_org_id_friendlyname`,cast(concat(coalesce(`IPv4Block_parent_id_ipblock`.`name`,'')) as char charset utf8) AS `parent_id_friendlyname` from (((`ipblockv4` `_ipblockv4` left join (`ipblockv4` `IPv4Block_parent_id_ipblockv4` join `ipblock` `IPv4Block_parent_id_ipblock` on((`IPv4Block_parent_id_ipblockv4`.`id` = `IPv4Block_parent_id_ipblock`.`id`))) on((`_ipblockv4`.`parent_id` = `IPv4Block_parent_id_ipblockv4`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_ipblockv4`.`id` = `_ipobject`.`id`))) join (`ipblock` `_ipblock` left join `organization` `Organization_parent_org_id_organization` on((`_ipblock`.`parent_org_id` = `Organization_parent_org_id_organization`.`id`))) on((`_ipblockv4`.`id` = `_ipblock`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPv4Range`
--

/*!50001 DROP TABLE IF EXISTS `view_IPv4Range`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPv4Range`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPv4Range` AS select distinct `_iprangev4`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_iprange`.`range` AS `range`,`_iprange`.`usage_id` AS `usage_id`,`IPRangeUsage_usage_id_typology`.`name` AS `usage_name`,`_iprange`.`dhcp` AS `dhcp`,`_iprange`.`write_reason` AS `write_reason`,`_iprange`.`occupancy` AS `occupancy`,`_iprange`.`alarm_water_mark` AS `alarm_water_mark`,`_iprangev4`.`subnet_id` AS `subnet_id`,`IPv4Subnet_subnet_id_ipsubnetv4`.`ip` AS `subnet_ip`,`_iprangev4`.`firstip` AS `firstip`,`_iprangev4`.`lastip` AS `lastip`,`_ipobject`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_iprange`.`range`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`IPRangeUsage_usage_id_typology`.`name`,'')) as char charset utf8) AS `usage_id_friendlyname`,cast(concat(coalesce(`IPv4Subnet_subnet_id_ipsubnetv4`.`ip`,'')) as char charset utf8) AS `subnet_id_friendlyname` from (((`iprangev4` `_iprangev4` join `ipsubnetv4` `IPv4Subnet_subnet_id_ipsubnetv4` on((`_iprangev4`.`subnet_id` = `IPv4Subnet_subnet_id_ipsubnetv4`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_iprangev4`.`id` = `_ipobject`.`id`))) join (`iprange` `_iprange` left join (`iprangeusage` `IPRangeUsage_usage_id_iprangeusage` join `typology` `IPRangeUsage_usage_id_typology` on((`IPRangeUsage_usage_id_iprangeusage`.`id` = `IPRangeUsage_usage_id_typology`.`id`))) on((`_iprange`.`usage_id` = `IPRangeUsage_usage_id_iprangeusage`.`id`))) on((`_iprangev4`.`id` = `_iprange`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPv4Subnet`
--

/*!50001 DROP TABLE IF EXISTS `view_IPv4Subnet`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPv4Subnet`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPv4Subnet` AS select distinct `_ipsubnetv4`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_ipsubnet`.`name` AS `name`,`_ipsubnet`.`type` AS `type`,`_ipsubnet`.`write_reason` AS `write_reason`,`_ipsubnet`.`ip_occupancy` AS `ip_occupancy`,`_ipsubnet`.`range_occupancy` AS `range_occupancy`,`_ipsubnet`.`alarm_water_mark` AS `alarm_water_mark`,`_ipsubnetv4`.`block_id` AS `block_id`,`IPv4Block_block_id_ipblock`.`name` AS `block_name`,`_ipsubnetv4`.`ip` AS `ip`,`_ipsubnetv4`.`mask` AS `mask`,`_ipsubnetv4`.`gatewayip` AS `gatewayip`,`_ipsubnetv4`.`broadcastip` AS `broadcastip`,`_ipobject`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ipsubnetv4`.`ip`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`IPv4Block_block_id_ipblock`.`name`,'')) as char charset utf8) AS `block_id_friendlyname` from (((`ipsubnetv4` `_ipsubnetv4` join (`ipblockv4` `IPv4Block_block_id_ipblockv4` join `ipblock` `IPv4Block_block_id_ipblock` on((`IPv4Block_block_id_ipblockv4`.`id` = `IPv4Block_block_id_ipblock`.`id`))) on((`_ipsubnetv4`.`block_id` = `IPv4Block_block_id_ipblockv4`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_ipsubnetv4`.`id` = `_ipobject`.`id`))) join `ipsubnet` `_ipsubnet` on((`_ipsubnetv4`.`id` = `_ipsubnet`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPv6Address`
--

/*!50001 DROP TABLE IF EXISTS `view_IPv6Address`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPv6Address`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPv6Address` AS select distinct `_ipaddressv6`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_ipaddress`.`short_name` AS `short_name`,`_ipaddress`.`domain_id` AS `domain_id`,`Domain_domain_id_dnsobject`.`name` AS `domain_name`,`_ipaddress`.`fqdn` AS `fqdn`,`_ipaddress`.`aliases` AS `aliases`,`_ipaddress`.`usage_id` AS `usage_id`,`IPUsage_usage_id_typology`.`name` AS `usage_name`,`_ipaddressv6`.`subnet_id` AS `subnet_id`,`IPv6Subnet_subnet_id_ipsubnetv6`.`ip_text` AS `subnet_ip`,`_ipaddressv6`.`range_id` AS `range_id`,`IPv6Range_range_id_iprange`.`range` AS `range_name`,`_ipaddressv6`.`ip_text` AS `ip`,`_ipaddressv6`.`ip_text` AS `ip_text`,`_ipaddressv6`.`ip_high` AS `ip_high`,`_ipaddressv6`.`ip_low` AS `ip_low`,`_ipobject`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ipaddressv6`.`ip_text`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Domain_domain_id_dnsobject`.`name`,'')) as char charset utf8) AS `domain_id_friendlyname`,cast(concat(coalesce(`IPUsage_usage_id_typology`.`name`,'')) as char charset utf8) AS `usage_id_friendlyname`,cast(concat(coalesce(`IPv6Subnet_subnet_id_ipsubnetv6`.`ip_text`,'')) as char charset utf8) AS `subnet_id_friendlyname`,cast(concat(coalesce(`IPv6Range_range_id_iprange`.`range`,'')) as char charset utf8) AS `range_id_friendlyname` from ((((`ipaddressv6` `_ipaddressv6` left join `ipsubnetv6` `IPv6Subnet_subnet_id_ipsubnetv6` on((`_ipaddressv6`.`subnet_id` = `IPv6Subnet_subnet_id_ipsubnetv6`.`id`))) left join (`iprangev6` `IPv6Range_range_id_iprangev6` join `iprange` `IPv6Range_range_id_iprange` on((`IPv6Range_range_id_iprangev6`.`id` = `IPv6Range_range_id_iprange`.`id`))) on((`_ipaddressv6`.`range_id` = `IPv6Range_range_id_iprangev6`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_ipaddressv6`.`id` = `_ipobject`.`id`))) join ((`ipaddress` `_ipaddress` left join (`domain` `Domain_domain_id_domain` join `dnsobject` `Domain_domain_id_dnsobject` on((`Domain_domain_id_domain`.`id` = `Domain_domain_id_dnsobject`.`id`))) on((`_ipaddress`.`domain_id` = `Domain_domain_id_domain`.`id`))) left join (`ipusage` `IPUsage_usage_id_ipusage` join `typology` `IPUsage_usage_id_typology` on((`IPUsage_usage_id_ipusage`.`id` = `IPUsage_usage_id_typology`.`id`))) on((`_ipaddress`.`usage_id` = `IPUsage_usage_id_ipusage`.`id`))) on((`_ipaddressv6`.`id` = `_ipaddress`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPv6Block`
--

/*!50001 DROP TABLE IF EXISTS `view_IPv6Block`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPv6Block`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPv6Block` AS select distinct `_ipblockv6`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_ipblock`.`name` AS `name`,`_ipblock`.`type` AS `type`,`_ipblock`.`parent_org_id` AS `parent_org_id`,`Organization_parent_org_id_organization`.`name` AS `parent_org_name`,`_ipblock`.`write_reason` AS `write_reason`,`_ipblock`.`occupancy` AS `occupancy`,`_ipblock`.`children_occupancy` AS `children_occupancy`,`_ipblock`.`subnet_occupancy` AS `subnet_occupancy`,`_ipblockv6`.`parent_id` AS `parent_id`,`IPv6Block_parent_id_ipblock`.`name` AS `parent_name`,`_ipblockv6`.`firstip_text` AS `firstip`,`_ipblockv6`.`firstip_text` AS `firstip_text`,`_ipblockv6`.`firstip_high` AS `firstip_high`,`_ipblockv6`.`firstip_low` AS `firstip_low`,`_ipblockv6`.`lastip_text` AS `lastip`,`_ipblockv6`.`lastip_text` AS `lastip_text`,`_ipblockv6`.`lastip_high` AS `lastip_high`,`_ipblockv6`.`lastip_low` AS `lastip_low`,`_ipobject`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ipblock`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Organization_parent_org_id_organization`.`name`,'')) as char charset utf8) AS `parent_org_id_friendlyname`,cast(concat(coalesce(`IPv6Block_parent_id_ipblock`.`name`,'')) as char charset utf8) AS `parent_id_friendlyname` from (((`ipblockv6` `_ipblockv6` left join (`ipblockv6` `IPv6Block_parent_id_ipblockv6` join `ipblock` `IPv6Block_parent_id_ipblock` on((`IPv6Block_parent_id_ipblockv6`.`id` = `IPv6Block_parent_id_ipblock`.`id`))) on((`_ipblockv6`.`parent_id` = `IPv6Block_parent_id_ipblockv6`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_ipblockv6`.`id` = `_ipobject`.`id`))) join (`ipblock` `_ipblock` left join `organization` `Organization_parent_org_id_organization` on((`_ipblock`.`parent_org_id` = `Organization_parent_org_id_organization`.`id`))) on((`_ipblockv6`.`id` = `_ipblock`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPv6Range`
--

/*!50001 DROP TABLE IF EXISTS `view_IPv6Range`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPv6Range`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPv6Range` AS select distinct `_iprangev6`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_iprange`.`range` AS `range`,`_iprange`.`usage_id` AS `usage_id`,`IPRangeUsage_usage_id_typology`.`name` AS `usage_name`,`_iprange`.`dhcp` AS `dhcp`,`_iprange`.`write_reason` AS `write_reason`,`_iprange`.`occupancy` AS `occupancy`,`_iprange`.`alarm_water_mark` AS `alarm_water_mark`,`_iprangev6`.`subnet_id` AS `subnet_id`,`IPv6Subnet_subnet_id_ipsubnetv6`.`ip_text` AS `subnet_ip`,`_iprangev6`.`firstip_text` AS `firstip`,`_iprangev6`.`firstip_text` AS `firstip_text`,`_iprangev6`.`firstip_high` AS `firstip_high`,`_iprangev6`.`firstip_low` AS `firstip_low`,`_iprangev6`.`lastip_text` AS `lastip`,`_iprangev6`.`lastip_text` AS `lastip_text`,`_iprangev6`.`lastip_high` AS `lastip_high`,`_iprangev6`.`lastip_low` AS `lastip_low`,`_ipobject`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_iprange`.`range`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`IPRangeUsage_usage_id_typology`.`name`,'')) as char charset utf8) AS `usage_id_friendlyname`,cast(concat(coalesce(`IPv6Subnet_subnet_id_ipsubnetv6`.`ip_text`,'')) as char charset utf8) AS `subnet_id_friendlyname` from (((`iprangev6` `_iprangev6` join `ipsubnetv6` `IPv6Subnet_subnet_id_ipsubnetv6` on((`_iprangev6`.`subnet_id` = `IPv6Subnet_subnet_id_ipsubnetv6`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_iprangev6`.`id` = `_ipobject`.`id`))) join (`iprange` `_iprange` left join (`iprangeusage` `IPRangeUsage_usage_id_iprangeusage` join `typology` `IPRangeUsage_usage_id_typology` on((`IPRangeUsage_usage_id_iprangeusage`.`id` = `IPRangeUsage_usage_id_typology`.`id`))) on((`_iprange`.`usage_id` = `IPRangeUsage_usage_id_iprangeusage`.`id`))) on((`_iprangev6`.`id` = `_iprange`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPv6Subnet`
--

/*!50001 DROP TABLE IF EXISTS `view_IPv6Subnet`*/;
/*!50001 DROP VIEW IF EXISTS `view_IPv6Subnet`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPv6Subnet` AS select distinct `_ipsubnetv6`.`id` AS `id`,`_ipobject`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ipobject`.`status` AS `status`,`_ipobject`.`comment` AS `comment`,`_ipobject`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`name` AS `requestor_name`,`_ipobject`.`allocation_date` AS `allocation_date`,`_ipobject`.`release_date` AS `release_date`,`_ipsubnet`.`name` AS `name`,`_ipsubnet`.`type` AS `type`,`_ipsubnet`.`write_reason` AS `write_reason`,`_ipsubnet`.`ip_occupancy` AS `ip_occupancy`,`_ipsubnet`.`range_occupancy` AS `range_occupancy`,`_ipsubnet`.`alarm_water_mark` AS `alarm_water_mark`,`_ipsubnetv6`.`block_id` AS `block_id`,`IPv6Block_block_id_ipblock`.`name` AS `block_name`,`_ipsubnetv6`.`ip_text` AS `ip`,`_ipsubnetv6`.`ip_text` AS `ip_text`,`_ipsubnetv6`.`ip_high` AS `ip_high`,`_ipsubnetv6`.`ip_low` AS `ip_low`,`_ipsubnetv6`.`mask` AS `mask`,`_ipsubnetv6`.`gatewayip_text` AS `gatewayip`,`_ipsubnetv6`.`gatewayip_text` AS `gatewayip_text`,`_ipsubnetv6`.`gatewayip_high` AS `gatewayip_high`,`_ipsubnetv6`.`gatewayip_low` AS `gatewayip_low`,`_ipsubnetv6`.`lastip_text` AS `lastip`,`_ipsubnetv6`.`lastip_text` AS `lastip_text`,`_ipsubnetv6`.`lastip_high` AS `lastip_high`,`_ipsubnetv6`.`lastip_low` AS `lastip_low`,`_ipobject`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ipsubnetv6`.`ip_text`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`IPv6Block_block_id_ipblock`.`name`,'')) as char charset utf8) AS `block_id_friendlyname` from (((`ipsubnetv6` `_ipsubnetv6` join (`ipblockv6` `IPv6Block_block_id_ipblockv6` join `ipblock` `IPv6Block_block_id_ipblock` on((`IPv6Block_block_id_ipblockv6`.`id` = `IPv6Block_block_id_ipblock`.`id`))) on((`_ipsubnetv6`.`block_id` = `IPv6Block_block_id_ipblockv6`.`id`))) join ((`ipobject` `_ipobject` join `organization` `Organization_org_id_organization` on((`_ipobject`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_ipobject`.`requestor_id` = `Person_requestor_id_person`.`id`))) on((`_ipsubnetv6`.`id` = `_ipobject`.`id`))) join `ipsubnet` `_ipsubnet` on((`_ipsubnetv6`.`id` = `_ipsubnet`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_KnownError`
--

/*!50001 DROP TABLE IF EXISTS `view_KnownError`*/;
/*!50001 DROP VIEW IF EXISTS `view_KnownError`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_KnownError` AS select distinct `_knownerror`.`id` AS `id`,`_knownerror`.`name` AS `name`,`_knownerror`.`cust_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `cust_name`,`_knownerror`.`problem_id` AS `problem_id`,`Problem_problem_id_ticket`.`ref` AS `problem_ref`,`_knownerror`.`symptom` AS `symptom`,`_knownerror`.`rootcause` AS `root_cause`,`_knownerror`.`workaround` AS `workaround`,`_knownerror`.`solution` AS `solution`,`_knownerror`.`error_code` AS `error_code`,`_knownerror`.`domain` AS `domain`,`_knownerror`.`vendor` AS `vendor`,`_knownerror`.`model` AS `model`,`_knownerror`.`version` AS `version`,cast(concat(coalesce(`_knownerror`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Problem_problem_id_ticket`.`ref`,'')) as char charset utf8) AS `problem_id_friendlyname` from ((`knownerror` `_knownerror` join `organization` `Organization_org_id_organization` on((`_knownerror`.`cust_id` = `Organization_org_id_organization`.`id`))) left join (`ticket_problem` `Problem_problem_id_ticket_problem` join `ticket` `Problem_problem_id_ticket` on((`Problem_problem_id_ticket_problem`.`id` = `Problem_problem_id_ticket`.`id`))) on((`_knownerror`.`problem_id` = `Problem_problem_id_ticket_problem`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Licence`
--

/*!50001 DROP TABLE IF EXISTS `view_Licence`*/;
/*!50001 DROP VIEW IF EXISTS `view_Licence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Licence` AS select distinct `_licence`.`id` AS `id`,`_licence`.`name` AS `name`,`_licence`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_licence`.`usage_limit` AS `usage_limit`,`_licence`.`description` AS `description`,`_licence`.`start_date` AS `start_date`,`_licence`.`end_date` AS `end_date`,`_licence`.`licence_key` AS `licence_key`,`_licence`.`perpetual` AS `perpetual`,`_licence`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_licence`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`licence` `_licence` join `organization` `Organization_org_id_organization` on((`_licence`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Location`
--

/*!50001 DROP TABLE IF EXISTS `view_Location`*/;
/*!50001 DROP VIEW IF EXISTS `view_Location`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Location` AS select distinct `_location`.`id` AS `id`,`_location`.`name` AS `name`,`_location`.`status` AS `status`,`_location`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_location`.`address` AS `address`,`_location`.`postal_code` AS `postal_code`,`_location`.`city` AS `city`,`_location`.`country` AS `country`,cast(concat(coalesce(`_location`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`location` `_location` join `organization` `Organization_org_id_organization` on((`_location`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_LogicalInterface`
--

/*!50001 DROP TABLE IF EXISTS `view_LogicalInterface`*/;
/*!50001 DROP VIEW IF EXISTS `view_LogicalInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_LogicalInterface` AS select distinct `_logicalinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_ipinterface`.`comment` AS `comment`,`_ipinterface`.`speed` AS `speed`,`_ipinterface`.`macaddress` AS `macaddress`,`_logicalinterface`.`virtualmachine_id` AS `virtualmachine_id`,`VirtualMachine_virtualmachine_id_functionalci`.`name` AS `virtualmachine_name`,`_networkinterface`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8) AS `virtualmachine_id_friendlyname` from (((`logicalinterface` `_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) join `networkinterface` `_networkinterface` on((`_logicalinterface`.`id` = `_networkinterface`.`id`))) join `ipinterface` `_ipinterface` on((`_logicalinterface`.`id` = `_ipinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_LogicalVolume`
--

/*!50001 DROP TABLE IF EXISTS `view_LogicalVolume`*/;
/*!50001 DROP VIEW IF EXISTS `view_LogicalVolume`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_LogicalVolume` AS select distinct `_logicalvolume`.`id` AS `id`,`_logicalvolume`.`name` AS `name`,`_logicalvolume`.`lun_id` AS `lun_id`,`_logicalvolume`.`description` AS `description`,`_logicalvolume`.`raid_level` AS `raid_level`,`_logicalvolume`.`size` AS `size`,`_logicalvolume`.`storagesystem_id` AS `storagesystem_id`,`StorageSystem_storagesystem_id_functionalci`.`name` AS `storagesystem_name`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`_logicalvolume`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,'')) as char charset utf8) AS `storagesystem_id_friendlyname` from (`logicalvolume` `_logicalvolume` join (`storagesystem` `StorageSystem_storagesystem_id_storagesystem` join `functionalci` `StorageSystem_storagesystem_id_functionalci` on((`StorageSystem_storagesystem_id_storagesystem`.`id` = `StorageSystem_storagesystem_id_functionalci`.`id`))) on((`_logicalvolume`.`storagesystem_id` = `StorageSystem_storagesystem_id_storagesystem`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Middleware`
--

/*!50001 DROP TABLE IF EXISTS `view_Middleware`*/;
/*!50001 DROP VIEW IF EXISTS `view_Middleware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Middleware` AS select distinct `_middleware`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`middleware` `_middleware` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_middleware`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_middleware`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_MiddlewareInstance`
--

/*!50001 DROP TABLE IF EXISTS `view_MiddlewareInstance`*/;
/*!50001 DROP VIEW IF EXISTS `view_MiddlewareInstance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_MiddlewareInstance` AS select distinct `_middlewareinstance`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_middlewareinstance`.`middleware_id` AS `middleware_id`,`Middleware_middleware_id_functionalci`.`name` AS `middleware_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Middleware_middleware_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `middleware_id_friendlyname` from ((`middlewareinstance` `_middlewareinstance` join ((`middleware` `Middleware_middleware_id_middleware` join `functionalci` `Middleware_middleware_id_functionalci` on((`Middleware_middleware_id_middleware`.`id` = `Middleware_middleware_id_functionalci`.`id`))) join (`softwareinstance` `Middleware_middleware_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`Middleware_middleware_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`Middleware_middleware_id_middleware`.`id` = `Middleware_middleware_id_softwareinstance`.`id`))) on((`_middlewareinstance`.`middleware_id` = `Middleware_middleware_id_middleware`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_middlewareinstance`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_MobilePhone`
--

/*!50001 DROP TABLE IF EXISTS `view_MobilePhone`*/;
/*!50001 DROP VIEW IF EXISTS `view_MobilePhone`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_MobilePhone` AS select distinct `_mobilephone`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_mobilephone`.`imei` AS `imei`,`_mobilephone`.`hw_pin` AS `hw_pin`,`_mobilephone`.`ipaddress_id` AS `ipaddress_id`,`IPAddress_ipaddress_id_ipaddress`.`fqdn` AS `ipaddress_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `ipaddress_id_friendlyname`,`IPAddress_ipaddress_id_ipobject`.`finalclass` AS `ipaddress_id_finalclass_recall` from ((((`mobilephone` `_mobilephone` left join (((`ipaddress` `IPAddress_ipaddress_id_ipaddress` join `ipobject` `IPAddress_ipaddress_id_ipobject` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_mobilephone`.`ipaddress_id` = `IPAddress_ipaddress_id_ipaddress`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_mobilephone`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_mobilephone`.`id` = `_physicaldevice`.`id`))) join `telephonyci` `_telephonyci` on((`_mobilephone`.`id` = `_telephonyci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Model`
--

/*!50001 DROP TABLE IF EXISTS `view_Model`*/;
/*!50001 DROP VIEW IF EXISTS `view_Model`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Model` AS select distinct `_model`.`id` AS `id`,`_typology`.`name` AS `name`,`_model`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_model`.`type` AS `type`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname` from ((`model` `_model` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_model`.`brand_id` = `Brand_brand_id_brand`.`id`))) join `typology` `_typology` on((`_model`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NAS`
--

/*!50001 DROP TABLE IF EXISTS `view_NAS`*/;
/*!50001 DROP VIEW IF EXISTS `view_NAS`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NAS` AS select distinct `_nas`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_datacenterdevice`.`managementip_id` AS `managementip_id`,`IPAddress_managementip_id_ipaddress`.`fqdn` AS `managementip_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `managementip_id_friendlyname`,`IPAddress_managementip_id_ipobject`.`finalclass` AS `managementip_id_finalclass_recall` from (((`nas` `_nas` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_nas`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_nas`.`id` = `_physicaldevice`.`id`))) join (((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) left join (((`ipaddress` `IPAddress_managementip_id_ipaddress` join `ipobject` `IPAddress_managementip_id_ipobject` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_datacenterdevice`.`managementip_id` = `IPAddress_managementip_id_ipaddress`.`id`))) on((`_nas`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NASFileSystem`
--

/*!50001 DROP TABLE IF EXISTS `view_NASFileSystem`*/;
/*!50001 DROP VIEW IF EXISTS `view_NASFileSystem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NASFileSystem` AS select distinct `_nasfilesystem`.`id` AS `id`,`_nasfilesystem`.`name` AS `name`,`_nasfilesystem`.`description` AS `description`,`_nasfilesystem`.`raid_level` AS `raid_level`,`_nasfilesystem`.`size` AS `size`,`_nasfilesystem`.`nas_id` AS `nas_id`,`NAS_nas_id_functionalci`.`name` AS `nas_name`,cast(concat(coalesce(`_nasfilesystem`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`NAS_nas_id_functionalci`.`name`,'')) as char charset utf8) AS `nas_id_friendlyname` from (`nasfilesystem` `_nasfilesystem` join (`nas` `NAS_nas_id_nas` join `functionalci` `NAS_nas_id_functionalci` on((`NAS_nas_id_nas`.`id` = `NAS_nas_id_functionalci`.`id`))) on((`_nasfilesystem`.`nas_id` = `NAS_nas_id_nas`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NetworkDevice`
--

/*!50001 DROP TABLE IF EXISTS `view_NetworkDevice`*/;
/*!50001 DROP VIEW IF EXISTS `view_NetworkDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NetworkDevice` AS select distinct `_networkdevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id1_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_datacenterdevice`.`managementip_id` AS `managementip_id`,`IPAddress_managementip_id_ipaddress`.`fqdn` AS `managementip_name`,`_networkdevice`.`networkdevicetype_id` AS `networkdevicetype_id`,`NetworkDeviceType_networkdevicetype_id_typology`.`name` AS `networkdevicetype_name`,`_networkdevice`.`iosversion_id` AS `iosversion_id`,`IOSVersion_iosversion_id_typology`.`name` AS `iosversion_name`,`_networkdevice`.`ram` AS `ram`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id1_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `managementip_id_friendlyname`,`IPAddress_managementip_id_ipobject`.`finalclass` AS `managementip_id_finalclass_recall`,cast(concat(coalesce(`NetworkDeviceType_networkdevicetype_id_typology`.`name`,'')) as char charset utf8) AS `networkdevicetype_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,''),coalesce(' ',''),coalesce(`IOSVersion_iosversion_id_typology`.`name`,'')) as char charset utf8) AS `iosversion_id_friendlyname` from (((((`networkdevice` `_networkdevice` join (`networkdevicetype` `NetworkDeviceType_networkdevicetype_id_networkdevicetype` join `typology` `NetworkDeviceType_networkdevicetype_id_typology` on((`NetworkDeviceType_networkdevicetype_id_networkdevicetype`.`id` = `NetworkDeviceType_networkdevicetype_id_typology`.`id`))) on((`_networkdevice`.`networkdevicetype_id` = `NetworkDeviceType_networkdevicetype_id_networkdevicetype`.`id`))) left join ((`iosversion` `IOSVersion_iosversion_id_iosversion` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`IOSVersion_iosversion_id_iosversion`.`brand_id` = `Brand_brand_id_brand`.`id`))) join `typology` `IOSVersion_iosversion_id_typology` on((`IOSVersion_iosversion_id_iosversion`.`id` = `IOSVersion_iosversion_id_typology`.`id`))) on((`_networkdevice`.`iosversion_id` = `IOSVersion_iosversion_id_iosversion`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_networkdevice`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id1_brand` join `typology` `Brand_brand_id1_typology` on((`Brand_brand_id1_brand`.`id` = `Brand_brand_id1_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id1_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_networkdevice`.`id` = `_physicaldevice`.`id`))) join (((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) left join (((`ipaddress` `IPAddress_managementip_id_ipaddress` join `ipobject` `IPAddress_managementip_id_ipobject` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_datacenterdevice`.`managementip_id` = `IPAddress_managementip_id_ipaddress`.`id`))) on((`_networkdevice`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NetworkDeviceType`
--

/*!50001 DROP TABLE IF EXISTS `view_NetworkDeviceType`*/;
/*!50001 DROP VIEW IF EXISTS `view_NetworkDeviceType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NetworkDeviceType` AS select distinct `_networkdevicetype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`networkdevicetype` `_networkdevicetype` join `typology` `_typology` on((`_networkdevicetype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NetworkInterface`
--

/*!50001 DROP TABLE IF EXISTS `view_NetworkInterface`*/;
/*!50001 DROP VIEW IF EXISTS `view_NetworkInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NetworkInterface` AS select distinct `_networkinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_networkinterface`.`finalclass` AS `finalclass`,if((`_networkinterface`.`finalclass` = 'NetworkInterface'),cast(concat(coalesce(`_networkinterface`.`name`,'')) as char charset utf8),if((`_networkinterface`.`finalclass` = 'LogicalInterface'),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8),if((`_networkinterface`.`finalclass` = 'FiberChannelInterface'),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8)))) AS `friendlyname` from (((`networkinterface` `_networkinterface` left join (`logicalinterface` `_fn_LogicalInterface_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`_fn_LogicalInterface_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) on((`_networkinterface`.`id` = `_fn_LogicalInterface_logicalinterface`.`id`))) left join (`fiberchannelinterface` `_fn_FiberChannelInterface_fiberchannelinterface` join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id_functionalci` on((`DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id_functionalci`.`id`))) on((`_fn_FiberChannelInterface_fiberchannelinterface`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id`))) on((`_networkinterface`.`id` = `_fn_FiberChannelInterface_fiberchannelinterface`.`id`))) left join (`physicalinterface` `_fn_PhysicalInterface_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_fn_PhysicalInterface_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) on((`_networkinterface`.`id` = `_fn_PhysicalInterface_physicalinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSFamily`
--

/*!50001 DROP TABLE IF EXISTS `view_OSFamily`*/;
/*!50001 DROP VIEW IF EXISTS `view_OSFamily`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSFamily` AS select distinct `_osfamily`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`osfamily` `_osfamily` join `typology` `_typology` on((`_osfamily`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSLicence`
--

/*!50001 DROP TABLE IF EXISTS `view_OSLicence`*/;
/*!50001 DROP VIEW IF EXISTS `view_OSLicence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSLicence` AS select distinct `_oslicence`.`id` AS `id`,`_licence`.`name` AS `name`,`_licence`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_licence`.`usage_limit` AS `usage_limit`,`_licence`.`description` AS `description`,`_licence`.`start_date` AS `start_date`,`_licence`.`end_date` AS `end_date`,`_licence`.`licence_key` AS `licence_key`,`_licence`.`perpetual` AS `perpetual`,`_oslicence`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_licence`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_licence`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname` from ((`oslicence` `_oslicence` join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_oslicence`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) join (`licence` `_licence` join `organization` `Organization_org_id_organization` on((`_licence`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_oslicence`.`id` = `_licence`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSPatch`
--

/*!50001 DROP TABLE IF EXISTS `view_OSPatch`*/;
/*!50001 DROP VIEW IF EXISTS `view_OSPatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSPatch` AS select distinct `_ospatch`.`id` AS `id`,`_patch`.`name` AS `name`,`_patch`.`description` AS `description`,`_ospatch`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_patch`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_patch`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname` from ((`ospatch` `_ospatch` join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_ospatch`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) join `patch` `_patch` on((`_ospatch`.`id` = `_patch`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSVersion`
--

/*!50001 DROP TABLE IF EXISTS `view_OSVersion`*/;
/*!50001 DROP VIEW IF EXISTS `view_OSVersion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSVersion` AS select distinct `_osversion`.`id` AS `id`,`_typology`.`name` AS `name`,`_osversion`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname` from ((`osversion` `_osversion` join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_osversion`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) join `typology` `_typology` on((`_osversion`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Organization`
--

/*!50001 DROP TABLE IF EXISTS `view_Organization`*/;
/*!50001 DROP VIEW IF EXISTS `view_Organization`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Organization` AS select distinct `_organization`.`id` AS `id`,`_organization`.`name` AS `name`,`_organization`.`code` AS `code`,`_organization`.`status` AS `status`,`_organization`.`parent_id` AS `parent_id`,`Organization_parent_id_organization`.`name` AS `parent_name`,`_organization`.`deliverymodel_id` AS `deliverymodel_id`,`DeliveryModel_deliverymodel_id_deliverymodel`.`name` AS `deliverymodel_name`,cast(concat(coalesce(`_organization`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_parent_id_organization`.`name`,'')) as char charset utf8) AS `parent_id_friendlyname`,cast(concat(coalesce(`DeliveryModel_deliverymodel_id_deliverymodel`.`name`,'')) as char charset utf8) AS `deliverymodel_id_friendlyname` from ((`organization` `_organization` left join `organization` `Organization_parent_id_organization` on((`_organization`.`parent_id` = `Organization_parent_id_organization`.`id`))) left join `deliverymodel` `DeliveryModel_deliverymodel_id_deliverymodel` on((`_organization`.`deliverymodel_id` = `DeliveryModel_deliverymodel_id_deliverymodel`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OtherSoftware`
--

/*!50001 DROP TABLE IF EXISTS `view_OtherSoftware`*/;
/*!50001 DROP VIEW IF EXISTS `view_OtherSoftware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OtherSoftware` AS select distinct `_othersoftware`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`othersoftware` `_othersoftware` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_othersoftware`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_othersoftware`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PC`
--

/*!50001 DROP TABLE IF EXISTS `view_PC`*/;
/*!50001 DROP VIEW IF EXISTS `view_PC`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PC` AS select distinct `_pc`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_pc`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_pc`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_pc`.`cpu` AS `cpu`,`_pc`.`ram` AS `ram`,`_pc`.`type` AS `type`,`_pc`.`ipaddress_id` AS `ipaddress_id`,`IPAddress_ipaddress_id_ipaddress`.`fqdn` AS `ipaddress_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname`,if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `ipaddress_id_friendlyname`,`IPAddress_ipaddress_id_ipobject`.`finalclass` AS `ipaddress_id_finalclass_recall` from (((((`pc` `_pc` left join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_pc`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) left join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_pc`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) left join (((`ipaddress` `IPAddress_ipaddress_id_ipaddress` join `ipobject` `IPAddress_ipaddress_id_ipobject` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_pc`.`ipaddress_id` = `IPAddress_ipaddress_id_ipaddress`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_pc`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_pc`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PCSoftware`
--

/*!50001 DROP TABLE IF EXISTS `view_PCSoftware`*/;
/*!50001 DROP VIEW IF EXISTS `view_PCSoftware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PCSoftware` AS select distinct `_pcsoftware`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`pcsoftware` `_pcsoftware` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_pcsoftware`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_pcsoftware`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PDU`
--

/*!50001 DROP TABLE IF EXISTS `view_PDU`*/;
/*!50001 DROP VIEW IF EXISTS `view_PDU`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PDU` AS select distinct `_pdu`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_pdu`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_pdu`.`powerstart_id` AS `powerstart_id`,`PowerConnection_powerstart_id_functionalci`.`name` AS `powerstart_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerstart_id_functionalci`.`name`,'')) as char charset utf8) AS `powerstart_id_friendlyname`,`PowerConnection_powerstart_id_functionalci`.`finalclass` AS `powerstart_id_finalclass_recall` from ((((`pdu` `_pdu` join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_pdu`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`powerconnection` `PowerConnection_powerstart_id_powerconnection` join `functionalci` `PowerConnection_powerstart_id_functionalci` on((`PowerConnection_powerstart_id_powerconnection`.`id` = `PowerConnection_powerstart_id_functionalci`.`id`))) on((`_pdu`.`powerstart_id` = `PowerConnection_powerstart_id_powerconnection`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_pdu`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_pdu`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Patch`
--

/*!50001 DROP TABLE IF EXISTS `view_Patch`*/;
/*!50001 DROP VIEW IF EXISTS `view_Patch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Patch` AS select distinct `_patch`.`id` AS `id`,`_patch`.`name` AS `name`,`_patch`.`description` AS `description`,`_patch`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_patch`.`name`,'')) as char charset utf8) AS `friendlyname` from `patch` `_patch` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Peripheral`
--

/*!50001 DROP TABLE IF EXISTS `view_Peripheral`*/;
/*!50001 DROP VIEW IF EXISTS `view_Peripheral`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Peripheral` AS select distinct `_peripheral`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`peripheral` `_peripheral` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_peripheral`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_peripheral`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Person`
--

/*!50001 DROP TABLE IF EXISTS `view_Person`*/;
/*!50001 DROP VIEW IF EXISTS `view_Person`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Person` AS select distinct `_person`.`id` AS `id`,`_contact`.`name` AS `name`,`_contact`.`status` AS `status`,`_contact`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_contact`.`email` AS `email`,`_contact`.`phone` AS `phone`,`_contact`.`notify` AS `notify`,`_contact`.`function` AS `function`,`_person`.`first_name` AS `first_name`,`_person`.`employee_number` AS `employee_number`,`_person`.`mobile_phone` AS `mobile_phone`,`_person`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_person`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`name` AS `manager_name`,`_contact`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_person`.`first_name`,''),coalesce(' ',''),coalesce(`_contact`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname` from (((`person` `_person` left join `location` `Location_location_id_location` on((`_person`.`location_id` = `Location_location_id_location`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_person`.`manager_id` = `Person_manager_id_person`.`id`))) join (`contact` `_contact` join `organization` `Organization_org_id_organization` on((`_contact`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_person`.`id` = `_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Phone`
--

/*!50001 DROP TABLE IF EXISTS `view_Phone`*/;
/*!50001 DROP VIEW IF EXISTS `view_Phone`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Phone` AS select distinct `_phone`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from (((`phone` `_phone` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_phone`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_phone`.`id` = `_physicaldevice`.`id`))) join `telephonyci` `_telephonyci` on((`_phone`.`id` = `_telephonyci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PhysicalDevice`
--

/*!50001 DROP TABLE IF EXISTS `view_PhysicalDevice`*/;
/*!50001 DROP VIEW IF EXISTS `view_PhysicalDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PhysicalDevice` AS select distinct `_physicaldevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_physicaldevice`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PhysicalInterface`
--

/*!50001 DROP TABLE IF EXISTS `view_PhysicalInterface`*/;
/*!50001 DROP VIEW IF EXISTS `view_PhysicalInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PhysicalInterface` AS select distinct `_physicalinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_ipinterface`.`comment` AS `comment`,`_ipinterface`.`speed` AS `speed`,`_ipinterface`.`macaddress` AS `macaddress`,`_physicalinterface`.`connectableci_id` AS `connectableci_id`,`ConnectableCI_connectableci_id_functionalci`.`name` AS `connectableci_name`,`_networkinterface`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `connectableci_id_friendlyname`,`ConnectableCI_connectableci_id_functionalci`.`finalclass` AS `connectableci_id_finalclass_recall` from (((`physicalinterface` `_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) join `networkinterface` `_networkinterface` on((`_physicalinterface`.`id` = `_networkinterface`.`id`))) join `ipinterface` `_ipinterface` on((`_physicalinterface`.`id` = `_ipinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PowerConnection`
--

/*!50001 DROP TABLE IF EXISTS `view_PowerConnection`*/;
/*!50001 DROP VIEW IF EXISTS `view_PowerConnection`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PowerConnection` AS select distinct `_powerconnection`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`powerconnection` `_powerconnection` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_powerconnection`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_powerconnection`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PowerSource`
--

/*!50001 DROP TABLE IF EXISTS `view_PowerSource`*/;
/*!50001 DROP VIEW IF EXISTS `view_PowerSource`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PowerSource` AS select distinct `_powersource`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`powersource` `_powersource` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_powersource`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_powersource`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Printer`
--

/*!50001 DROP TABLE IF EXISTS `view_Printer`*/;
/*!50001 DROP VIEW IF EXISTS `view_Printer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Printer` AS select distinct `_printer`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_printer`.`ipaddress_id` AS `ipaddress_id`,`IPAddress_ipaddress_id_ipaddress`.`fqdn` AS `ipaddress_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `ipaddress_id_friendlyname`,`IPAddress_ipaddress_id_ipobject`.`finalclass` AS `ipaddress_id_finalclass_recall` from (((`printer` `_printer` left join (((`ipaddress` `IPAddress_ipaddress_id_ipaddress` join `ipobject` `IPAddress_ipaddress_id_ipobject` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_printer`.`ipaddress_id` = `IPAddress_ipaddress_id_ipaddress`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_printer`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_printer`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Problem`
--

/*!50001 DROP TABLE IF EXISTS `view_Problem`*/;
/*!50001 DROP VIEW IF EXISTS `view_Problem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Problem` AS select distinct `_ticket_problem`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket_problem`.`status` AS `status`,`_ticket_problem`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_ticket_problem`.`servicesubcategory_id` AS `servicesubcategory_id`,`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name` AS `servicesubcategory_name`,`_ticket_problem`.`product` AS `product`,`_ticket_problem`.`impact` AS `impact`,`_ticket_problem`.`urgency` AS `urgency`,`_ticket_problem`.`priority` AS `priority`,`_ticket_problem`.`related_change_id` AS `related_change_id`,`Change_related_change_id_ticket`.`ref` AS `related_change_ref`,`_ticket_problem`.`assignment_date` AS `assignment_date`,`_ticket_problem`.`resolution_date` AS `resolution_date`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_id_friendlyname`,cast(concat(coalesce(`Change_related_change_id_ticket`.`ref`,'')) as char charset utf8) AS `related_change_id_friendlyname` from ((((`ticket_problem` `_ticket_problem` left join `service` `Service_service_id_service` on((`_ticket_problem`.`service_id` = `Service_service_id_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_id_servicesubcategory` on((`_ticket_problem`.`servicesubcategory_id` = `ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`id`))) left join (`ticket_change` `Change_related_change_id_ticket_change` join `ticket` `Change_related_change_id_ticket` on((`Change_related_change_id_ticket_change`.`id` = `Change_related_change_id_ticket`.`id`))) on((`_ticket_problem`.`related_change_id` = `Change_related_change_id_ticket_change`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_ticket_problem`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ProviderContract`
--

/*!50001 DROP TABLE IF EXISTS `view_ProviderContract`*/;
/*!50001 DROP VIEW IF EXISTS `view_ProviderContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ProviderContract` AS select distinct `_providercontract`.`id` AS `id`,`_contract`.`name` AS `name`,`_contract`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_contract`.`description` AS `description`,`_contract`.`start_date` AS `start_date`,`_contract`.`end_date` AS `end_date`,`_contract`.`cost` AS `cost`,`_contract`.`cost_currency` AS `cost_currency`,`_contract`.`contracttype_id` AS `contracttype_id`,`ContractType_contracttype_id_typology`.`name` AS `contracttype_name`,`_contract`.`billing_frequency` AS `billing_frequency`,`_contract`.`cost_unit` AS `cost_unit`,`_contract`.`provider_id` AS `provider_id`,`Organization_provider_id_organization`.`name` AS `provider_name`,`_contract`.`status` AS `status`,`_providercontract`.`sla` AS `sla`,`_providercontract`.`coverage` AS `coverage`,`_contract`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contract`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ContractType_contracttype_id_typology`.`name`,'')) as char charset utf8) AS `contracttype_id_friendlyname`,cast(concat(coalesce(`Organization_provider_id_organization`.`name`,'')) as char charset utf8) AS `provider_id_friendlyname` from (`providercontract` `_providercontract` join (((`contract` `_contract` join `organization` `Organization_org_id_organization` on((`_contract`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`contracttype` `ContractType_contracttype_id_contracttype` join `typology` `ContractType_contracttype_id_typology` on((`ContractType_contracttype_id_contracttype`.`id` = `ContractType_contracttype_id_typology`.`id`))) on((`_contract`.`contracttype_id` = `ContractType_contracttype_id_contracttype`.`id`))) join `organization` `Organization_provider_id_organization` on((`_contract`.`provider_id` = `Organization_provider_id_organization`.`id`))) on((`_providercontract`.`id` = `_contract`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Rack`
--

/*!50001 DROP TABLE IF EXISTS `view_Rack`*/;
/*!50001 DROP VIEW IF EXISTS `view_Rack`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Rack` AS select distinct `_rack`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_rack`.`nb_u` AS `nb_u`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`rack` `_rack` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_rack`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_rack`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SANSwitch`
--

/*!50001 DROP TABLE IF EXISTS `view_SANSwitch`*/;
/*!50001 DROP VIEW IF EXISTS `view_SANSwitch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SANSwitch` AS select distinct `_sanswitch`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_datacenterdevice`.`managementip_id` AS `managementip_id`,`IPAddress_managementip_id_ipaddress`.`fqdn` AS `managementip_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `managementip_id_friendlyname`,`IPAddress_managementip_id_ipobject`.`finalclass` AS `managementip_id_finalclass_recall` from (((`sanswitch` `_sanswitch` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_sanswitch`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_sanswitch`.`id` = `_physicaldevice`.`id`))) join (((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) left join (((`ipaddress` `IPAddress_managementip_id_ipaddress` join `ipobject` `IPAddress_managementip_id_ipobject` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_datacenterdevice`.`managementip_id` = `IPAddress_managementip_id_ipaddress`.`id`))) on((`_sanswitch`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SLA`
--

/*!50001 DROP TABLE IF EXISTS `view_SLA`*/;
/*!50001 DROP VIEW IF EXISTS `view_SLA`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SLA` AS select distinct `_sla`.`id` AS `id`,`_sla`.`name` AS `name`,`_sla`.`description` AS `description`,`_sla`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,cast(concat(coalesce(`_sla`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`sla` `_sla` join `organization` `Organization_org_id_organization` on((`_sla`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SLT`
--

/*!50001 DROP TABLE IF EXISTS `view_SLT`*/;
/*!50001 DROP VIEW IF EXISTS `view_SLT`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SLT` AS select distinct `_slt`.`id` AS `id`,`_slt`.`name` AS `name`,`_slt`.`priority` AS `priority`,`_slt`.`request_type` AS `request_type`,`_slt`.`metric` AS `metric`,`_slt`.`value` AS `value`,`_slt`.`unit` AS `unit`,cast(concat(coalesce(`_slt`.`name`,'')) as char charset utf8) AS `friendlyname` from `slt` `_slt` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Server`
--

/*!50001 DROP TABLE IF EXISTS `view_Server`*/;
/*!50001 DROP VIEW IF EXISTS `view_Server`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Server` AS select distinct `_server`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_datacenterdevice`.`managementip_id` AS `managementip_id`,`IPAddress_managementip_id_ipaddress`.`fqdn` AS `managementip_name`,`_server`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_server`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_server`.`oslicence_id` AS `oslicence_id`,`OSLicence_oslicence_id_licence`.`name` AS `oslicence_name`,`_server`.`cpu` AS `cpu`,`_server`.`ram` AS `ram`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `managementip_id_friendlyname`,`IPAddress_managementip_id_ipobject`.`finalclass` AS `managementip_id_finalclass_recall`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname`,cast(concat(coalesce(`OSLicence_oslicence_id_licence`.`name`,'')) as char charset utf8) AS `oslicence_id_friendlyname` from ((((((`server` `_server` left join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_server`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) left join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_server`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) left join (`oslicence` `OSLicence_oslicence_id_oslicence` join `licence` `OSLicence_oslicence_id_licence` on((`OSLicence_oslicence_id_oslicence`.`id` = `OSLicence_oslicence_id_licence`.`id`))) on((`_server`.`oslicence_id` = `OSLicence_oslicence_id_oslicence`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_server`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_server`.`id` = `_physicaldevice`.`id`))) join (((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) left join (((`ipaddress` `IPAddress_managementip_id_ipaddress` join `ipobject` `IPAddress_managementip_id_ipobject` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_datacenterdevice`.`managementip_id` = `IPAddress_managementip_id_ipaddress`.`id`))) on((`_server`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Service`
--

/*!50001 DROP TABLE IF EXISTS `view_Service`*/;
/*!50001 DROP VIEW IF EXISTS `view_Service`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Service` AS select distinct `_service`.`id` AS `id`,`_service`.`name` AS `name`,`_service`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_service`.`servicefamily_id` AS `servicefamily_id`,`ServiceFamily_servicefamily_id_servicefamily`.`name` AS `servicefamily_name`,`_service`.`description` AS `description`,`_service`.`status` AS `status`,cast(concat(coalesce(`_service`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ServiceFamily_servicefamily_id_servicefamily`.`name`,'')) as char charset utf8) AS `servicefamily_id_friendlyname` from ((`service` `_service` join `organization` `Organization_org_id_organization` on((`_service`.`org_id` = `Organization_org_id_organization`.`id`))) left join `servicefamily` `ServiceFamily_servicefamily_id_servicefamily` on((`_service`.`servicefamily_id` = `ServiceFamily_servicefamily_id_servicefamily`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ServiceFamily`
--

/*!50001 DROP TABLE IF EXISTS `view_ServiceFamily`*/;
/*!50001 DROP VIEW IF EXISTS `view_ServiceFamily`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ServiceFamily` AS select distinct `_servicefamily`.`id` AS `id`,`_servicefamily`.`name` AS `name`,cast(concat(coalesce(`_servicefamily`.`name`,'')) as char charset utf8) AS `friendlyname` from `servicefamily` `_servicefamily` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ServiceSubcategory`
--

/*!50001 DROP TABLE IF EXISTS `view_ServiceSubcategory`*/;
/*!50001 DROP VIEW IF EXISTS `view_ServiceSubcategory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ServiceSubcategory` AS select distinct `_servicesubcategory`.`id` AS `id`,`_servicesubcategory`.`name` AS `name`,`_servicesubcategory`.`description` AS `description`,`_servicesubcategory`.`service_id` AS `service_id`,`Service_service_id_service`.`org_id` AS `service_org_id`,`Service_service_id_service`.`name` AS `service_name`,`Organization_org_id_organization`.`name` AS `service_provider`,`_servicesubcategory`.`request_type` AS `request_type`,`_servicesubcategory`.`status` AS `status`,cast(concat(coalesce(`_servicesubcategory`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `service_org_id_friendlyname` from (`servicesubcategory` `_servicesubcategory` join (`service` `Service_service_id_service` join `organization` `Organization_org_id_organization` on((`Service_service_id_service`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_servicesubcategory`.`service_id` = `Service_service_id_service`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Software`
--

/*!50001 DROP TABLE IF EXISTS `view_Software`*/;
/*!50001 DROP VIEW IF EXISTS `view_Software`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Software` AS select distinct `_software`.`id` AS `id`,`_software`.`name` AS `name`,`_software`.`vendor` AS `vendor`,`_software`.`version` AS `version`,`_software`.`type` AS `type`,cast(concat(coalesce(`_software`.`name`,''),coalesce(' ',''),coalesce(`_software`.`version`,'')) as char charset utf8) AS `friendlyname` from `software` `_software` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SoftwareInstance`
--

/*!50001 DROP TABLE IF EXISTS `view_SoftwareInstance`*/;
/*!50001 DROP VIEW IF EXISTS `view_SoftwareInstance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SoftwareInstance` AS select distinct `_softwareinstance`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_softwareinstance`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SoftwareLicence`
--

/*!50001 DROP TABLE IF EXISTS `view_SoftwareLicence`*/;
/*!50001 DROP VIEW IF EXISTS `view_SoftwareLicence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SoftwareLicence` AS select distinct `_softwarelicence`.`id` AS `id`,`_licence`.`name` AS `name`,`_licence`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_licence`.`usage_limit` AS `usage_limit`,`_licence`.`description` AS `description`,`_licence`.`start_date` AS `start_date`,`_licence`.`end_date` AS `end_date`,`_licence`.`licence_key` AS `licence_key`,`_licence`.`perpetual` AS `perpetual`,`_softwarelicence`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_licence`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_licence`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname` from ((`softwarelicence` `_softwarelicence` join `software` `Software_software_id_software` on((`_softwarelicence`.`software_id` = `Software_software_id_software`.`id`))) join (`licence` `_licence` join `organization` `Organization_org_id_organization` on((`_licence`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_softwarelicence`.`id` = `_licence`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SoftwarePatch`
--

/*!50001 DROP TABLE IF EXISTS `view_SoftwarePatch`*/;
/*!50001 DROP VIEW IF EXISTS `view_SoftwarePatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SoftwarePatch` AS select distinct `_softwarepatch`.`id` AS `id`,`_patch`.`name` AS `name`,`_patch`.`description` AS `description`,`_softwarepatch`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_patch`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_patch`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname` from ((`softwarepatch` `_softwarepatch` join `software` `Software_software_id_software` on((`_softwarepatch`.`software_id` = `Software_software_id_software`.`id`))) join `patch` `_patch` on((`_softwarepatch`.`id` = `_patch`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_StorageSystem`
--

/*!50001 DROP TABLE IF EXISTS `view_StorageSystem`*/;
/*!50001 DROP VIEW IF EXISTS `view_StorageSystem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_StorageSystem` AS select distinct `_storagesystem`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_datacenterdevice`.`managementip_id` AS `managementip_id`,`IPAddress_managementip_id_ipaddress`.`fqdn` AS `managementip_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `managementip_id_friendlyname`,`IPAddress_managementip_id_ipobject`.`finalclass` AS `managementip_id_finalclass_recall` from (((`storagesystem` `_storagesystem` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_storagesystem`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_storagesystem`.`id` = `_physicaldevice`.`id`))) join (((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) left join (((`ipaddress` `IPAddress_managementip_id_ipaddress` join `ipobject` `IPAddress_managementip_id_ipobject` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_datacenterdevice`.`managementip_id` = `IPAddress_managementip_id_ipaddress`.`id`))) on((`_storagesystem`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Subnet`
--

/*!50001 DROP TABLE IF EXISTS `view_Subnet`*/;
/*!50001 DROP VIEW IF EXISTS `view_Subnet`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Subnet` AS select distinct `_subnet`.`id` AS `id`,`_subnet`.`description` AS `description`,`_subnet`.`subnet_name` AS `subnet_name`,`_subnet`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_subnet`.`ip` AS `ip`,`_subnet`.`ip_mask` AS `ip_mask`,cast(concat(coalesce(`_subnet`.`ip`,''),coalesce(' ',''),coalesce(`_subnet`.`ip_mask`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`subnet` `_subnet` join `organization` `Organization_org_id_organization` on((`_subnet`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Tablet`
--

/*!50001 DROP TABLE IF EXISTS `view_Tablet`*/;
/*!50001 DROP VIEW IF EXISTS `view_Tablet`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Tablet` AS select distinct `_tablet`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_tablet`.`ipaddress_id` AS `ipaddress_id`,`IPAddress_ipaddress_id_ipaddress`.`fqdn` AS `ipaddress_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `ipaddress_id_friendlyname`,`IPAddress_ipaddress_id_ipobject`.`finalclass` AS `ipaddress_id_finalclass_recall` from (((`tablet` `_tablet` left join (((`ipaddress` `IPAddress_ipaddress_id_ipaddress` join `ipobject` `IPAddress_ipaddress_id_ipobject` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_tablet`.`ipaddress_id` = `IPAddress_ipaddress_id_ipaddress`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_tablet`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_tablet`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Tape`
--

/*!50001 DROP TABLE IF EXISTS `view_Tape`*/;
/*!50001 DROP VIEW IF EXISTS `view_Tape`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Tape` AS select distinct `_tape`.`id` AS `id`,`_tape`.`name` AS `name`,`_tape`.`description` AS `description`,`_tape`.`size` AS `size`,`_tape`.`tapelibrary_id` AS `tapelibrary_id`,`TapeLibrary_tapelibrary_id_functionalci`.`name` AS `tapelibrary_name`,cast(concat(coalesce(`_tape`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`TapeLibrary_tapelibrary_id_functionalci`.`name`,'')) as char charset utf8) AS `tapelibrary_id_friendlyname` from (`tape` `_tape` join (`tapelibrary` `TapeLibrary_tapelibrary_id_tapelibrary` join `functionalci` `TapeLibrary_tapelibrary_id_functionalci` on((`TapeLibrary_tapelibrary_id_tapelibrary`.`id` = `TapeLibrary_tapelibrary_id_functionalci`.`id`))) on((`_tape`.`tapelibrary_id` = `TapeLibrary_tapelibrary_id_tapelibrary`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TapeLibrary`
--

/*!50001 DROP TABLE IF EXISTS `view_TapeLibrary`*/;
/*!50001 DROP VIEW IF EXISTS `view_TapeLibrary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TapeLibrary` AS select distinct `_tapelibrary`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_datacenterdevice`.`redundancy` AS `redundancy`,`_datacenterdevice`.`managementip_id` AS `managementip_id`,`IPAddress_managementip_id_ipaddress`.`fqdn` AS `managementip_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `managementip_id_friendlyname`,`IPAddress_managementip_id_ipobject`.`finalclass` AS `managementip_id_finalclass_recall` from (((`tapelibrary` `_tapelibrary` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_tapelibrary`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_tapelibrary`.`id` = `_physicaldevice`.`id`))) join (((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) left join (((`ipaddress` `IPAddress_managementip_id_ipaddress` join `ipobject` `IPAddress_managementip_id_ipobject` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_datacenterdevice`.`managementip_id` = `IPAddress_managementip_id_ipaddress`.`id`))) on((`_tapelibrary`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Team`
--

/*!50001 DROP TABLE IF EXISTS `view_Team`*/;
/*!50001 DROP VIEW IF EXISTS `view_Team`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Team` AS select distinct `_team`.`id` AS `id`,`_contact`.`name` AS `name`,`_contact`.`status` AS `status`,`_contact`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_contact`.`email` AS `email`,`_contact`.`phone` AS `phone`,`_contact`.`notify` AS `notify`,`_contact`.`function` AS `function`,`_contact`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contact`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`team` `_team` join (`contact` `_contact` join `organization` `Organization_org_id_organization` on((`_contact`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_team`.`id` = `_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TelephonyCI`
--

/*!50001 DROP TABLE IF EXISTS `view_TelephonyCI`*/;
/*!50001 DROP VIEW IF EXISTS `view_TelephonyCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TelephonyCI` AS select distinct `_telephonyci`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`telephonyci` `_telephonyci` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_telephonyci`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_telephonyci`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Ticket`
--

/*!50001 DROP TABLE IF EXISTS `view_Ticket`*/;
/*!50001 DROP VIEW IF EXISTS `view_Ticket`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Ticket` AS select distinct `_ticket`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname` from ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Typology`
--

/*!50001 DROP TABLE IF EXISTS `view_Typology`*/;
/*!50001 DROP VIEW IF EXISTS `view_Typology`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Typology` AS select distinct `_typology`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,if((`_typology`.`finalclass` = 'IOSVersion'),cast(concat(coalesce(`Brand_brand_id_typology`.`name`,''),coalesce(' ',''),coalesce(`_typology`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8)) AS `friendlyname` from (`typology` `_typology` left join (`iosversion` `_fn_IOSVersion_iosversion` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_fn_IOSVersion_iosversion`.`brand_id` = `Brand_brand_id_brand`.`id`))) on((`_typology`.`id` = `_fn_IOSVersion_iosversion`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_UserRequest`
--

/*!50001 DROP TABLE IF EXISTS `view_UserRequest`*/;
/*!50001 DROP VIEW IF EXISTS `view_UserRequest`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_UserRequest` AS select distinct `_ticket_request`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket_request`.`status` AS `status`,`_ticket_request`.`request_type` AS `request_type`,`_ticket_request`.`impact` AS `impact`,`_ticket_request`.`priority` AS `priority`,`_ticket_request`.`urgency` AS `urgency`,`_ticket_request`.`origin` AS `origin`,`_ticket_request`.`approver_id` AS `approver_id`,`Person_approver_id_contact`.`email` AS `approver_email`,`_ticket_request`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_ticket_request`.`servicesubcategory_id` AS `servicesubcategory_id`,`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name` AS `servicesubcategory_name`,`_ticket_request`.`escalation_flag` AS `escalation_flag`,`_ticket_request`.`escalation_reason` AS `escalation_reason`,`_ticket_request`.`assignment_date` AS `assignment_date`,`_ticket_request`.`resolution_date` AS `resolution_date`,`_ticket_request`.`last_pending_date` AS `last_pending_date`,`_ticket_request`.`cumulatedpending_timespent` AS `cumulatedpending`,`_ticket_request`.`cumulatedpending_started` AS `cumulatedpending_started`,`_ticket_request`.`cumulatedpending_laststart` AS `cumulatedpending_laststart`,`_ticket_request`.`cumulatedpending_stopped` AS `cumulatedpending_stopped`,`_ticket_request`.`tto_timespent` AS `tto`,`_ticket_request`.`tto_started` AS `tto_started`,`_ticket_request`.`tto_laststart` AS `tto_laststart`,`_ticket_request`.`tto_stopped` AS `tto_stopped`,`_ticket_request`.`tto_75_deadline` AS `tto_75_deadline`,`_ticket_request`.`tto_75_passed` AS `tto_75_passed`,`_ticket_request`.`tto_75_triggered` AS `tto_75_triggered`,`_ticket_request`.`tto_75_overrun` AS `tto_75_overrun`,`_ticket_request`.`tto_100_deadline` AS `tto_100_deadline`,`_ticket_request`.`tto_100_passed` AS `tto_100_passed`,`_ticket_request`.`tto_100_triggered` AS `tto_100_triggered`,`_ticket_request`.`tto_100_overrun` AS `tto_100_overrun`,`_ticket_request`.`ttr_timespent` AS `ttr`,`_ticket_request`.`ttr_started` AS `ttr_started`,`_ticket_request`.`ttr_laststart` AS `ttr_laststart`,`_ticket_request`.`ttr_stopped` AS `ttr_stopped`,`_ticket_request`.`ttr_75_deadline` AS `ttr_75_deadline`,`_ticket_request`.`ttr_75_passed` AS `ttr_75_passed`,`_ticket_request`.`ttr_75_triggered` AS `ttr_75_triggered`,`_ticket_request`.`ttr_75_overrun` AS `ttr_75_overrun`,`_ticket_request`.`ttr_100_deadline` AS `ttr_100_deadline`,`_ticket_request`.`ttr_100_passed` AS `ttr_100_passed`,`_ticket_request`.`ttr_100_triggered` AS `ttr_100_triggered`,`_ticket_request`.`ttr_100_overrun` AS `ttr_100_overrun`,`_ticket_request`.`tto_100_deadline` AS `tto_escalation_deadline`,`_ticket_request`.`tto_100_passed` AS `sla_tto_passed`,`_ticket_request`.`tto_100_overrun` AS `sla_tto_over`,`_ticket_request`.`ttr_100_deadline` AS `ttr_escalation_deadline`,`_ticket_request`.`ttr_100_passed` AS `sla_ttr_passed`,`_ticket_request`.`ttr_100_overrun` AS `sla_ttr_over`,`_ticket_request`.`time_spent` AS `time_spent`,`_ticket_request`.`resolution_code` AS `resolution_code`,`_ticket_request`.`solution` AS `solution`,`_ticket_request`.`pending_reason` AS `pending_reason`,`_ticket_request`.`parent_request_id` AS `parent_request_id`,`UserRequest_parent_request_id_ticket`.`ref` AS `parent_request_ref`,`_ticket_request`.`parent_problem_id` AS `parent_problem_id`,`Problem_parent_problem_id_ticket`.`ref` AS `parent_problem_ref`,`_ticket_request`.`parent_change_id` AS `parent_change_id`,`Change_parent_change_id_ticket`.`ref` AS `parent_change_ref`,`_ticket_request`.`public_log` AS `public_log`,`_ticket_request`.`public_log_index` AS `public_log_index`,`_ticket_request`.`user_satisfaction` AS `user_satisfaction`,`_ticket_request`.`user_commment` AS `user_comment`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_approver_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_approver_id_contact`.`name`,'')) as char charset utf8) AS `approver_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_id_friendlyname`,cast(concat(coalesce(`UserRequest_parent_request_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_request_id_friendlyname`,cast(concat(coalesce(`Problem_parent_problem_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_problem_id_friendlyname`,cast(concat(coalesce(`Change_parent_change_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_change_id_friendlyname` from (((((((`ticket_request` `_ticket_request` left join (`person` `Person_approver_id_person` join `contact` `Person_approver_id_contact` on((`Person_approver_id_person`.`id` = `Person_approver_id_contact`.`id`))) on((`_ticket_request`.`approver_id` = `Person_approver_id_person`.`id`))) left join `service` `Service_service_id_service` on((`_ticket_request`.`service_id` = `Service_service_id_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_id_servicesubcategory` on((`_ticket_request`.`servicesubcategory_id` = `ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`id`))) left join (`ticket_request` `UserRequest_parent_request_id_ticket_request` join `ticket` `UserRequest_parent_request_id_ticket` on((`UserRequest_parent_request_id_ticket_request`.`id` = `UserRequest_parent_request_id_ticket`.`id`))) on((`_ticket_request`.`parent_request_id` = `UserRequest_parent_request_id_ticket_request`.`id`))) left join (`ticket_problem` `Problem_parent_problem_id_ticket_problem` join `ticket` `Problem_parent_problem_id_ticket` on((`Problem_parent_problem_id_ticket_problem`.`id` = `Problem_parent_problem_id_ticket`.`id`))) on((`_ticket_request`.`parent_problem_id` = `Problem_parent_problem_id_ticket_problem`.`id`))) left join (`ticket_change` `Change_parent_change_id_ticket_change` join `ticket` `Change_parent_change_id_ticket` on((`Change_parent_change_id_ticket_change`.`id` = `Change_parent_change_id_ticket`.`id`))) on((`_ticket_request`.`parent_change_id` = `Change_parent_change_id_ticket_change`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_ticket_request`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VLAN`
--

/*!50001 DROP TABLE IF EXISTS `view_VLAN`*/;
/*!50001 DROP VIEW IF EXISTS `view_VLAN`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VLAN` AS select distinct `_vlan`.`id` AS `id`,`_vlan`.`vlan_tag` AS `vlan_tag`,`_vlan`.`description` AS `description`,`_vlan`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,cast(concat(coalesce(`_vlan`.`vlan_tag`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`vlan` `_vlan` join `organization` `Organization_org_id_organization` on((`_vlan`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VRF`
--

/*!50001 DROP TABLE IF EXISTS `view_VRF`*/;
/*!50001 DROP VIEW IF EXISTS `view_VRF`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VRF` AS select distinct `_vrf`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_vrf`.`route_dist` AS `route_dist`,`_vrf`.`route_trgt` AS `route_trgt`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`vrf` `_vrf` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_vrf`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VirtualDevice`
--

/*!50001 DROP TABLE IF EXISTS `view_VirtualDevice`*/;
/*!50001 DROP VIEW IF EXISTS `view_VirtualDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VirtualDevice` AS select distinct `_virtualdevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`virtualdevice` `_virtualdevice` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_virtualdevice`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VirtualHost`
--

/*!50001 DROP TABLE IF EXISTS `view_VirtualHost`*/;
/*!50001 DROP VIEW IF EXISTS `view_VirtualHost`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VirtualHost` AS select distinct `_virtualhost`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`virtualhost` `_virtualhost` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_virtualhost`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_virtualhost`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VirtualMachine`
--

/*!50001 DROP TABLE IF EXISTS `view_VirtualMachine`*/;
/*!50001 DROP VIEW IF EXISTS `view_VirtualMachine`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VirtualMachine` AS select distinct `_virtualmachine`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_virtualmachine`.`virtualhost_id` AS `virtualhost_id`,`VirtualHost_virtualhost_id_functionalci`.`name` AS `virtualhost_name`,`_virtualmachine`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_virtualmachine`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_virtualmachine`.`oslicence_id` AS `oslicence_id`,`OSLicence_oslicence_id_licence`.`name` AS `oslicence_name`,`_virtualmachine`.`cpu` AS `cpu`,`_virtualmachine`.`ram` AS `ram`,`_virtualmachine`.`managementip_id` AS `managementip_id`,`IPAddress_managementip_id_ipaddress`.`fqdn` AS `managementip_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`VirtualHost_virtualhost_id_functionalci`.`name`,'')) as char charset utf8) AS `virtualhost_id_friendlyname`,`VirtualHost_virtualhost_id_functionalci`.`finalclass` AS `virtualhost_id_finalclass_recall`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname`,cast(concat(coalesce(`OSLicence_oslicence_id_licence`.`name`,'')) as char charset utf8) AS `oslicence_id_friendlyname`,if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_managementip_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `managementip_id_friendlyname`,`IPAddress_managementip_id_ipobject`.`finalclass` AS `managementip_id_finalclass_recall` from (((((((`virtualmachine` `_virtualmachine` join (`virtualhost` `VirtualHost_virtualhost_id_virtualhost` join `functionalci` `VirtualHost_virtualhost_id_functionalci` on((`VirtualHost_virtualhost_id_virtualhost`.`id` = `VirtualHost_virtualhost_id_functionalci`.`id`))) on((`_virtualmachine`.`virtualhost_id` = `VirtualHost_virtualhost_id_virtualhost`.`id`))) left join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_virtualmachine`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) left join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_virtualmachine`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) left join (`oslicence` `OSLicence_oslicence_id_oslicence` join `licence` `OSLicence_oslicence_id_licence` on((`OSLicence_oslicence_id_oslicence`.`id` = `OSLicence_oslicence_id_licence`.`id`))) on((`_virtualmachine`.`oslicence_id` = `OSLicence_oslicence_id_oslicence`.`id`))) left join (((`ipaddress` `IPAddress_managementip_id_ipaddress` join `ipobject` `IPAddress_managementip_id_ipobject` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_managementip_id_ipaddress`.`id` = `IPAddress_managementip_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_virtualmachine`.`managementip_id` = `IPAddress_managementip_id_ipaddress`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_virtualmachine`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_virtualmachine`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WANLink`
--

/*!50001 DROP TABLE IF EXISTS `view_WANLink`*/;
/*!50001 DROP VIEW IF EXISTS `view_WANLink`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WANLink` AS select distinct `_wanlink`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_wanlink`.`status` AS `status`,`_wanlink`.`location_id1` AS `location_id1`,`Location_location_id1_location`.`name` AS `location_name1`,`_wanlink`.`location_id2` AS `location_id2`,`Location_location_id2_location`.`name` AS `location_name2`,`_wanlink`.`type_id` AS `type_id`,`WANType_type_id_typology`.`name` AS `type_name`,`_wanlink`.`rate` AS `rate`,`_wanlink`.`burst_rate` AS `burst_rate`,`_wanlink`.`underlying_rate` AS `underlying_rate`,`_wanlink`.`networkinterface_id1` AS `networkinterface_id1`,`NetworkInterface_networkinterface_id1_networkinterface`.`name` AS `networkinterface_name1`,`_wanlink`.`networkinterface_id2` AS `networkinterface_id2`,`NetworkInterface_networkinterface_id2_networkinterface`.`name` AS `networkinterface_name2`,`_wanlink`.`carrier_id` AS `carrier_id`,`Organization_carrier_id_organization`.`name` AS `carrier_name`,`_wanlink`.`carrier_ref` AS `carrier_reference`,`_wanlink`.`internal_reference` AS `internal_reference`,`_wanlink`.`purchase_date` AS `purchase_date`,`_wanlink`.`renewal_date` AS `renewal_date`,`_wanlink`.`decommissioning_date` AS `decommissioning_date`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id1_location`.`name`,'')) as char charset utf8) AS `location_id1_friendlyname`,cast(concat(coalesce(`Location_location_id2_location`.`name`,'')) as char charset utf8) AS `location_id2_friendlyname`,cast(concat(coalesce(`WANType_type_id_typology`.`name`,'')) as char charset utf8) AS `type_id_friendlyname`,if((`NetworkInterface_networkinterface_id1_networkinterface`.`finalclass` = 'NetworkInterface'),cast(concat(coalesce(`NetworkInterface_networkinterface_id1_networkinterface`.`name`,'')) as char charset utf8),if((`NetworkInterface_networkinterface_id1_networkinterface`.`finalclass` = 'LogicalInterface'),cast(concat(coalesce(`NetworkInterface_networkinterface_id1_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8),if((`NetworkInterface_networkinterface_id1_networkinterface`.`finalclass` = 'FiberChannelInterface'),cast(concat(coalesce(`NetworkInterface_networkinterface_id1_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`NetworkInterface_networkinterface_id1_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8)))) AS `networkinterface_id1_friendlyname`,`NetworkInterface_networkinterface_id1_networkinterface`.`finalclass` AS `networkinterface_id1_finalclass_recall`,if((`NetworkInterface_networkinterface_id2_networkinterface`.`finalclass` = 'NetworkInterface'),cast(concat(coalesce(`NetworkInterface_networkinterface_id2_networkinterface`.`name`,'')) as char charset utf8),if((`NetworkInterface_networkinterface_id2_networkinterface`.`finalclass` = 'LogicalInterface'),cast(concat(coalesce(`NetworkInterface_networkinterface_id2_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id1_functionalci`.`name`,'')) as char charset utf8),if((`NetworkInterface_networkinterface_id2_networkinterface`.`finalclass` = 'FiberChannelInterface'),cast(concat(coalesce(`NetworkInterface_networkinterface_id2_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`DatacenterDevice_datacenterdevice_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`NetworkInterface_networkinterface_id2_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id1_functionalci`.`name`,'')) as char charset utf8)))) AS `networkinterface_id2_friendlyname`,`NetworkInterface_networkinterface_id2_networkinterface`.`finalclass` AS `networkinterface_id2_finalclass_recall`,cast(concat(coalesce(`Organization_carrier_id_organization`.`name`,'')) as char charset utf8) AS `carrier_id_friendlyname` from (((((((`wanlink` `_wanlink` left join `location` `Location_location_id1_location` on((`_wanlink`.`location_id1` = `Location_location_id1_location`.`id`))) left join `location` `Location_location_id2_location` on((`_wanlink`.`location_id2` = `Location_location_id2_location`.`id`))) left join (`wantype` `WANType_type_id_wantype` join `typology` `WANType_type_id_typology` on((`WANType_type_id_wantype`.`id` = `WANType_type_id_typology`.`id`))) on((`_wanlink`.`type_id` = `WANType_type_id_wantype`.`id`))) left join (((`networkinterface` `NetworkInterface_networkinterface_id1_networkinterface` left join (`logicalinterface` `NetworkInterface_networkinterface_id1_fn_LogicalInterface_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`NetworkInterface_networkinterface_id1_fn_LogicalInterface_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) on((`NetworkInterface_networkinterface_id1_networkinterface`.`id` = `NetworkInterface_networkinterface_id1_fn_LogicalInterface_logicalinterface`.`id`))) left join (`fiberchannelinterface` `NetworkInterface_networkinterface_id1_fn_FiberChannelInterface_fiberchannelinterface` join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id_functionalci` on((`DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id_functionalci`.`id`))) on((`NetworkInterface_networkinterface_id1_fn_FiberChannelInterface_fiberchannelinterface`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id`))) on((`NetworkInterface_networkinterface_id1_networkinterface`.`id` = `NetworkInterface_networkinterface_id1_fn_FiberChannelInterface_fiberchannelinterface`.`id`))) left join (`physicalinterface` `NetworkInterface_networkinterface_id1_fn_PhysicalInterface_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`NetworkInterface_networkinterface_id1_fn_PhysicalInterface_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) on((`NetworkInterface_networkinterface_id1_networkinterface`.`id` = `NetworkInterface_networkinterface_id1_fn_PhysicalInterface_physicalinterface`.`id`))) on((`_wanlink`.`networkinterface_id1` = `NetworkInterface_networkinterface_id1_networkinterface`.`id`))) left join (((`networkinterface` `NetworkInterface_networkinterface_id2_networkinterface` left join (`logicalinterface` `NetworkInterface_networkinterface_id2_fn_LogicalInterface_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id1_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id1_functionalci` on((`VirtualMachine_virtualmachine_id1_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id1_functionalci`.`id`))) on((`NetworkInterface_networkinterface_id2_fn_LogicalInterface_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id1_virtualmachine`.`id`))) on((`NetworkInterface_networkinterface_id2_networkinterface`.`id` = `NetworkInterface_networkinterface_id2_fn_LogicalInterface_logicalinterface`.`id`))) left join (`fiberchannelinterface` `NetworkInterface_networkinterface_id2_fn_FiberChannelInterface_fiberchannelinterface` join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id1_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id1_functionalci` on((`DatacenterDevice_datacenterdevice_id1_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id1_functionalci`.`id`))) on((`NetworkInterface_networkinterface_id2_fn_FiberChannelInterface_fiberchannelinterface`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id1_datacenterdevice`.`id`))) on((`NetworkInterface_networkinterface_id2_networkinterface`.`id` = `NetworkInterface_networkinterface_id2_fn_FiberChannelInterface_fiberchannelinterface`.`id`))) left join (`physicalinterface` `NetworkInterface_networkinterface_id2_fn_PhysicalInterface_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id1_connectableci` join `functionalci` `ConnectableCI_connectableci_id1_functionalci` on((`ConnectableCI_connectableci_id1_connectableci`.`id` = `ConnectableCI_connectableci_id1_functionalci`.`id`))) on((`NetworkInterface_networkinterface_id2_fn_PhysicalInterface_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id1_connectableci`.`id`))) on((`NetworkInterface_networkinterface_id2_networkinterface`.`id` = `NetworkInterface_networkinterface_id2_fn_PhysicalInterface_physicalinterface`.`id`))) on((`_wanlink`.`networkinterface_id2` = `NetworkInterface_networkinterface_id2_networkinterface`.`id`))) left join `organization` `Organization_carrier_id_organization` on((`_wanlink`.`carrier_id` = `Organization_carrier_id_organization`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_wanlink`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WANType`
--

/*!50001 DROP TABLE IF EXISTS `view_WANType`*/;
/*!50001 DROP VIEW IF EXISTS `view_WANType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WANType` AS select distinct `_wantype`.`id` AS `id`,`_typology`.`name` AS `name`,`_wantype`.`description` AS `description`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`wantype` `_wantype` join `typology` `_typology` on((`_wantype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WebApplication`
--

/*!50001 DROP TABLE IF EXISTS `view_WebApplication`*/;
/*!50001 DROP VIEW IF EXISTS `view_WebApplication`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WebApplication` AS select distinct `_webapplication`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_webapplication`.`webserver_id` AS `webserver_id`,`WebServer_webserver_id_functionalci`.`name` AS `webserver_name`,`_webapplication`.`url` AS `url`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`WebServer_webserver_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `webserver_id_friendlyname` from ((`webapplication` `_webapplication` join ((`webserver` `WebServer_webserver_id_webserver` join `functionalci` `WebServer_webserver_id_functionalci` on((`WebServer_webserver_id_webserver`.`id` = `WebServer_webserver_id_functionalci`.`id`))) join (`softwareinstance` `WebServer_webserver_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`WebServer_webserver_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`WebServer_webserver_id_webserver`.`id` = `WebServer_webserver_id_softwareinstance`.`id`))) on((`_webapplication`.`webserver_id` = `WebServer_webserver_id_webserver`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_webapplication`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WebServer`
--

/*!50001 DROP TABLE IF EXISTS `view_WebServer`*/;
/*!50001 DROP VIEW IF EXISTS `view_WebServer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WebServer` AS select distinct `_webserver`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`webserver` `_webserver` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_webserver`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_webserver`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WorkOrder`
--

/*!50001 DROP TABLE IF EXISTS `view_WorkOrder`*/;
/*!50001 DROP VIEW IF EXISTS `view_WorkOrder`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WorkOrder` AS select distinct `_workorder`.`id` AS `id`,`_workorder`.`name` AS `name`,`_workorder`.`status` AS `status`,`_workorder`.`description` AS `description`,`_workorder`.`ticket_id` AS `ticket_id`,`Ticket_ticket_id_ticket`.`ref` AS `ticket_ref`,`_workorder`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_workorder`.`owner_id` AS `agent_id`,`Person_agent_id_contact`.`email` AS `agent_email`,`_workorder`.`start_date` AS `start_date`,`_workorder`.`end_date` AS `end_date`,`_workorder`.`log` AS `log`,`_workorder`.`log_index` AS `log_index`,cast(concat(coalesce(`_workorder`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Ticket_ticket_id_ticket`.`ref`,'')) as char charset utf8) AS `ticket_id_friendlyname`,`Ticket_ticket_id_ticket`.`finalclass` AS `ticket_id_finalclass_recall`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname` from (((`workorder` `_workorder` join `ticket` `Ticket_ticket_id_ticket` on((`_workorder`.`ticket_id` = `Ticket_ticket_id_ticket`.`id`))) join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_workorder`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_workorder`.`owner_id` = `Person_agent_id_person`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkApplicationSolutionToBusinessProcess`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkApplicationSolutionToBusinessProcess`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToBusinessProcess`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkApplicationSolutionToBusinessProcess` AS select distinct `_lnkapplicationsolutiontobusinessprocess`.`id` AS `id`,`_lnkapplicationsolutiontobusinessprocess`.`businessprocess_id` AS `businessprocess_id`,`BusinessProcess_businessprocess_id_functionalci`.`name` AS `businessprocess_name`,`_lnkapplicationsolutiontobusinessprocess`.`applicationsolution_id` AS `applicationsolution_id`,`ApplicationSolution_applicationsolution_id_functionalci`.`name` AS `applicationsolution_name`,cast(concat(coalesce(`_lnkapplicationsolutiontobusinessprocess`.`businessprocess_id`,''),coalesce(' ',''),coalesce(`_lnkapplicationsolutiontobusinessprocess`.`applicationsolution_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`BusinessProcess_businessprocess_id_functionalci`.`name`,'')) as char charset utf8) AS `businessprocess_id_friendlyname`,cast(concat(coalesce(`ApplicationSolution_applicationsolution_id_functionalci`.`name`,'')) as char charset utf8) AS `applicationsolution_id_friendlyname` from ((`lnkapplicationsolutiontobusinessprocess` `_lnkapplicationsolutiontobusinessprocess` join (`businessprocess` `BusinessProcess_businessprocess_id_businessprocess` join `functionalci` `BusinessProcess_businessprocess_id_functionalci` on((`BusinessProcess_businessprocess_id_businessprocess`.`id` = `BusinessProcess_businessprocess_id_functionalci`.`id`))) on((`_lnkapplicationsolutiontobusinessprocess`.`businessprocess_id` = `BusinessProcess_businessprocess_id_businessprocess`.`id`))) join (`applicationsolution` `ApplicationSolution_applicationsolution_id_applicationsolution` join `functionalci` `ApplicationSolution_applicationsolution_id_functionalci` on((`ApplicationSolution_applicationsolution_id_applicationsolution`.`id` = `ApplicationSolution_applicationsolution_id_functionalci`.`id`))) on((`_lnkapplicationsolutiontobusinessprocess`.`applicationsolution_id` = `ApplicationSolution_applicationsolution_id_applicationsolution`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkApplicationSolutionToFunctionalCI`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkApplicationSolutionToFunctionalCI`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkApplicationSolutionToFunctionalCI` AS select distinct `_lnkapplicationsolutiontofunctionalci`.`id` AS `id`,`_lnkapplicationsolutiontofunctionalci`.`applicationsolution_id` AS `applicationsolution_id`,`ApplicationSolution_applicationsolution_id_functionalci`.`name` AS `applicationsolution_name`,`_lnkapplicationsolutiontofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkapplicationsolutiontofunctionalci`.`applicationsolution_id`,''),coalesce(' ',''),coalesce(`_lnkapplicationsolutiontofunctionalci`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`ApplicationSolution_applicationsolution_id_functionalci`.`name`,'')) as char charset utf8) AS `applicationsolution_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkapplicationsolutiontofunctionalci` `_lnkapplicationsolutiontofunctionalci` join (`applicationsolution` `ApplicationSolution_applicationsolution_id_applicationsolution` join `functionalci` `ApplicationSolution_applicationsolution_id_functionalci` on((`ApplicationSolution_applicationsolution_id_applicationsolution`.`id` = `ApplicationSolution_applicationsolution_id_functionalci`.`id`))) on((`_lnkapplicationsolutiontofunctionalci`.`applicationsolution_id` = `ApplicationSolution_applicationsolution_id_applicationsolution`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkapplicationsolutiontofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkConnectableCIToNetworkDevice`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkConnectableCIToNetworkDevice`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkConnectableCIToNetworkDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkConnectableCIToNetworkDevice` AS select distinct `_lnkconnectablecitonetworkdevice`.`id` AS `id`,`_lnkconnectablecitonetworkdevice`.`networkdevice_id` AS `networkdevice_id`,`NetworkDevice_networkdevice_id_functionalci`.`name` AS `networkdevice_name`,`_lnkconnectablecitonetworkdevice`.`connectableci_id` AS `connectableci_id`,`ConnectableCI_connectableci_id_functionalci`.`name` AS `connectableci_name`,`_lnkconnectablecitonetworkdevice`.`network_port` AS `network_port`,`_lnkconnectablecitonetworkdevice`.`device_port` AS `device_port`,`_lnkconnectablecitonetworkdevice`.`type` AS `connection_type`,cast(concat(coalesce(`_lnkconnectablecitonetworkdevice`.`networkdevice_id`,''),coalesce(' ',''),coalesce(`_lnkconnectablecitonetworkdevice`.`connectableci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`NetworkDevice_networkdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `networkdevice_id_friendlyname`,cast(concat(coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `connectableci_id_friendlyname`,`ConnectableCI_connectableci_id_functionalci`.`finalclass` AS `connectableci_id_finalclass_recall` from ((`lnkconnectablecitonetworkdevice` `_lnkconnectablecitonetworkdevice` join (`networkdevice` `NetworkDevice_networkdevice_id_networkdevice` join `functionalci` `NetworkDevice_networkdevice_id_functionalci` on((`NetworkDevice_networkdevice_id_networkdevice`.`id` = `NetworkDevice_networkdevice_id_functionalci`.`id`))) on((`_lnkconnectablecitonetworkdevice`.`networkdevice_id` = `NetworkDevice_networkdevice_id_networkdevice`.`id`))) join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_lnkconnectablecitonetworkdevice`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToContract`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkContactToContract`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToContract` AS select distinct `_lnkcontacttocontract`.`id` AS `id`,`_lnkcontacttocontract`.`contract_id` AS `contract_id`,`Contract_contract_id_contract`.`name` AS `contract_name`,`_lnkcontacttocontract`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,cast(concat(coalesce(`_lnkcontacttocontract`.`contract_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttocontract`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Contract_contract_id_contract`.`name`,'')) as char charset utf8) AS `contract_id_friendlyname`,`Contract_contract_id_contract`.`finalclass` AS `contract_id_finalclass_recall`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttocontract` `_lnkcontacttocontract` join `contract` `Contract_contract_id_contract` on((`_lnkcontacttocontract`.`contract_id` = `Contract_contract_id_contract`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttocontract`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToFunctionalCI`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkContactToFunctionalCI`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToFunctionalCI` AS select distinct `_lnkcontacttofunctionalci`.`id` AS `id`,`_lnkcontacttofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkcontacttofunctionalci`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,cast(concat(coalesce(`_lnkcontacttofunctionalci`.`functionalci_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttofunctionalci`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttofunctionalci` `_lnkcontacttofunctionalci` join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkcontacttofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttofunctionalci`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToIPObject`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkContactToIPObject`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToIPObject`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToIPObject` AS select distinct `_lnkcontacttoipobject`.`id` AS `id`,`_lnkcontacttoipobject`.`ipobject_id` AS `ipobject_id`,`_lnkcontacttoipobject`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,cast(concat(coalesce(`_lnkcontacttoipobject`.`ipobject_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttoipobject`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPObject'),cast(concat(coalesce('IPObject','')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv6Subnet'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv6Subnet_ipsubnetv6`.`ip_text`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv4Address'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` in ('IPv4Range','IPv6Range')),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPRange_iprange`.`range`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv4Subnet'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv4Subnet_ipsubnetv4`.`ip`,'')) as char charset utf8),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPBlock_ipblock`.`name`,'')) as char charset utf8))))))) AS `ipobject_id_friendlyname`,`IPObject_ipobject_id_ipobject`.`finalclass` AS `ipobject_id_finalclass_recall`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttoipobject` `_lnkcontacttoipobject` join ((((((`ipobject` `IPObject_ipobject_id_ipobject` left join `ipaddressv6` `IPObject_ipobject_id_fn_IPv6Address_ipaddressv6` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipsubnetv6` `IPObject_ipobject_id_fn_IPv6Subnet_ipsubnetv6` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv6Subnet_ipsubnetv6`.`id`))) left join `ipaddressv4` `IPObject_ipobject_id_fn_IPv4Address_ipaddressv4` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv4Address_ipaddressv4`.`id`))) left join `iprange` `IPObject_ipobject_id_fn_IPRange_iprange` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPRange_iprange`.`id`))) left join `ipsubnetv4` `IPObject_ipobject_id_fn_IPv4Subnet_ipsubnetv4` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv4Subnet_ipsubnetv4`.`id`))) left join `ipblock` `IPObject_ipobject_id_fn_IPBlock_ipblock` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPBlock_ipblock`.`id`))) on((`_lnkcontacttoipobject`.`ipobject_id` = `IPObject_ipobject_id_ipobject`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttoipobject`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToService`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkContactToService`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToService` AS select distinct `_lnkcontacttoservice`.`id` AS `id`,`_lnkcontacttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkcontacttoservice`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,cast(concat(coalesce(`_lnkcontacttoservice`.`service_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttoservice`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttoservice` `_lnkcontacttoservice` join `service` `Service_service_id_service` on((`_lnkcontacttoservice`.`service_id` = `Service_service_id_service`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttoservice`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToTicket`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkContactToTicket`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToTicket`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToTicket` AS select distinct `_lnkcontacttoticket`.`id` AS `id`,`_lnkcontacttoticket`.`ticket_id` AS `ticket_id`,`Ticket_ticket_id_ticket`.`ref` AS `ticket_ref`,`_lnkcontacttoticket`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`email` AS `contact_email`,`_lnkcontacttoticket`.`role` AS `role`,`_lnkcontacttoticket`.`impact_code` AS `role_code`,cast(concat(coalesce(`_lnkcontacttoticket`.`ticket_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttoticket`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Ticket_ticket_id_ticket`.`ref`,'')) as char charset utf8) AS `ticket_id_friendlyname`,`Ticket_ticket_id_ticket`.`finalclass` AS `ticket_id_finalclass_recall`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttoticket` `_lnkcontacttoticket` join `ticket` `Ticket_ticket_id_ticket` on((`_lnkcontacttoticket`.`ticket_id` = `Ticket_ticket_id_ticket`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttoticket`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContractToDocument`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkContractToDocument`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkContractToDocument`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContractToDocument` AS select distinct `_lnkcontracttodocument`.`id` AS `id`,`_lnkcontracttodocument`.`contract_id` AS `contract_id`,`Contract_contract_id_contract`.`name` AS `contract_name`,`_lnkcontracttodocument`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkcontracttodocument`.`contract_id`,''),coalesce(' ',''),coalesce(`_lnkcontracttodocument`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Contract_contract_id_contract`.`name`,'')) as char charset utf8) AS `contract_id_friendlyname`,`Contract_contract_id_contract`.`finalclass` AS `contract_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkcontracttodocument` `_lnkcontracttodocument` join `contract` `Contract_contract_id_contract` on((`_lnkcontracttodocument`.`contract_id` = `Contract_contract_id_contract`.`id`))) join `document` `Document_document_id_document` on((`_lnkcontracttodocument`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkCustomerContractToService`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkCustomerContractToService`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkCustomerContractToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkCustomerContractToService` AS select distinct `_lnkcustomercontracttoservice`.`id` AS `id`,`_lnkcustomercontracttoservice`.`customercontract_id` AS `customercontract_id`,`CustomerContract_customercontract_id_contract`.`name` AS `customercontract_name`,`_lnkcustomercontracttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkcustomercontracttoservice`.`sla_id` AS `sla_id`,`SLA_sla_id_sla`.`name` AS `sla_name`,cast(concat(coalesce(`_lnkcustomercontracttoservice`.`customercontract_id`,''),coalesce(' ',''),coalesce(`_lnkcustomercontracttoservice`.`service_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`CustomerContract_customercontract_id_contract`.`name`,'')) as char charset utf8) AS `customercontract_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`SLA_sla_id_sla`.`name`,'')) as char charset utf8) AS `sla_id_friendlyname` from (((`lnkcustomercontracttoservice` `_lnkcustomercontracttoservice` join (`customercontract` `CustomerContract_customercontract_id_customercontract` join `contract` `CustomerContract_customercontract_id_contract` on((`CustomerContract_customercontract_id_customercontract`.`id` = `CustomerContract_customercontract_id_contract`.`id`))) on((`_lnkcustomercontracttoservice`.`customercontract_id` = `CustomerContract_customercontract_id_customercontract`.`id`))) join `service` `Service_service_id_service` on((`_lnkcustomercontracttoservice`.`service_id` = `Service_service_id_service`.`id`))) left join `sla` `SLA_sla_id_sla` on((`_lnkcustomercontracttoservice`.`sla_id` = `SLA_sla_id_sla`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDeliveryModelToContact`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkDeliveryModelToContact`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkDeliveryModelToContact`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDeliveryModelToContact` AS select distinct `_lnkdeliverymodeltocontact`.`id` AS `id`,`_lnkdeliverymodeltocontact`.`deliverymodel_id` AS `deliverymodel_id`,`DeliveryModel_deliverymodel_id_deliverymodel`.`name` AS `deliverymodel_name`,`_lnkdeliverymodeltocontact`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,`_lnkdeliverymodeltocontact`.`role_id` AS `role_id`,`ContactType_role_id_typology`.`name` AS `role_name`,cast(concat(coalesce(`_lnkdeliverymodeltocontact`.`deliverymodel_id`,''),coalesce(' ',''),coalesce(`_lnkdeliverymodeltocontact`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`DeliveryModel_deliverymodel_id_deliverymodel`.`name`,'')) as char charset utf8) AS `deliverymodel_id_friendlyname`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall`,cast(concat(coalesce(`ContactType_role_id_typology`.`name`,'')) as char charset utf8) AS `role_id_friendlyname` from (((`lnkdeliverymodeltocontact` `_lnkdeliverymodeltocontact` join `deliverymodel` `DeliveryModel_deliverymodel_id_deliverymodel` on((`_lnkdeliverymodeltocontact`.`deliverymodel_id` = `DeliveryModel_deliverymodel_id_deliverymodel`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkdeliverymodeltocontact`.`contact_id` = `Contact_contact_id_contact`.`id`))) left join (`contacttype` `ContactType_role_id_contacttype` join `typology` `ContactType_role_id_typology` on((`ContactType_role_id_contacttype`.`id` = `ContactType_role_id_typology`.`id`))) on((`_lnkdeliverymodeltocontact`.`role_id` = `ContactType_role_id_contacttype`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocToIPObject`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkDocToIPObject`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocToIPObject`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocToIPObject` AS select distinct `_lnkdoctoipobject`.`id` AS `id`,`_lnkdoctoipobject`.`ipobject_id` AS `ipobject_id`,`_lnkdoctoipobject`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdoctoipobject`.`ipobject_id`,''),coalesce(' ',''),coalesce(`_lnkdoctoipobject`.`document_id`,'')) as char charset utf8) AS `friendlyname`,if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPObject'),cast(concat(coalesce('IPObject','')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv6Subnet'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv6Subnet_ipsubnetv6`.`ip_text`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv4Address'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` in ('IPv4Range','IPv6Range')),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPRange_iprange`.`range`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv4Subnet'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv4Subnet_ipsubnetv4`.`ip`,'')) as char charset utf8),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPBlock_ipblock`.`name`,'')) as char charset utf8))))))) AS `ipobject_id_friendlyname`,`IPObject_ipobject_id_ipobject`.`finalclass` AS `ipobject_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdoctoipobject` `_lnkdoctoipobject` join ((((((`ipobject` `IPObject_ipobject_id_ipobject` left join `ipaddressv6` `IPObject_ipobject_id_fn_IPv6Address_ipaddressv6` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipsubnetv6` `IPObject_ipobject_id_fn_IPv6Subnet_ipsubnetv6` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv6Subnet_ipsubnetv6`.`id`))) left join `ipaddressv4` `IPObject_ipobject_id_fn_IPv4Address_ipaddressv4` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv4Address_ipaddressv4`.`id`))) left join `iprange` `IPObject_ipobject_id_fn_IPRange_iprange` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPRange_iprange`.`id`))) left join `ipsubnetv4` `IPObject_ipobject_id_fn_IPv4Subnet_ipsubnetv4` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv4Subnet_ipsubnetv4`.`id`))) left join `ipblock` `IPObject_ipobject_id_fn_IPBlock_ipblock` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPBlock_ipblock`.`id`))) on((`_lnkdoctoipobject`.`ipobject_id` = `IPObject_ipobject_id_ipobject`.`id`))) join `document` `Document_document_id_document` on((`_lnkdoctoipobject`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToError`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkDocumentToError`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToError`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToError` AS select distinct `_lnkdocumenttoerror`.`link_id` AS `id`,`_lnkdocumenttoerror`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,`_lnkdocumenttoerror`.`error_id` AS `error_id`,`KnownError_error_id_knownerror`.`name` AS `error_name`,`_lnkdocumenttoerror`.`link_type` AS `link_type`,cast(concat(coalesce(`_lnkdocumenttoerror`.`link_type`,'')) as char charset utf8) AS `friendlyname`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall`,cast(concat(coalesce(`KnownError_error_id_knownerror`.`name`,'')) as char charset utf8) AS `error_id_friendlyname` from ((`lnkdocumenttoerror` `_lnkdocumenttoerror` join `document` `Document_document_id_document` on((`_lnkdocumenttoerror`.`document_id` = `Document_document_id_document`.`id`))) join `knownerror` `KnownError_error_id_knownerror` on((`_lnkdocumenttoerror`.`error_id` = `KnownError_error_id_knownerror`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToFunctionalCI`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkDocumentToFunctionalCI`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToFunctionalCI` AS select distinct `_lnkdocumenttofunctionalci`.`id` AS `id`,`_lnkdocumenttofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkdocumenttofunctionalci`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttofunctionalci`.`functionalci_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttofunctionalci`.`document_id`,'')) as char charset utf8) AS `friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttofunctionalci` `_lnkdocumenttofunctionalci` join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkdocumenttofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttofunctionalci`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToLicence`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkDocumentToLicence`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToLicence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToLicence` AS select distinct `_lnkdocumenttolicence`.`id` AS `id`,`_lnkdocumenttolicence`.`licence_id` AS `licence_id`,`Licence_licence_id_licence`.`name` AS `licence_name`,`_lnkdocumenttolicence`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttolicence`.`licence_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttolicence`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Licence_licence_id_licence`.`name`,'')) as char charset utf8) AS `licence_id_friendlyname`,`Licence_licence_id_licence`.`finalclass` AS `licence_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttolicence` `_lnkdocumenttolicence` join `licence` `Licence_licence_id_licence` on((`_lnkdocumenttolicence`.`licence_id` = `Licence_licence_id_licence`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttolicence`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToPatch`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkDocumentToPatch`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToPatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToPatch` AS select distinct `_lnkdocumenttopatch`.`id` AS `id`,`_lnkdocumenttopatch`.`patch_id` AS `patch_id`,`Patch_patch_id_patch`.`name` AS `patch_name`,`_lnkdocumenttopatch`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttopatch`.`patch_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttopatch`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Patch_patch_id_patch`.`name`,'')) as char charset utf8) AS `patch_id_friendlyname`,`Patch_patch_id_patch`.`finalclass` AS `patch_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttopatch` `_lnkdocumenttopatch` join `patch` `Patch_patch_id_patch` on((`_lnkdocumenttopatch`.`patch_id` = `Patch_patch_id_patch`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttopatch`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToService`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkDocumentToService`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToService` AS select distinct `_lnkdocumenttoservice`.`id` AS `id`,`_lnkdocumenttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkdocumenttoservice`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttoservice`.`service_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttoservice`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttoservice` `_lnkdocumenttoservice` join `service` `Service_service_id_service` on((`_lnkdocumenttoservice`.`service_id` = `Service_service_id_service`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttoservice`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToSoftware`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkDocumentToSoftware`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToSoftware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToSoftware` AS select distinct `_lnkdocumenttosoftware`.`id` AS `id`,`_lnkdocumenttosoftware`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_lnkdocumenttosoftware`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttosoftware`.`software_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttosoftware`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttosoftware` `_lnkdocumenttosoftware` join `software` `Software_software_id_software` on((`_lnkdocumenttosoftware`.`software_id` = `Software_software_id_software`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttosoftware`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkErrorToFunctionalCI`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkErrorToFunctionalCI`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkErrorToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkErrorToFunctionalCI` AS select distinct `_lnkerrortofunctionalci`.`link_id` AS `id`,`_lnkerrortofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkerrortofunctionalci`.`error_id` AS `error_id`,`KnownError_error_id_knownerror`.`name` AS `error_name`,`_lnkerrortofunctionalci`.`dummy` AS `reason`,cast(concat(coalesce('lnkErrorToFunctionalCI','')) as char charset utf8) AS `friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall`,cast(concat(coalesce(`KnownError_error_id_knownerror`.`name`,'')) as char charset utf8) AS `error_id_friendlyname` from ((`lnkerrortofunctionalci` `_lnkerrortofunctionalci` join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkerrortofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) join `knownerror` `KnownError_error_id_knownerror` on((`_lnkerrortofunctionalci`.`error_id` = `KnownError_error_id_knownerror`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToOSPatch`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkFunctionalCIToOSPatch`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToOSPatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToOSPatch` AS select distinct `_lnkfunctionalcitoospatch`.`id` AS `id`,`_lnkfunctionalcitoospatch`.`ospatch_id` AS `ospatch_id`,`OSPatch_ospatch_id_patch`.`name` AS `ospatch_name`,`_lnkfunctionalcitoospatch`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkfunctionalcitoospatch`.`ospatch_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoospatch`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`OSPatch_ospatch_id_patch`.`name`,'')) as char charset utf8) AS `ospatch_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoospatch` `_lnkfunctionalcitoospatch` join (`ospatch` `OSPatch_ospatch_id_ospatch` join `patch` `OSPatch_ospatch_id_patch` on((`OSPatch_ospatch_id_ospatch`.`id` = `OSPatch_ospatch_id_patch`.`id`))) on((`_lnkfunctionalcitoospatch`.`ospatch_id` = `OSPatch_ospatch_id_ospatch`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoospatch`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToProviderContract`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkFunctionalCIToProviderContract`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToProviderContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToProviderContract` AS select distinct `_lnkfunctionalcitoprovidercontract`.`id` AS `id`,`_lnkfunctionalcitoprovidercontract`.`providercontract_id` AS `providercontract_id`,`ProviderContract_providercontract_id_contract`.`name` AS `providercontract_name`,`_lnkfunctionalcitoprovidercontract`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkfunctionalcitoprovidercontract`.`providercontract_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoprovidercontract`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`ProviderContract_providercontract_id_contract`.`name`,'')) as char charset utf8) AS `providercontract_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoprovidercontract` `_lnkfunctionalcitoprovidercontract` join (`providercontract` `ProviderContract_providercontract_id_providercontract` join `contract` `ProviderContract_providercontract_id_contract` on((`ProviderContract_providercontract_id_providercontract`.`id` = `ProviderContract_providercontract_id_contract`.`id`))) on((`_lnkfunctionalcitoprovidercontract`.`providercontract_id` = `ProviderContract_providercontract_id_providercontract`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoprovidercontract`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToService`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkFunctionalCIToService`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToService` AS select distinct `_lnkfunctionalcitoservice`.`id` AS `id`,`_lnkfunctionalcitoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkfunctionalcitoservice`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkfunctionalcitoservice`.`service_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoservice`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoservice` `_lnkfunctionalcitoservice` join `service` `Service_service_id_service` on((`_lnkfunctionalcitoservice`.`service_id` = `Service_service_id_service`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoservice`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToTicket`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkFunctionalCIToTicket`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToTicket`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToTicket` AS select distinct `_lnkfunctionalcitoticket`.`id` AS `id`,`_lnkfunctionalcitoticket`.`ticket_id` AS `ticket_id`,`Ticket_ticket_id_ticket`.`ref` AS `ticket_ref`,`Ticket_ticket_id_ticket`.`title` AS `ticket_title`,`_lnkfunctionalcitoticket`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkfunctionalcitoticket`.`impact` AS `impact`,`_lnkfunctionalcitoticket`.`impact_code` AS `impact_code`,cast(concat(coalesce(`_lnkfunctionalcitoticket`.`ticket_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoticket`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Ticket_ticket_id_ticket`.`ref`,'')) as char charset utf8) AS `ticket_id_friendlyname`,`Ticket_ticket_id_ticket`.`finalclass` AS `ticket_id_finalclass_recall`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoticket` `_lnkfunctionalcitoticket` join `ticket` `Ticket_ticket_id_ticket` on((`_lnkfunctionalcitoticket`.`ticket_id` = `Ticket_ticket_id_ticket`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoticket`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkGroupToCI`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkGroupToCI`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkGroupToCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkGroupToCI` AS select distinct `_lnkgrouptoci`.`id` AS `id`,`_lnkgrouptoci`.`group_id` AS `group_id`,`Group_group_id_group`.`name` AS `group_name`,`_lnkgrouptoci`.`ci_id` AS `ci_id`,`FunctionalCI_ci_id_functionalci`.`name` AS `ci_name`,`_lnkgrouptoci`.`reason` AS `reason`,cast(concat(coalesce(`_lnkgrouptoci`.`group_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Group_group_id_group`.`name`,'')) as char charset utf8) AS `group_id_friendlyname`,if((`FunctionalCI_ci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_ci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_ci_id_functionalci`.`name`,'')) as char charset utf8)) AS `ci_id_friendlyname`,`FunctionalCI_ci_id_functionalci`.`finalclass` AS `ci_id_finalclass_recall` from ((`lnkgrouptoci` `_lnkgrouptoci` join `group` `Group_group_id_group` on((`_lnkgrouptoci`.`group_id` = `Group_group_id_group`.`id`))) join (`functionalci` `FunctionalCI_ci_id_functionalci` left join (`softwareinstance` `FunctionalCI_ci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_ci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_ci_id_functionalci`.`id` = `FunctionalCI_ci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkgrouptoci`.`ci_id` = `FunctionalCI_ci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkIPAdressToIPAddress`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkIPAdressToIPAddress`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPAdressToIPAddress`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkIPAdressToIPAddress` AS select distinct `_lnkipaddresstoipaddress`.`id` AS `id`,`_lnkipaddresstoipaddress`.`ip1_id` AS `ip1_id`,`IPAddress_ip1_id_ipaddress`.`fqdn` AS `ip1_fqdn`,`_lnkipaddresstoipaddress`.`ip2_id` AS `ip2_id`,`IPAddress_ip2_id_ipaddress`.`fqdn` AS `ip2_fqdn`,cast(concat(coalesce(`_lnkipaddresstoipaddress`.`ip2_id`,''),coalesce(' ',''),coalesce(`_lnkipaddresstoipaddress`.`ip1_id`,'')) as char charset utf8) AS `friendlyname`,if((`IPAddress_ip1_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_ip1_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_ip1_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_ip1_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `ip1_id_friendlyname`,`IPAddress_ip1_id_ipobject`.`finalclass` AS `ip1_id_finalclass_recall`,if((`IPAddress_ip2_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_ip2_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_ip2_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_ip2_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `ip2_id_friendlyname`,`IPAddress_ip2_id_ipobject`.`finalclass` AS `ip2_id_finalclass_recall` from ((`lnkipaddresstoipaddress` `_lnkipaddresstoipaddress` join (((`ipaddress` `IPAddress_ip1_id_ipaddress` join `ipobject` `IPAddress_ip1_id_ipobject` on((`IPAddress_ip1_id_ipaddress`.`id` = `IPAddress_ip1_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_ip1_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_ip1_id_ipaddress`.`id` = `IPAddress_ip1_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_ip1_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_ip1_id_ipaddress`.`id` = `IPAddress_ip1_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_lnkipaddresstoipaddress`.`ip1_id` = `IPAddress_ip1_id_ipaddress`.`id`))) join (((`ipaddress` `IPAddress_ip2_id_ipaddress` join `ipobject` `IPAddress_ip2_id_ipobject` on((`IPAddress_ip2_id_ipaddress`.`id` = `IPAddress_ip2_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_ip2_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_ip2_id_ipaddress`.`id` = `IPAddress_ip2_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_ip2_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_ip2_id_ipaddress`.`id` = `IPAddress_ip2_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_lnkipaddresstoipaddress`.`ip2_id` = `IPAddress_ip2_id_ipaddress`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkIPBlockToLocation`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkIPBlockToLocation`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPBlockToLocation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkIPBlockToLocation` AS select distinct `_lnkipblocktolocation`.`id` AS `id`,`_lnkipblocktolocation`.`ipblock_id` AS `ipblock_id`,`IPBlock_ipblock_id_ipblock`.`name` AS `ipblock_name`,`_lnkipblocktolocation`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,cast(concat(coalesce(`_lnkipblocktolocation`.`location_id`,''),coalesce(' ',''),coalesce(`_lnkipblocktolocation`.`ipblock_id`,'')) as char charset utf8) AS `friendlyname`,if((`IPBlock_ipblock_id_ipobject`.`finalclass` = 'IPBlock'),cast(concat(coalesce('IPBlock','')) as char charset utf8),cast(concat(coalesce(`IPBlock_ipblock_id_ipblock`.`name`,'')) as char charset utf8)) AS `ipblock_id_friendlyname`,`IPBlock_ipblock_id_ipobject`.`finalclass` AS `ipblock_id_finalclass_recall`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname` from ((`lnkipblocktolocation` `_lnkipblocktolocation` join (`ipblock` `IPBlock_ipblock_id_ipblock` join `ipobject` `IPBlock_ipblock_id_ipobject` on((`IPBlock_ipblock_id_ipblock`.`id` = `IPBlock_ipblock_id_ipobject`.`id`))) on((`_lnkipblocktolocation`.`ipblock_id` = `IPBlock_ipblock_id_ipblock`.`id`))) join `location` `Location_location_id_location` on((`_lnkipblocktolocation`.`location_id` = `Location_location_id_location`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkIPInterfaceToIPAddress`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkIPInterfaceToIPAddress`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPInterfaceToIPAddress`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkIPInterfaceToIPAddress` AS select distinct `_lnkipinterfacetoipaddress`.`id` AS `id`,`_lnkipinterfacetoipaddress`.`ipinterface_id` AS `ipinterface_id`,`IPInterface_ipinterface_id_networkinterface`.`name` AS `ipinterface_name`,`_lnkipinterfacetoipaddress`.`ipaddress_id` AS `ipaddress_id`,cast(concat(coalesce(`_lnkipinterfacetoipaddress`.`ipinterface_id`,''),coalesce(' ',''),coalesce(`_lnkipinterfacetoipaddress`.`ipaddress_id`,'')) as char charset utf8) AS `friendlyname`,if((`IPInterface_ipinterface_id_networkinterface`.`finalclass` = 'IPInterface'),cast(concat(coalesce(`IPInterface_ipinterface_id_networkinterface`.`name`,'')) as char charset utf8),if((`IPInterface_ipinterface_id_networkinterface`.`finalclass` = 'LogicalInterface'),cast(concat(coalesce(`IPInterface_ipinterface_id_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`IPInterface_ipinterface_id_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8))) AS `ipinterface_id_friendlyname`,`IPInterface_ipinterface_id_networkinterface`.`finalclass` AS `ipinterface_id_finalclass_recall`,if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPAddress'),cast(concat(coalesce('IPAddress','')) as char charset utf8),if((`IPAddress_ipaddress_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8))) AS `ipaddress_id_friendlyname`,`IPAddress_ipaddress_id_ipobject`.`finalclass` AS `ipaddress_id_finalclass_recall` from ((`lnkipinterfacetoipaddress` `_lnkipinterfacetoipaddress` join (((`ipinterface` `IPInterface_ipinterface_id_ipinterface` join `networkinterface` `IPInterface_ipinterface_id_networkinterface` on((`IPInterface_ipinterface_id_ipinterface`.`id` = `IPInterface_ipinterface_id_networkinterface`.`id`))) left join (`logicalinterface` `IPInterface_ipinterface_id_fn_LogicalInterface_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`IPInterface_ipinterface_id_fn_LogicalInterface_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) on((`IPInterface_ipinterface_id_ipinterface`.`id` = `IPInterface_ipinterface_id_fn_LogicalInterface_logicalinterface`.`id`))) left join (`physicalinterface` `IPInterface_ipinterface_id_fn_PhysicalInterface_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`IPInterface_ipinterface_id_fn_PhysicalInterface_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) on((`IPInterface_ipinterface_id_ipinterface`.`id` = `IPInterface_ipinterface_id_fn_PhysicalInterface_physicalinterface`.`id`))) on((`_lnkipinterfacetoipaddress`.`ipinterface_id` = `IPInterface_ipinterface_id_ipinterface`.`id`))) join (((`ipaddress` `IPAddress_ipaddress_id_ipaddress` join `ipobject` `IPAddress_ipaddress_id_ipobject` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_ipobject`.`id`))) left join `ipaddressv6` `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipaddressv4` `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4` on((`IPAddress_ipaddress_id_ipaddress`.`id` = `IPAddress_ipaddress_id_fn_IPv4Address_ipaddressv4`.`id`))) on((`_lnkipinterfacetoipaddress`.`ipaddress_id` = `IPAddress_ipaddress_id_ipaddress`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkIPObjectToTicket`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkIPObjectToTicket`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPObjectToTicket`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkIPObjectToTicket` AS select distinct `_lnkipobjecttoticket`.`id` AS `id`,`_lnkipobjecttoticket`.`ipobject_id` AS `ipobject_id`,`_lnkipobjecttoticket`.`ticket_id` AS `ticket_id`,`Ticket_ticket_id_ticket`.`ref` AS `ticket_ref`,`Ticket_ticket_id_ticket`.`title` AS `ticket_title`,cast(concat(coalesce(`_lnkipobjecttoticket`.`ipobject_id`,''),coalesce(' ',''),coalesce(`_lnkipobjecttoticket`.`ticket_id`,'')) as char charset utf8) AS `friendlyname`,if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPObject'),cast(concat(coalesce('IPObject','')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv6Address'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv6Address_ipaddressv6`.`ip_text`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv6Subnet'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv6Subnet_ipsubnetv6`.`ip_text`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv4Address'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv4Address_ipaddressv4`.`ip`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` in ('IPv4Range','IPv6Range')),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPRange_iprange`.`range`,'')) as char charset utf8),if((`IPObject_ipobject_id_ipobject`.`finalclass` = 'IPv4Subnet'),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPv4Subnet_ipsubnetv4`.`ip`,'')) as char charset utf8),cast(concat(coalesce(`IPObject_ipobject_id_fn_IPBlock_ipblock`.`name`,'')) as char charset utf8))))))) AS `ipobject_id_friendlyname`,`IPObject_ipobject_id_ipobject`.`finalclass` AS `ipobject_id_finalclass_recall`,cast(concat(coalesce(`Ticket_ticket_id_ticket`.`ref`,'')) as char charset utf8) AS `ticket_id_friendlyname`,`Ticket_ticket_id_ticket`.`finalclass` AS `ticket_id_finalclass_recall` from ((`lnkipobjecttoticket` `_lnkipobjecttoticket` join ((((((`ipobject` `IPObject_ipobject_id_ipobject` left join `ipaddressv6` `IPObject_ipobject_id_fn_IPv6Address_ipaddressv6` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv6Address_ipaddressv6`.`id`))) left join `ipsubnetv6` `IPObject_ipobject_id_fn_IPv6Subnet_ipsubnetv6` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv6Subnet_ipsubnetv6`.`id`))) left join `ipaddressv4` `IPObject_ipobject_id_fn_IPv4Address_ipaddressv4` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv4Address_ipaddressv4`.`id`))) left join `iprange` `IPObject_ipobject_id_fn_IPRange_iprange` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPRange_iprange`.`id`))) left join `ipsubnetv4` `IPObject_ipobject_id_fn_IPv4Subnet_ipsubnetv4` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPv4Subnet_ipsubnetv4`.`id`))) left join `ipblock` `IPObject_ipobject_id_fn_IPBlock_ipblock` on((`IPObject_ipobject_id_ipobject`.`id` = `IPObject_ipobject_id_fn_IPBlock_ipblock`.`id`))) on((`_lnkipobjecttoticket`.`ipobject_id` = `IPObject_ipobject_id_ipobject`.`id`))) join `ticket` `Ticket_ticket_id_ticket` on((`_lnkipobjecttoticket`.`ticket_id` = `Ticket_ticket_id_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkIPSubnetToLocation`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkIPSubnetToLocation`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPSubnetToLocation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkIPSubnetToLocation` AS select distinct `_lnkipsubnettolocation`.`id` AS `id`,`_lnkipsubnettolocation`.`ipsubnet_id` AS `ipsubnet_id`,`IPSubnet_ipsubnet_id_ipsubnet`.`name` AS `ipsubnet_name`,`_lnkipsubnettolocation`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,cast(concat(coalesce(`_lnkipsubnettolocation`.`location_id`,''),coalesce(' ',''),coalesce(`_lnkipsubnettolocation`.`ipsubnet_id`,'')) as char charset utf8) AS `friendlyname`,if((`IPSubnet_ipsubnet_id_ipobject`.`finalclass` = 'IPSubnet'),cast(concat(coalesce('IPSubnet','')) as char charset utf8),if((`IPSubnet_ipsubnet_id_ipobject`.`finalclass` = 'IPv6Subnet'),cast(concat(coalesce(`IPSubnet_ipsubnet_id_fn_IPv6Subnet_ipsubnetv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPSubnet_ipsubnet_id_fn_IPv4Subnet_ipsubnetv4`.`ip`,'')) as char charset utf8))) AS `ipsubnet_id_friendlyname`,`IPSubnet_ipsubnet_id_ipobject`.`finalclass` AS `ipsubnet_id_finalclass_recall`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname` from ((`lnkipsubnettolocation` `_lnkipsubnettolocation` join (((`ipsubnet` `IPSubnet_ipsubnet_id_ipsubnet` join `ipobject` `IPSubnet_ipsubnet_id_ipobject` on((`IPSubnet_ipsubnet_id_ipsubnet`.`id` = `IPSubnet_ipsubnet_id_ipobject`.`id`))) left join `ipsubnetv6` `IPSubnet_ipsubnet_id_fn_IPv6Subnet_ipsubnetv6` on((`IPSubnet_ipsubnet_id_ipsubnet`.`id` = `IPSubnet_ipsubnet_id_fn_IPv6Subnet_ipsubnetv6`.`id`))) left join `ipsubnetv4` `IPSubnet_ipsubnet_id_fn_IPv4Subnet_ipsubnetv4` on((`IPSubnet_ipsubnet_id_ipsubnet`.`id` = `IPSubnet_ipsubnet_id_fn_IPv4Subnet_ipsubnetv4`.`id`))) on((`_lnkipsubnettolocation`.`ipsubnet_id` = `IPSubnet_ipsubnet_id_ipsubnet`.`id`))) join `location` `Location_location_id_location` on((`_lnkipsubnettolocation`.`location_id` = `Location_location_id_location`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkIPSubnetToVLAN`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkIPSubnetToVLAN`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPSubnetToVLAN`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkIPSubnetToVLAN` AS select distinct `_lnkipsubnettovlan`.`id` AS `id`,`_lnkipsubnettovlan`.`ipsubnet_id` AS `ipsubnet_id`,`IPSubnet_ipsubnet_id_ipsubnet`.`name` AS `ipsubnet_name`,`_lnkipsubnettovlan`.`vlan_id` AS `vlan_id`,`VLAN_vlan_id_vlan`.`vlan_tag` AS `vlan_tag`,cast(concat(coalesce(`_lnkipsubnettovlan`.`ipsubnet_id`,''),coalesce(' ',''),coalesce(`_lnkipsubnettovlan`.`vlan_id`,'')) as char charset utf8) AS `friendlyname`,if((`IPSubnet_ipsubnet_id_ipobject`.`finalclass` = 'IPSubnet'),cast(concat(coalesce('IPSubnet','')) as char charset utf8),if((`IPSubnet_ipsubnet_id_ipobject`.`finalclass` = 'IPv6Subnet'),cast(concat(coalesce(`IPSubnet_ipsubnet_id_fn_IPv6Subnet_ipsubnetv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPSubnet_ipsubnet_id_fn_IPv4Subnet_ipsubnetv4`.`ip`,'')) as char charset utf8))) AS `ipsubnet_id_friendlyname`,`IPSubnet_ipsubnet_id_ipobject`.`finalclass` AS `ipsubnet_id_finalclass_recall`,cast(concat(coalesce(`VLAN_vlan_id_vlan`.`vlan_tag`,'')) as char charset utf8) AS `vlan_id_friendlyname` from ((`lnkipsubnettovlan` `_lnkipsubnettovlan` join (((`ipsubnet` `IPSubnet_ipsubnet_id_ipsubnet` join `ipobject` `IPSubnet_ipsubnet_id_ipobject` on((`IPSubnet_ipsubnet_id_ipsubnet`.`id` = `IPSubnet_ipsubnet_id_ipobject`.`id`))) left join `ipsubnetv6` `IPSubnet_ipsubnet_id_fn_IPv6Subnet_ipsubnetv6` on((`IPSubnet_ipsubnet_id_ipsubnet`.`id` = `IPSubnet_ipsubnet_id_fn_IPv6Subnet_ipsubnetv6`.`id`))) left join `ipsubnetv4` `IPSubnet_ipsubnet_id_fn_IPv4Subnet_ipsubnetv4` on((`IPSubnet_ipsubnet_id_ipsubnet`.`id` = `IPSubnet_ipsubnet_id_fn_IPv4Subnet_ipsubnetv4`.`id`))) on((`_lnkipsubnettovlan`.`ipsubnet_id` = `IPSubnet_ipsubnet_id_ipsubnet`.`id`))) join `vlan` `VLAN_vlan_id_vlan` on((`_lnkipsubnettovlan`.`vlan_id` = `VLAN_vlan_id_vlan`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkIPSubnetToVRF`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkIPSubnetToVRF`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkIPSubnetToVRF`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkIPSubnetToVRF` AS select distinct `_lnkipsubnettovrf`.`id` AS `id`,`_lnkipsubnettovrf`.`ipsubnet_id` AS `ipsubnet_id`,`IPSubnet_ipsubnet_id_ipsubnet`.`name` AS `ipsubnet_name`,`_lnkipsubnettovrf`.`vrf_id` AS `vrf_id`,cast(concat(coalesce(`_lnkipsubnettovrf`.`ipsubnet_id`,''),coalesce(' ',''),coalesce(`_lnkipsubnettovrf`.`vrf_id`,'')) as char charset utf8) AS `friendlyname`,if((`IPSubnet_ipsubnet_id_ipobject`.`finalclass` = 'IPSubnet'),cast(concat(coalesce('IPSubnet','')) as char charset utf8),if((`IPSubnet_ipsubnet_id_ipobject`.`finalclass` = 'IPv6Subnet'),cast(concat(coalesce(`IPSubnet_ipsubnet_id_fn_IPv6Subnet_ipsubnetv6`.`ip_text`,'')) as char charset utf8),cast(concat(coalesce(`IPSubnet_ipsubnet_id_fn_IPv4Subnet_ipsubnetv4`.`ip`,'')) as char charset utf8))) AS `ipsubnet_id_friendlyname`,`IPSubnet_ipsubnet_id_ipobject`.`finalclass` AS `ipsubnet_id_finalclass_recall`,cast(concat(coalesce(`VRF_vrf_id_functionalci`.`name`,'')) as char charset utf8) AS `vrf_id_friendlyname` from ((`lnkipsubnettovrf` `_lnkipsubnettovrf` join (((`ipsubnet` `IPSubnet_ipsubnet_id_ipsubnet` join `ipobject` `IPSubnet_ipsubnet_id_ipobject` on((`IPSubnet_ipsubnet_id_ipsubnet`.`id` = `IPSubnet_ipsubnet_id_ipobject`.`id`))) left join `ipsubnetv6` `IPSubnet_ipsubnet_id_fn_IPv6Subnet_ipsubnetv6` on((`IPSubnet_ipsubnet_id_ipsubnet`.`id` = `IPSubnet_ipsubnet_id_fn_IPv6Subnet_ipsubnetv6`.`id`))) left join `ipsubnetv4` `IPSubnet_ipsubnet_id_fn_IPv4Subnet_ipsubnetv4` on((`IPSubnet_ipsubnet_id_ipsubnet`.`id` = `IPSubnet_ipsubnet_id_fn_IPv4Subnet_ipsubnetv4`.`id`))) on((`_lnkipsubnettovrf`.`ipsubnet_id` = `IPSubnet_ipsubnet_id_ipsubnet`.`id`))) join (`vrf` `VRF_vrf_id_vrf` join `functionalci` `VRF_vrf_id_functionalci` on((`VRF_vrf_id_vrf`.`id` = `VRF_vrf_id_functionalci`.`id`))) on((`_lnkipsubnettovrf`.`vrf_id` = `VRF_vrf_id_vrf`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkPersonToTeam`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkPersonToTeam`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkPersonToTeam`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkPersonToTeam` AS select distinct `_lnkpersontoteam`.`id` AS `id`,`_lnkpersontoteam`.`team_id` AS `team_id`,`Team_team_id_contact`.`name` AS `team_name`,`_lnkpersontoteam`.`person_id` AS `person_id`,`Person_person_id_contact`.`name` AS `person_name`,`_lnkpersontoteam`.`role_id` AS `role_id`,`ContactType_role_id_typology`.`name` AS `role_name`,cast(concat(coalesce(`_lnkpersontoteam`.`team_id`,''),coalesce(' ',''),coalesce(`_lnkpersontoteam`.`person_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_person_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_person_id_contact`.`name`,'')) as char charset utf8) AS `person_id_friendlyname`,cast(concat(coalesce(`ContactType_role_id_typology`.`name`,'')) as char charset utf8) AS `role_id_friendlyname` from (((`lnkpersontoteam` `_lnkpersontoteam` join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_lnkpersontoteam`.`team_id` = `Team_team_id_team`.`id`))) join (`person` `Person_person_id_person` join `contact` `Person_person_id_contact` on((`Person_person_id_person`.`id` = `Person_person_id_contact`.`id`))) on((`_lnkpersontoteam`.`person_id` = `Person_person_id_person`.`id`))) left join (`contacttype` `ContactType_role_id_contacttype` join `typology` `ContactType_role_id_typology` on((`ContactType_role_id_contacttype`.`id` = `ContactType_role_id_typology`.`id`))) on((`_lnkpersontoteam`.`role_id` = `ContactType_role_id_contacttype`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkPhysicalInterfaceToVLAN`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkPhysicalInterfaceToVLAN`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkPhysicalInterfaceToVLAN`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkPhysicalInterfaceToVLAN` AS select distinct `_lnkphysicalinterfacetovlan`.`id` AS `id`,`_lnkphysicalinterfacetovlan`.`physicalinterface_id` AS `physicalinterface_id`,`PhysicalInterface_physicalinterface_id_networkinterface`.`name` AS `physicalinterface_name`,`PhysicalInterface_physicalinterface_id_physicalinterface`.`connectableci_id` AS `physicalinterface_device_id`,`ConnectableCI_connectableci_id_functionalci`.`name` AS `physicalinterface_device_name`,`_lnkphysicalinterfacetovlan`.`vlan_id` AS `vlan_id`,`VLAN_vlan_id_vlan`.`vlan_tag` AS `vlan_tag`,cast(concat(coalesce(`_lnkphysicalinterfacetovlan`.`physicalinterface_id`,''),coalesce(' ',''),coalesce(`_lnkphysicalinterfacetovlan`.`vlan_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`PhysicalInterface_physicalinterface_id_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `physicalinterface_id_friendlyname`,cast(concat(coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `physicalinterface_device_id_friendlyname`,cast(concat(coalesce(`VLAN_vlan_id_vlan`.`vlan_tag`,'')) as char charset utf8) AS `vlan_id_friendlyname` from ((`lnkphysicalinterfacetovlan` `_lnkphysicalinterfacetovlan` join ((`physicalinterface` `PhysicalInterface_physicalinterface_id_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`PhysicalInterface_physicalinterface_id_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) join `networkinterface` `PhysicalInterface_physicalinterface_id_networkinterface` on((`PhysicalInterface_physicalinterface_id_physicalinterface`.`id` = `PhysicalInterface_physicalinterface_id_networkinterface`.`id`))) on((`_lnkphysicalinterfacetovlan`.`physicalinterface_id` = `PhysicalInterface_physicalinterface_id_physicalinterface`.`id`))) join `vlan` `VLAN_vlan_id_vlan` on((`_lnkphysicalinterfacetovlan`.`vlan_id` = `VLAN_vlan_id_vlan`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkPhysicalInterfaceToVRF`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkPhysicalInterfaceToVRF`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkPhysicalInterfaceToVRF`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkPhysicalInterfaceToVRF` AS select distinct `_lnkphysicalinterfacetovrf`.`id` AS `id`,`_lnkphysicalinterfacetovrf`.`physicalinterface_id` AS `physicalinterface_id`,`PhysicalInterface_physicalinterface_id_networkinterface`.`name` AS `physicalinterface_name`,`PhysicalInterface_physicalinterface_id_physicalinterface`.`connectableci_id` AS `physicalinterface_device_id`,`ConnectableCI_connectableci_id_functionalci`.`name` AS `physicalinterface_device_name`,`_lnkphysicalinterfacetovrf`.`vrf_id` AS `vrf_id`,`VRF_vrf_id_functionalci`.`name` AS `name`,cast(concat(coalesce(`_lnkphysicalinterfacetovrf`.`physicalinterface_id`,''),coalesce(' ',''),coalesce(`_lnkphysicalinterfacetovrf`.`vrf_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`PhysicalInterface_physicalinterface_id_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `physicalinterface_id_friendlyname`,cast(concat(coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `physicalinterface_device_id_friendlyname`,cast(concat(coalesce(`VRF_vrf_id_functionalci`.`name`,'')) as char charset utf8) AS `vrf_id_friendlyname` from ((`lnkphysicalinterfacetovrf` `_lnkphysicalinterfacetovrf` join ((`physicalinterface` `PhysicalInterface_physicalinterface_id_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`PhysicalInterface_physicalinterface_id_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) join `networkinterface` `PhysicalInterface_physicalinterface_id_networkinterface` on((`PhysicalInterface_physicalinterface_id_physicalinterface`.`id` = `PhysicalInterface_physicalinterface_id_networkinterface`.`id`))) on((`_lnkphysicalinterfacetovrf`.`physicalinterface_id` = `PhysicalInterface_physicalinterface_id_physicalinterface`.`id`))) join (`vrf` `VRF_vrf_id_vrf` join `functionalci` `VRF_vrf_id_functionalci` on((`VRF_vrf_id_vrf`.`id` = `VRF_vrf_id_functionalci`.`id`))) on((`_lnkphysicalinterfacetovrf`.`vrf_id` = `VRF_vrf_id_vrf`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkProviderContractToService`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkProviderContractToService`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkProviderContractToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkProviderContractToService` AS select distinct `_lnkprovidercontracttoservice`.`id` AS `id`,`_lnkprovidercontracttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkprovidercontracttoservice`.`providercontract_id` AS `providercontract_id`,`ProviderContract_providercontract_id_contract`.`name` AS `providercontract_name`,cast(concat(coalesce(`_lnkprovidercontracttoservice`.`service_id`,''),coalesce(' ',''),coalesce(`_lnkprovidercontracttoservice`.`providercontract_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`ProviderContract_providercontract_id_contract`.`name`,'')) as char charset utf8) AS `providercontract_id_friendlyname` from ((`lnkprovidercontracttoservice` `_lnkprovidercontracttoservice` join `service` `Service_service_id_service` on((`_lnkprovidercontracttoservice`.`service_id` = `Service_service_id_service`.`id`))) join (`providercontract` `ProviderContract_providercontract_id_providercontract` join `contract` `ProviderContract_providercontract_id_contract` on((`ProviderContract_providercontract_id_providercontract`.`id` = `ProviderContract_providercontract_id_contract`.`id`))) on((`_lnkprovidercontracttoservice`.`providercontract_id` = `ProviderContract_providercontract_id_providercontract`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSLAToSLT`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkSLAToSLT`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkSLAToSLT`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSLAToSLT` AS select distinct `_lnkslatoslt`.`id` AS `id`,`_lnkslatoslt`.`sla_id` AS `sla_id`,`SLA_sla_id_sla`.`name` AS `sla_name`,`_lnkslatoslt`.`slt_id` AS `slt_id`,`SLT_slt_id_slt`.`name` AS `slt_name`,`SLT_slt_id_slt`.`metric` AS `slt_metric`,`SLT_slt_id_slt`.`request_type` AS `slt_request_type`,`SLT_slt_id_slt`.`priority` AS `slt_ticket_priority`,`SLT_slt_id_slt`.`value` AS `slt_value`,`SLT_slt_id_slt`.`unit` AS `slt_value_unit`,cast(concat(coalesce(`_lnkslatoslt`.`sla_id`,''),coalesce(' ',''),coalesce(`_lnkslatoslt`.`slt_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`SLA_sla_id_sla`.`name`,'')) as char charset utf8) AS `sla_id_friendlyname`,cast(concat(coalesce(`SLT_slt_id_slt`.`name`,'')) as char charset utf8) AS `slt_id_friendlyname` from ((`lnkslatoslt` `_lnkslatoslt` join `sla` `SLA_sla_id_sla` on((`_lnkslatoslt`.`sla_id` = `SLA_sla_id_sla`.`id`))) join `slt` `SLT_slt_id_slt` on((`_lnkslatoslt`.`slt_id` = `SLT_slt_id_slt`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSanToDatacenterDevice`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkSanToDatacenterDevice`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkSanToDatacenterDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSanToDatacenterDevice` AS select distinct `_lnkdatacenterdevicetosan`.`id` AS `id`,`_lnkdatacenterdevicetosan`.`san_id` AS `san_id`,`SANSwitch_san_id_functionalci`.`name` AS `san_name`,`_lnkdatacenterdevicetosan`.`datacenterdevice_id` AS `datacenterdevice_id`,`DatacenterDevice_datacenterdevice_id_functionalci`.`name` AS `datacenterdevice_name`,`_lnkdatacenterdevicetosan`.`san_port` AS `san_port`,`_lnkdatacenterdevicetosan`.`datacenterdevice_port` AS `datacenterdevice_port`,cast(concat(coalesce(`_lnkdatacenterdevicetosan`.`san_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`SANSwitch_san_id_functionalci`.`name`,'')) as char charset utf8) AS `san_id_friendlyname`,cast(concat(coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `datacenterdevice_id_friendlyname`,`DatacenterDevice_datacenterdevice_id_functionalci`.`finalclass` AS `datacenterdevice_id_finalclass_recall` from ((`lnkdatacenterdevicetosan` `_lnkdatacenterdevicetosan` join (`sanswitch` `SANSwitch_san_id_sanswitch` join `functionalci` `SANSwitch_san_id_functionalci` on((`SANSwitch_san_id_sanswitch`.`id` = `SANSwitch_san_id_functionalci`.`id`))) on((`_lnkdatacenterdevicetosan`.`san_id` = `SANSwitch_san_id_sanswitch`.`id`))) join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id_functionalci` on((`DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id_functionalci`.`id`))) on((`_lnkdatacenterdevicetosan`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkServerToVolume`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkServerToVolume`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkServerToVolume`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkServerToVolume` AS select distinct `_lnkservertovolume`.`id` AS `id`,`_lnkservertovolume`.`volume_id` AS `volume_id`,`LogicalVolume_volume_id_logicalvolume`.`name` AS `volume_name`,`_lnkservertovolume`.`server_id` AS `server_id`,`Server_server_id_functionalci`.`name` AS `server_name`,`_lnkservertovolume`.`size_used` AS `size_used`,cast(concat(coalesce(`_lnkservertovolume`.`volume_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`LogicalVolume_volume_id_logicalvolume`.`name`,'')) as char charset utf8) AS `volume_id_friendlyname`,cast(concat(coalesce(`Server_server_id_functionalci`.`name`,'')) as char charset utf8) AS `server_id_friendlyname` from ((`lnkservertovolume` `_lnkservertovolume` join (`logicalvolume` `LogicalVolume_volume_id_logicalvolume` join (`storagesystem` `StorageSystem_storagesystem_id_storagesystem` join `functionalci` `StorageSystem_storagesystem_id_functionalci` on((`StorageSystem_storagesystem_id_storagesystem`.`id` = `StorageSystem_storagesystem_id_functionalci`.`id`))) on((`LogicalVolume_volume_id_logicalvolume`.`storagesystem_id` = `StorageSystem_storagesystem_id_storagesystem`.`id`))) on((`_lnkservertovolume`.`volume_id` = `LogicalVolume_volume_id_logicalvolume`.`id`))) join (`server` `Server_server_id_server` join `functionalci` `Server_server_id_functionalci` on((`Server_server_id_server`.`id` = `Server_server_id_functionalci`.`id`))) on((`_lnkservertovolume`.`server_id` = `Server_server_id_server`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSoftwareInstanceToSoftwarePatch`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkSoftwareInstanceToSoftwarePatch`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkSoftwareInstanceToSoftwarePatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSoftwareInstanceToSoftwarePatch` AS select distinct `_lnksoftwareinstancetosoftwarepatch`.`id` AS `id`,`_lnksoftwareinstancetosoftwarepatch`.`softwarepatch_id` AS `softwarepatch_id`,`SoftwarePatch_softwarepatch_id_patch`.`name` AS `softwarepatch_name`,`_lnksoftwareinstancetosoftwarepatch`.`softwareinstance_id` AS `softwareinstance_id`,`SoftwareInstance_softwareinstance_id_functionalci`.`name` AS `softwareinstance_name`,cast(concat(coalesce(`_lnksoftwareinstancetosoftwarepatch`.`softwarepatch_id`,''),coalesce(' ',''),coalesce(`_lnksoftwareinstancetosoftwarepatch`.`softwareinstance_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`SoftwarePatch_softwarepatch_id_patch`.`name`,'')) as char charset utf8) AS `softwarepatch_id_friendlyname`,cast(concat(coalesce(`SoftwareInstance_softwareinstance_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `softwareinstance_id_friendlyname`,`SoftwareInstance_softwareinstance_id_functionalci`.`finalclass` AS `softwareinstance_id_finalclass_recall` from ((`lnksoftwareinstancetosoftwarepatch` `_lnksoftwareinstancetosoftwarepatch` join (`softwarepatch` `SoftwarePatch_softwarepatch_id_softwarepatch` join `patch` `SoftwarePatch_softwarepatch_id_patch` on((`SoftwarePatch_softwarepatch_id_softwarepatch`.`id` = `SoftwarePatch_softwarepatch_id_patch`.`id`))) on((`_lnksoftwareinstancetosoftwarepatch`.`softwarepatch_id` = `SoftwarePatch_softwarepatch_id_softwarepatch`.`id`))) join ((`softwareinstance` `SoftwareInstance_softwareinstance_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`SoftwareInstance_softwareinstance_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) join `functionalci` `SoftwareInstance_softwareinstance_id_functionalci` on((`SoftwareInstance_softwareinstance_id_softwareinstance`.`id` = `SoftwareInstance_softwareinstance_id_functionalci`.`id`))) on((`_lnksoftwareinstancetosoftwarepatch`.`softwareinstance_id` = `SoftwareInstance_softwareinstance_id_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSubnetToVLAN`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkSubnetToVLAN`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkSubnetToVLAN`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSubnetToVLAN` AS select distinct `_lnksubnettovlan`.`id` AS `id`,`_lnksubnettovlan`.`subnet_id` AS `subnet_id`,`Subnet_subnet_id_subnet`.`ip` AS `subnet_ip`,`Subnet_subnet_id_subnet`.`subnet_name` AS `subnet_name`,`_lnksubnettovlan`.`vlan_id` AS `vlan_id`,`VLAN_vlan_id_vlan`.`vlan_tag` AS `vlan_tag`,cast(concat(coalesce(`_lnksubnettovlan`.`subnet_id`,''),coalesce(' ',''),coalesce(`_lnksubnettovlan`.`vlan_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Subnet_subnet_id_subnet`.`ip`,''),coalesce(' ',''),coalesce(`Subnet_subnet_id_subnet`.`ip_mask`,'')) as char charset utf8) AS `subnet_id_friendlyname`,cast(concat(coalesce(`VLAN_vlan_id_vlan`.`vlan_tag`,'')) as char charset utf8) AS `vlan_id_friendlyname` from ((`lnksubnettovlan` `_lnksubnettovlan` join `subnet` `Subnet_subnet_id_subnet` on((`_lnksubnettovlan`.`subnet_id` = `Subnet_subnet_id_subnet`.`id`))) join `vlan` `VLAN_vlan_id_vlan` on((`_lnksubnettovlan`.`vlan_id` = `VLAN_vlan_id_vlan`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkVirtualDeviceToVolume`
--

/*!50001 DROP TABLE IF EXISTS `view_lnkVirtualDeviceToVolume`*/;
/*!50001 DROP VIEW IF EXISTS `view_lnkVirtualDeviceToVolume`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkVirtualDeviceToVolume` AS select distinct `_lnkvirtualdevicetovolume`.`id` AS `id`,`_lnkvirtualdevicetovolume`.`volume_id` AS `volume_id`,`LogicalVolume_volume_id_logicalvolume`.`name` AS `volume_name`,`_lnkvirtualdevicetovolume`.`virtualdevice_id` AS `virtualdevice_id`,`VirtualDevice_virtualdevice_id_functionalci`.`name` AS `virtualdevice_name`,`_lnkvirtualdevicetovolume`.`size_used` AS `size_used`,cast(concat(coalesce(`_lnkvirtualdevicetovolume`.`volume_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`LogicalVolume_volume_id_logicalvolume`.`name`,'')) as char charset utf8) AS `volume_id_friendlyname`,cast(concat(coalesce(`VirtualDevice_virtualdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `virtualdevice_id_friendlyname`,`VirtualDevice_virtualdevice_id_functionalci`.`finalclass` AS `virtualdevice_id_finalclass_recall` from ((`lnkvirtualdevicetovolume` `_lnkvirtualdevicetovolume` join (`logicalvolume` `LogicalVolume_volume_id_logicalvolume` join (`storagesystem` `StorageSystem_storagesystem_id_storagesystem` join `functionalci` `StorageSystem_storagesystem_id_functionalci` on((`StorageSystem_storagesystem_id_storagesystem`.`id` = `StorageSystem_storagesystem_id_functionalci`.`id`))) on((`LogicalVolume_volume_id_logicalvolume`.`storagesystem_id` = `StorageSystem_storagesystem_id_storagesystem`.`id`))) on((`_lnkvirtualdevicetovolume`.`volume_id` = `LogicalVolume_volume_id_logicalvolume`.`id`))) join (`virtualdevice` `VirtualDevice_virtualdevice_id_virtualdevice` join `functionalci` `VirtualDevice_virtualdevice_id_functionalci` on((`VirtualDevice_virtualdevice_id_virtualdevice`.`id` = `VirtualDevice_virtualdevice_id_functionalci`.`id`))) on((`_lnkvirtualdevicetovolume`.`virtualdevice_id` = `VirtualDevice_virtualdevice_id_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-29 20:48:38
